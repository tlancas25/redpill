# Small Business Competitive Edge

Premium skill pack ($97) for small business owners who want to automate review management, social media content, email & SMS marketing, competitor intelligence, and unified analytics.

## Quick Start

1. Copy `config.example.json` to `config.json` and fill in your business details.
2. Add API keys to your `~/.openclaw/.env` file (see Environment Variables below).
3. Install dependencies: `pip install -r requirements.txt`
4. Run any script: `python3 scripts/review_engine.py --help`

## Scripts

### review_engine.py — Review Monitoring & Response

Monitor Google and Yelp reviews, generate AI-assisted responses, track sentiment, and alert on negative reviews.

```bash
python3 scripts/review_engine.py check --platforms google,yelp
python3 scripts/review_engine.py respond --auto --tone professional
python3 scripts/review_engine.py respond --review-id 42 --tone friendly
python3 scripts/review_engine.py analytics --period 30d
python3 scripts/review_engine.py alerts
```

**Features:**
- Google Business Profile API + Yelp Fusion API integration
- Contextual response generation (different for 5-star vs 1-star reviews)
- Sentiment analysis on all reviews
- SQLite tracking of reviews and responses
- Automatic alerts on negative reviews (< 3 stars)
- Response tone options: professional, friendly, formal

### local_social.py — Localized Social Media Content

Generate business-type aware social media content with weekly calendars, promotions, testimonials, and local event tie-ins.

```bash
python3 scripts/local_social.py generate-week --business-type restaurant --business-name "Joe's Diner" --location "Austin, TX"
python3 scripts/local_social.py promo --type discount --offer "20% off all haircuts"
python3 scripts/local_social.py testimonial --review "Best pizza in town!" --reviewer "Sarah M."
python3 scripts/local_social.py local-event --event "Austin Food Festival" --date 2026-04-15 --tie-in "Visit us after!"
python3 scripts/local_social.py post-now --platform x --content "Fresh batch just out of the oven!"
```

**Supported business types:** restaurant, salon, service, retail

### biz_dashboard.py — Unified Business Analytics

Aggregated dashboard pulling from Stripe (revenue), Google/Yelp (reputation), X (social), SendGrid (email), and local data.

```bash
python3 scripts/biz_dashboard.py overview
python3 scripts/biz_dashboard.py trends --metric revenue --period 30d
python3 scripts/biz_dashboard.py competitors
python3 scripts/biz_dashboard.py cac
python3 scripts/biz_dashboard.py export --format json
```

**Features:**
- ASCII-art dashboard display (with --verbose)
- Trend analysis with period-over-period comparison
- Customer acquisition cost calculation
- JSON and formatted text export

### competitor_intel.py — Competitive Monitoring

Track competitor ratings, review counts, and social media presence over time. Detect opportunities when competitors are inactive or declining.

```bash
python3 scripts/competitor_intel.py track --competitor "Rival Cafe" --platforms google,yelp
python3 scripts/competitor_intel.py report
python3 scripts/competitor_intel.py compare
python3 scripts/competitor_intel.py alerts
```

**Opportunity detection:**
- Competitor rating dropping (> 0.2 star decline)
- Competitor social media inactivity (14+ days)

### email_engine.py — Email Marketing Automation

SendGrid-powered email sequences with subscriber segmentation and pre-built campaign templates.

```bash
python3 scripts/email_engine.py create-sequence --name welcome
python3 scripts/email_engine.py broadcast --subject "Spring Sale!" --segment active
python3 scripts/email_engine.py analytics
python3 scripts/email_engine.py list-sequences
python3 scripts/email_engine.py subscribers --action add --email user@example.com --first-name John
python3 scripts/email_engine.py subscribers --action list --segment vip
```

**Pre-built sequences:** welcome, win-back, review-request, referral, birthday, loyalty

**Segments:** active, lapsed, new, vip, all

### sms_engine.py — SMS Notification System

Twilio-powered SMS with opt-in/opt-out compliance, segment-based blasts, and delivery tracking.

```bash
python3 scripts/sms_engine.py send --to +15551234567 --message "Your order is ready!"
python3 scripts/sms_engine.py blast --segment vip --message "Exclusive VIP sale this weekend!"
python3 scripts/sms_engine.py opt-in --phone +15551234567 --name "John Doe"
python3 scripts/sms_engine.py opt-out --phone +15551234567
python3 scripts/sms_engine.py stats
```

## Pipelines

### daily-operations.json
Full daily automation: check reviews, track competitors, generate social content, pull email/SMS stats, render dashboard.

### review-response.json
Focused review pipeline: fetch new reviews, check for alerts, auto-respond, report analytics.

## Environment Variables

Add these to `~/.openclaw/.env`:

```
# Google Business Profile
GOOGLE_BUSINESS_ACCESS_TOKEN=your_token
GOOGLE_BUSINESS_ACCOUNT_ID=your_account_id
GOOGLE_BUSINESS_LOCATION_ID=your_location_id
GOOGLE_PLACES_API_KEY=your_api_key

# Yelp
YELP_API_KEY=your_yelp_api_key
YELP_BUSINESS_ID=your-business-city

# X / Twitter
X_BEARER_TOKEN=your_bearer_token
X_USER_ID=your_user_id

# SendGrid
SENDGRID_API_KEY=your_sendgrid_key
SENDGRID_FROM_EMAIL=hello@yourbusiness.com
SENDGRID_FROM_NAME=Your Business

# Twilio
TWILIO_ACCOUNT_SID=your_sid
TWILIO_AUTH_TOKEN=your_token
TWILIO_PHONE_NUMBER=+15551234567

# Stripe
STRIPE_SECRET_KEY=sk_live_...
```

## Configuration

Copy `config.example.json` to `config.json` and customize:

- **business** — Your business name, type, address, hours
- **competitors** — Businesses to monitor (with platform IDs)
- **review_response** — Default tone, auto-respond settings, guidelines
- **social_content** — Specialty, posting times, hashtags
- **email_sequences** — Offer text for each sequence type
- **sms** — Opt-in/out keywords, welcome message
- **marketing_costs** — Ad spend, tools, content creation (for CAC calculation)

## Data Storage

All local state is stored in SQLite databases under `data/`:

- `data/reviews.db` — Review history, responses, alerts
- `data/competitors.db` — Competitor snapshots, alerts
- `data/email.db` — Subscribers, sequences, send history
- `data/sms.db` — SMS subscribers, message history

## Output Format

All scripts output JSON by default (compact). Use `--verbose` / `-v` for pretty-printed JSON with additional details and ASCII visualizations where applicable.
