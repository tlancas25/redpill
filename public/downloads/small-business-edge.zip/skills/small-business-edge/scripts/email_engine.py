#!/usr/bin/env python3
"""Email marketing automation engine for small businesses.

Provides sequence-based email automation with SendGrid integration,
subscriber segmentation, pre-built campaign templates, and analytics.
Supports welcome sequences, win-back campaigns, review requests,
referral programs, birthday greetings, and loyalty campaigns.

Usage:
    python3 email_engine.py create-sequence --name welcome --trigger signup --emails 3
    python3 email_engine.py broadcast --subject "Spring Sale!" --template seasonal --segment active
    python3 email_engine.py analytics
    python3 email_engine.py list-sequences
    python3 email_engine.py subscribers --action list --segment vip
"""

import argparse
import json
import os
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path

OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", os.path.expanduser("~/.openclaw"))
ENV_FILE = os.path.join(OPENCLAW_HOME, ".env")
SKILL_DIR = Path(__file__).resolve().parent.parent
CONFIG_FILE = SKILL_DIR / "config.json"
DB_PATH = SKILL_DIR / "data" / "email.db"

SEGMENTS = ["active", "lapsed", "new", "vip", "all"]
TRIGGERS = ["signup", "purchase", "inactive_7d", "inactive_30d", "review_request", "birthday", "referral"]

PRE_BUILT_SEQUENCES = {
    "welcome": {
        "trigger": "signup",
        "emails": [
            {"delay_days": 0, "subject": "Welcome to {biz_name}!", "template": "welcome_1",
             "body": "Hi {first_name},\n\nWelcome to {biz_name}! We're thrilled to have you join our community.\n\nHere's what you can expect from us:\n- Exclusive offers and promotions\n- New product/service announcements\n- Tips and helpful content\n\nAs a thank you for joining, here's a special welcome offer: {welcome_offer}\n\nSee you soon!\n{biz_name} Team"},
            {"delay_days": 3, "subject": "Getting the most from {biz_name}", "template": "welcome_2",
             "body": "Hi {first_name},\n\nWe hope you're settling in! Here are some tips to get the most from {biz_name}:\n\n1. Follow us on social media for daily updates\n2. Check out our most popular offerings\n3. Leave us a review to help others discover us\n\nQuestions? Just reply to this email!\n\nBest,\n{biz_name} Team"},
            {"delay_days": 7, "subject": "Your exclusive {biz_name} offer expires soon", "template": "welcome_3",
             "body": "Hi {first_name},\n\nJust a friendly reminder -- your welcome offer is expiring soon!\n\n{welcome_offer}\n\nDon't miss out. Visit us today!\n\n{biz_name} Team"},
        ],
    },
    "win-back": {
        "trigger": "inactive_30d",
        "emails": [
            {"delay_days": 0, "subject": "We miss you, {first_name}!", "template": "winback_1",
             "body": "Hi {first_name},\n\nIt's been a while since we've seen you at {biz_name}, and we miss you!\n\nA lot has changed since your last visit. Come check out what's new.\n\nAs a special incentive, here's an offer just for you: {winback_offer}\n\nHope to see you soon!\n{biz_name} Team"},
            {"delay_days": 7, "subject": "Last chance: Special offer from {biz_name}", "template": "winback_2",
             "body": "Hi {first_name},\n\nYour special come-back offer expires in 48 hours!\n\n{winback_offer}\n\nWe'd love to welcome you back.\n\n{biz_name} Team"},
        ],
    },
    "review-request": {
        "trigger": "purchase",
        "emails": [
            {"delay_days": 2, "subject": "How was your experience at {biz_name}?", "template": "review_1",
             "body": "Hi {first_name},\n\nThank you for choosing {biz_name}! We hope you had a great experience.\n\nWould you mind leaving us a quick review? It only takes 30 seconds and helps other customers find us.\n\n{review_link}\n\nThank you so much!\n{biz_name} Team"},
        ],
    },
    "referral": {
        "trigger": "purchase",
        "emails": [
            {"delay_days": 5, "subject": "Share the love -- refer a friend to {biz_name}!", "template": "referral_1",
             "body": "Hi {first_name},\n\nLoving {biz_name}? Share the experience with friends and family!\n\nFor every friend you refer, you'll both receive: {referral_offer}\n\nSimply share this link: {referral_link}\n\nThank you for spreading the word!\n{biz_name} Team"},
        ],
    },
    "birthday": {
        "trigger": "birthday",
        "emails": [
            {"delay_days": 0, "subject": "Happy Birthday, {first_name}! A gift from {biz_name}", "template": "birthday_1",
             "body": "Hi {first_name},\n\nHappy Birthday from all of us at {biz_name}!\n\nTo celebrate your special day, we have a gift for you: {birthday_offer}\n\nEnjoy your day!\n{biz_name} Team"},
        ],
    },
    "loyalty": {
        "trigger": "purchase",
        "emails": [
            {"delay_days": 0, "subject": "Thank you for being a loyal {biz_name} customer!", "template": "loyalty_1",
             "body": "Hi {first_name},\n\nWe noticed you've been a regular at {biz_name} and we want to say THANK YOU!\n\nAs a token of our appreciation: {loyalty_offer}\n\nYou're part of the {biz_name} family, and we're grateful for your continued support.\n\nWith gratitude,\n{biz_name} Team"},
        ],
    },
}


def load_env():
    """Load environment variables from .env file."""
    env = os.environ.copy()
    if os.path.exists(ENV_FILE):
        with open(ENV_FILE, "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    env[key.strip()] = value.strip().strip("\"'")
    return env


def load_config():
    """Load skill configuration."""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def ensure_db():
    """Initialize the email marketing SQLite database."""
    os.makedirs(DB_PATH.parent, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS subscribers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            first_name TEXT,
            last_name TEXT,
            segment TEXT DEFAULT 'new',
            birthday TEXT,
            subscribed_at TEXT NOT NULL,
            unsubscribed_at TEXT,
            status TEXT DEFAULT 'active'
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sequences (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            trigger_event TEXT NOT NULL,
            email_count INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            active INTEGER DEFAULT 1
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sequence_emails (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sequence_id INTEGER NOT NULL,
            position INTEGER NOT NULL,
            delay_days INTEGER NOT NULL,
            subject TEXT NOT NULL,
            template TEXT NOT NULL,
            body TEXT NOT NULL,
            FOREIGN KEY (sequence_id) REFERENCES sequences(id)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sends (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subscriber_id INTEGER,
            sequence_id INTEGER,
            email_subject TEXT NOT NULL,
            sent_at TEXT NOT NULL,
            opened INTEGER DEFAULT 0,
            clicked INTEGER DEFAULT 0,
            unsubscribed INTEGER DEFAULT 0,
            sendgrid_message_id TEXT,
            send_type TEXT DEFAULT 'sequence'
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_subscribers_segment ON subscribers(segment)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sends_date ON sends(sent_at)")
    conn.commit()
    return conn


def send_email_sendgrid(env, to_email, subject, body, from_name=None):
    """Send an email via SendGrid API."""
    import requests

    api_key = env.get("SENDGRID_API_KEY")
    from_email = env.get("SENDGRID_FROM_EMAIL", "noreply@example.com")
    from_name = from_name or env.get("SENDGRID_FROM_NAME", "Business")

    if not api_key:
        return {"error": "Missing SENDGRID_API_KEY"}

    payload = {
        "personalizations": [{"to": [{"email": to_email}]}],
        "from": {"email": from_email, "name": from_name},
        "subject": subject,
        "content": [{"type": "text/plain", "value": body}],
    }

    try:
        resp = requests.post(
            "https://api.sendgrid.com/v3/mail/send",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json=payload,
            timeout=15,
        )
        if resp.status_code in (200, 201, 202):
            msg_id = resp.headers.get("X-Message-Id", "")
            return {"success": True, "message_id": msg_id}
        else:
            return {"error": f"SendGrid error: {resp.status_code} {resp.text[:200]}"}
    except Exception as e:
        return {"error": f"SendGrid request failed: {str(e)}"}


def cmd_create_sequence(args, env, config):
    """Create or install an email sequence."""
    conn = ensure_db()
    name = args.name
    now = datetime.utcnow().isoformat()

    # Check if it's a pre-built sequence
    if name in PRE_BUILT_SEQUENCES:
        template = PRE_BUILT_SEQUENCES[name]
        trigger = template["trigger"]
        emails = template["emails"]
    else:
        trigger = args.trigger or "signup"
        email_count = args.emails or 3
        emails = []
        for i in range(email_count):
            emails.append({
                "delay_days": i * 3,
                "subject": f"{name} email {i + 1}",
                "template": f"{name}_{i + 1}",
                "body": f"Email {i + 1} in the {name} sequence. Customize this content in config.json.",
            })

    # Check for existing sequence
    existing = conn.execute("SELECT id FROM sequences WHERE name = ?", (name,)).fetchone()
    if existing:
        print(json.dumps({"success": False, "error": f"Sequence '{name}' already exists"}))
        conn.close()
        return

    conn.execute(
        "INSERT INTO sequences (name, trigger_event, email_count, created_at) VALUES (?, ?, ?, ?)",
        (name, trigger, len(emails), now)
    )
    seq_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    for i, email in enumerate(emails):
        conn.execute(
            "INSERT INTO sequence_emails (sequence_id, position, delay_days, subject, template, body) VALUES (?, ?, ?, ?, ?, ?)",
            (seq_id, i + 1, email["delay_days"], email["subject"], email["template"], email["body"])
        )

    conn.commit()
    conn.close()

    output = {
        "success": True,
        "sequence": name,
        "trigger": trigger,
        "emails": len(emails),
        "pre_built": name in PRE_BUILT_SEQUENCES,
    }
    if args.verbose:
        output["email_schedule"] = [
            {"position": i + 1, "delay_days": e["delay_days"], "subject": e["subject"]}
            for i, e in enumerate(emails)
        ]
    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_broadcast(args, env, config):
    """Send a broadcast email to a subscriber segment."""
    conn = ensure_db()
    biz_name = config.get("business", {}).get("name", "Our Business")
    subject = args.subject
    segment = args.segment or "all"

    # Get subscribers in segment
    if segment == "all":
        rows = conn.execute("SELECT id, email, first_name FROM subscribers WHERE status = 'active'").fetchall()
    else:
        rows = conn.execute(
            "SELECT id, email, first_name FROM subscribers WHERE status = 'active' AND segment = ?",
            (segment,)
        ).fetchall()

    if not rows:
        print(json.dumps({"success": False, "error": f"No active subscribers in segment '{segment}'"}))
        conn.close()
        return

    # Build email body from template or custom content
    body_template = args.body or f"Hello from {biz_name}!\n\nWe have exciting news to share with you.\n\nBest regards,\n{biz_name} Team"

    sent_count = 0
    errors = []
    now = datetime.utcnow().isoformat()

    for sub_id, email, first_name in rows:
        personalized_subject = subject.replace("{first_name}", first_name or "Valued Customer")
        personalized_body = body_template.replace("{first_name}", first_name or "Valued Customer").replace("{biz_name}", biz_name)

        result = send_email_sendgrid(env, email, personalized_subject, personalized_body, biz_name)
        if result.get("success"):
            conn.execute(
                "INSERT INTO sends (subscriber_id, email_subject, sent_at, sendgrid_message_id, send_type) VALUES (?, ?, ?, ?, ?)",
                (sub_id, personalized_subject, now, result.get("message_id", ""), "broadcast")
            )
            sent_count += 1
        else:
            errors.append({"email": email, "error": result.get("error", "Unknown error")})

    conn.commit()
    conn.close()

    output = {
        "success": True,
        "segment": segment,
        "total_recipients": len(rows),
        "sent": sent_count,
        "failed": len(errors),
    }
    if args.verbose and errors:
        output["errors"] = errors
    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_analytics(args, env, config):
    """Show email marketing analytics."""
    conn = ensure_db()

    total_subs = conn.execute("SELECT COUNT(*) FROM subscribers WHERE status = 'active'").fetchone()[0]
    total_unsubs = conn.execute("SELECT COUNT(*) FROM subscribers WHERE status = 'unsubscribed'").fetchone()[0]

    # Segment breakdown
    segments = conn.execute(
        "SELECT segment, COUNT(*) FROM subscribers WHERE status = 'active' GROUP BY segment"
    ).fetchall()

    # Send stats (last 30 days)
    cutoff = (datetime.utcnow() - timedelta(days=30)).isoformat()
    total_sent = conn.execute("SELECT COUNT(*) FROM sends WHERE sent_at >= ?", (cutoff,)).fetchone()[0]
    total_opened = conn.execute("SELECT COUNT(*) FROM sends WHERE sent_at >= ? AND opened = 1", (cutoff,)).fetchone()[0]
    total_clicked = conn.execute("SELECT COUNT(*) FROM sends WHERE sent_at >= ? AND clicked = 1", (cutoff,)).fetchone()[0]
    total_unsub_sends = conn.execute("SELECT COUNT(*) FROM sends WHERE sent_at >= ? AND unsubscribed = 1", (cutoff,)).fetchone()[0]

    open_rate = round(total_opened / total_sent * 100, 1) if total_sent > 0 else 0
    click_rate = round(total_clicked / total_sent * 100, 1) if total_sent > 0 else 0
    unsub_rate = round(total_unsub_sends / total_sent * 100, 1) if total_sent > 0 else 0

    # Active sequences
    active_seqs = conn.execute("SELECT COUNT(*) FROM sequences WHERE active = 1").fetchone()[0]

    output = {
        "success": True,
        "period": "30d",
        "subscribers": {
            "active": total_subs,
            "unsubscribed": total_unsubs,
            "segments": {s[0]: s[1] for s in segments},
        },
        "sends": {
            "total": total_sent,
            "open_rate": open_rate,
            "click_rate": click_rate,
            "unsubscribe_rate": unsub_rate,
        },
        "active_sequences": active_seqs,
    }

    conn.close()
    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_list_sequences(args, env, config):
    """List all email sequences."""
    conn = ensure_db()
    rows = conn.execute(
        "SELECT id, name, trigger_event, email_count, active, created_at FROM sequences ORDER BY created_at DESC"
    ).fetchall()

    sequences = []
    for row in rows:
        seq = {
            "id": row[0], "name": row[1], "trigger": row[2],
            "emails": row[3], "active": bool(row[4]), "created_at": row[5],
        }
        if args.verbose:
            emails = conn.execute(
                "SELECT position, delay_days, subject FROM sequence_emails WHERE sequence_id = ? ORDER BY position",
                (row[0],)
            ).fetchall()
            seq["email_schedule"] = [
                {"position": e[0], "delay_days": e[1], "subject": e[2]}
                for e in emails
            ]
        sequences.append(seq)

    conn.close()
    output = {"success": True, "total_sequences": len(sequences), "sequences": sequences}
    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_subscribers(args, env, config):
    """Manage email subscribers."""
    conn = ensure_db()
    action = args.action
    now = datetime.utcnow().isoformat()

    if action == "add":
        if not args.email:
            print(json.dumps({"success": False, "error": "Email required for add action (use --email)"}))
            conn.close()
            return
        try:
            conn.execute(
                "INSERT INTO subscribers (email, first_name, last_name, segment, subscribed_at) VALUES (?, ?, ?, ?, ?)",
                (args.email, args.first_name or "", args.last_name or "", args.segment or "new", now)
            )
            conn.commit()
            print(json.dumps({"success": True, "action": "added", "email": args.email, "segment": args.segment or "new"}))
        except sqlite3.IntegrityError:
            print(json.dumps({"success": False, "error": f"Subscriber {args.email} already exists"}))

    elif action == "remove":
        if not args.email:
            print(json.dumps({"success": False, "error": "Email required for remove action (use --email)"}))
            conn.close()
            return
        conn.execute(
            "UPDATE subscribers SET status = 'unsubscribed', unsubscribed_at = ? WHERE email = ?",
            (now, args.email)
        )
        conn.commit()
        print(json.dumps({"success": True, "action": "unsubscribed", "email": args.email}))

    elif action == "list":
        segment = args.segment
        if segment and segment != "all":
            rows = conn.execute(
                "SELECT email, first_name, segment, status, subscribed_at FROM subscribers WHERE segment = ? AND status = 'active' ORDER BY subscribed_at DESC",
                (segment,)
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT email, first_name, segment, status, subscribed_at FROM subscribers WHERE status = 'active' ORDER BY subscribed_at DESC"
            ).fetchall()

        subs = [{"email": r[0], "first_name": r[1], "segment": r[2], "status": r[3], "subscribed_at": r[4]} for r in rows]
        output = {"success": True, "total": len(subs)}
        if args.verbose:
            output["subscribers"] = subs
        else:
            output["subscribers"] = [{"email": s["email"], "segment": s["segment"]} for s in subs]
        print(json.dumps(output, indent=2 if args.verbose else None))

    conn.close()


def main():
    parser = argparse.ArgumentParser(
        description="Email marketing automation engine for small businesses"
    )
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output with full details")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # create-sequence
    cs = subparsers.add_parser("create-sequence", help="Create an email sequence")
    cs.add_argument("--name", required=True,
                    help=f"Sequence name (pre-built: {', '.join(PRE_BUILT_SEQUENCES.keys())})")
    cs.add_argument("--trigger", choices=TRIGGERS, help="Trigger event for the sequence")
    cs.add_argument("--emails", type=int, help="Number of emails in custom sequence")

    # broadcast
    bc = subparsers.add_parser("broadcast", help="Send a broadcast email")
    bc.add_argument("--subject", required=True, help="Email subject line")
    bc.add_argument("--template", help="Email template name")
    bc.add_argument("--segment", choices=SEGMENTS, default="all", help="Target subscriber segment")
    bc.add_argument("--body", help="Email body text (overrides template)")

    # analytics
    subparsers.add_parser("analytics", help="Show email marketing analytics")

    # list-sequences
    subparsers.add_parser("list-sequences", help="List all email sequences")

    # subscribers
    sub_p = subparsers.add_parser("subscribers", help="Manage subscribers")
    sub_p.add_argument("--action", required=True, choices=["add", "remove", "list"], help="Subscriber action")
    sub_p.add_argument("--email", help="Subscriber email address")
    sub_p.add_argument("--first-name", help="Subscriber first name")
    sub_p.add_argument("--last-name", help="Subscriber last name")
    sub_p.add_argument("--segment", choices=SEGMENTS, help="Subscriber segment")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    env = load_env()
    config = load_config()

    commands = {
        "create-sequence": cmd_create_sequence,
        "broadcast": cmd_broadcast,
        "analytics": cmd_analytics,
        "list-sequences": cmd_list_sequences,
        "subscribers": cmd_subscribers,
    }
    commands[args.command](args, env, config)


if __name__ == "__main__":
    main()
