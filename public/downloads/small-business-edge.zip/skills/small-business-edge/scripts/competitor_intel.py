#!/usr/bin/env python3
"""Competitive intelligence monitoring for small businesses.

Tracks competitor Google/Yelp ratings, review counts, and social media
activity over time. Generates comparison reports, detects opportunities
(competitor inactive, ratings dropping), and provides actionable alerts.

Usage:
    python3 competitor_intel.py track --competitor "Rival Cafe" --platforms google,yelp
    python3 competitor_intel.py report
    python3 competitor_intel.py compare
    python3 competitor_intel.py alerts
"""

import argparse
import json
import os
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path

OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", os.path.expanduser("~/.openclaw"))
ENV_FILE = os.path.join(OPENCLAW_HOME, ".env")
SKILL_DIR = Path(__file__).resolve().parent.parent
CONFIG_FILE = SKILL_DIR / "config.json"
DB_PATH = SKILL_DIR / "data" / "competitors.db"
REVIEWS_DB = SKILL_DIR / "data" / "reviews.db"

SUPPORTED_PLATFORMS = ["google", "yelp", "x"]


def load_env():
    """Load environment variables from .env file."""
    env = os.environ.copy()
    if os.path.exists(ENV_FILE):
        with open(ENV_FILE, "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    env[key.strip()] = value.strip().strip("\"'")
    return env


def load_config():
    """Load skill configuration."""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def ensure_db():
    """Initialize the competitors SQLite database."""
    os.makedirs(DB_PATH.parent, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS competitors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            google_place_id TEXT,
            yelp_business_id TEXT,
            x_handle TEXT,
            added_at TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS competitor_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            platform TEXT NOT NULL,
            avg_rating REAL,
            review_count INTEGER,
            followers INTEGER,
            tweet_count INTEGER,
            timestamp TEXT NOT NULL,
            FOREIGN KEY (name) REFERENCES competitors(name)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS competitor_alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            competitor_name TEXT NOT NULL,
            alert_type TEXT NOT NULL,
            message TEXT NOT NULL,
            created_at TEXT NOT NULL,
            acknowledged INTEGER DEFAULT 0
        )
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_snapshots_name_ts
        ON competitor_snapshots(name, timestamp)
    """)
    conn.commit()
    return conn


def fetch_google_place_rating(env, place_id):
    """Fetch rating and review count from Google Places API."""
    import requests

    api_key = env.get("GOOGLE_PLACES_API_KEY")
    if not api_key or not place_id:
        return None

    try:
        resp = requests.get(
            "https://maps.googleapis.com/maps/api/place/details/json",
            params={"place_id": place_id, "fields": "rating,user_ratings_total,name", "key": api_key},
            timeout=15,
        )
        resp.raise_for_status()
        result = resp.json().get("result", {})
        return {
            "avg_rating": result.get("rating", 0),
            "review_count": result.get("user_ratings_total", 0),
        }
    except Exception as e:
        return {"error": str(e)}


def fetch_yelp_business_rating(env, business_id):
    """Fetch rating and review count from Yelp Fusion API."""
    import requests

    api_key = env.get("YELP_API_KEY")
    if not api_key or not business_id:
        return None

    try:
        resp = requests.get(
            f"https://api.yelp.com/v3/businesses/{business_id}",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
        return {
            "avg_rating": data.get("rating", 0),
            "review_count": data.get("review_count", 0),
        }
    except Exception as e:
        return {"error": str(e)}


def fetch_x_profile(env, handle):
    """Fetch follower count and tweet count from X API."""
    import requests

    bearer = env.get("X_BEARER_TOKEN")
    if not bearer or not handle:
        return None

    try:
        resp = requests.get(
            f"https://api.twitter.com/2/users/by/username/{handle}",
            headers={"Authorization": f"Bearer {bearer}"},
            params={"user.fields": "public_metrics"},
            timeout=15,
        )
        resp.raise_for_status()
        metrics = resp.json().get("data", {}).get("public_metrics", {})
        return {
            "followers": metrics.get("followers_count", 0),
            "tweet_count": metrics.get("tweet_count", 0),
        }
    except Exception as e:
        return {"error": str(e)}


def detect_opportunities(conn, competitor_name):
    """Detect competitive opportunities from historical data."""
    alerts = []
    now = datetime.utcnow().isoformat()

    # Check for rating drops (compare last 2 snapshots)
    rows = conn.execute(
        "SELECT avg_rating, timestamp FROM competitor_snapshots WHERE name = ? ORDER BY timestamp DESC LIMIT 2",
        (competitor_name,)
    ).fetchall()

    if len(rows) == 2:
        current_rating = rows[0][0] or 0
        previous_rating = rows[1][0] or 0
        if previous_rating > 0 and current_rating < previous_rating - 0.2:
            msg = f"{competitor_name} rating dropped from {previous_rating} to {current_rating}"
            alerts.append(("rating_drop", msg))

    # Check for inactivity (no new snapshots in 14+ days for social)
    last_social = conn.execute(
        "SELECT timestamp FROM competitor_snapshots WHERE name = ? AND platform = 'x' ORDER BY timestamp DESC LIMIT 1",
        (competitor_name,)
    ).fetchone()

    if last_social:
        last_date = datetime.fromisoformat(last_social[0])
        if (datetime.utcnow() - last_date).days > 14:
            alerts.append(("inactive_social", f"{competitor_name} has been inactive on social media for 14+ days"))

    # Store new alerts
    for alert_type, message in alerts:
        existing = conn.execute(
            "SELECT id FROM competitor_alerts WHERE competitor_name = ? AND alert_type = ? AND acknowledged = 0",
            (competitor_name, alert_type)
        ).fetchone()
        if not existing:
            conn.execute(
                "INSERT INTO competitor_alerts (competitor_name, alert_type, message, created_at) VALUES (?, ?, ?, ?)",
                (competitor_name, alert_type, message, now)
            )

    return alerts


def cmd_track(args, env, config):
    """Track a competitor's current metrics."""
    conn = ensure_db()
    name = args.competitor
    platforms = [p.strip() for p in args.platforms.split(",")]
    now = datetime.utcnow().isoformat()

    # Ensure competitor exists in the database
    existing = conn.execute("SELECT id FROM competitors WHERE name = ?", (name,)).fetchone()
    if not existing:
        conn.execute(
            "INSERT INTO competitors (name, added_at) VALUES (?, ?)",
            (name, now)
        )

    results = {}
    for platform in platforms:
        if platform == "google":
            # Look up place_id from config or competitor record
            comp_config = next(
                (c for c in config.get("competitors", [])
                 if (isinstance(c, dict) and c.get("name") == name) or c == name),
                {}
            )
            place_id = comp_config.get("google_place_id") if isinstance(comp_config, dict) else None
            if place_id:
                data = fetch_google_place_rating(env, place_id)
                if data and "error" not in data:
                    conn.execute(
                        "INSERT INTO competitor_snapshots (name, platform, avg_rating, review_count, timestamp) VALUES (?, ?, ?, ?, ?)",
                        (name, "google", data["avg_rating"], data["review_count"], now)
                    )
                    results["google"] = data
                else:
                    results["google"] = data or {"error": "No place_id configured"}
            else:
                results["google"] = {"error": "No google_place_id configured for this competitor"}

        elif platform == "yelp":
            comp_config = next(
                (c for c in config.get("competitors", [])
                 if isinstance(c, dict) and c.get("name") == name),
                {}
            )
            biz_id = comp_config.get("yelp_business_id") if isinstance(comp_config, dict) else None
            if biz_id:
                data = fetch_yelp_business_rating(env, biz_id)
                if data and "error" not in data:
                    conn.execute(
                        "INSERT INTO competitor_snapshots (name, platform, avg_rating, review_count, timestamp) VALUES (?, ?, ?, ?, ?)",
                        (name, "yelp", data["avg_rating"], data["review_count"], now)
                    )
                    results["yelp"] = data
                else:
                    results["yelp"] = data or {"error": "No yelp_business_id configured"}
            else:
                results["yelp"] = {"error": "No yelp_business_id configured for this competitor"}

        elif platform == "x":
            comp_config = next(
                (c for c in config.get("competitors", [])
                 if isinstance(c, dict) and c.get("name") == name),
                {}
            )
            handle = comp_config.get("x_handle") if isinstance(comp_config, dict) else None
            if handle:
                data = fetch_x_profile(env, handle)
                if data and "error" not in data:
                    conn.execute(
                        "INSERT INTO competitor_snapshots (name, platform, followers, tweet_count, timestamp) VALUES (?, ?, ?, ?, ?)",
                        (name, "x", data["followers"], data["tweet_count"], now)
                    )
                    results["x"] = data
                else:
                    results["x"] = data or {"error": "No x_handle configured"}
            else:
                results["x"] = {"error": "No x_handle configured for this competitor"}

    # Detect opportunities
    opportunities = detect_opportunities(conn, name)
    conn.commit()
    conn.close()

    output = {
        "success": True,
        "competitor": name,
        "platforms_tracked": platforms,
        "results": results,
        "opportunities_detected": len(opportunities),
    }
    if args.verbose and opportunities:
        output["opportunities"] = [{"type": o[0], "message": o[1]} for o in opportunities]

    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_report(args, env, config):
    """Generate a competitor intelligence report."""
    conn = ensure_db()
    competitors = conn.execute("SELECT name FROM competitors ORDER BY name").fetchall()

    if not competitors:
        print(json.dumps({"success": False, "error": "No competitors being tracked. Use 'track' first."}))
        conn.close()
        return

    report = []
    for (name,) in competitors:
        latest = {}
        for platform in SUPPORTED_PLATFORMS:
            row = conn.execute(
                "SELECT avg_rating, review_count, followers, tweet_count, timestamp "
                "FROM competitor_snapshots WHERE name = ? AND platform = ? ORDER BY timestamp DESC LIMIT 1",
                (name, platform)
            ).fetchone()
            if row:
                latest[platform] = {
                    "avg_rating": row[0], "review_count": row[1],
                    "followers": row[2], "tweet_count": row[3],
                    "last_updated": row[4],
                }

        # Historical trend (30 days)
        thirty_days_ago = (datetime.utcnow() - timedelta(days=30)).isoformat()
        old_snapshot = conn.execute(
            "SELECT avg_rating, review_count FROM competitor_snapshots "
            "WHERE name = ? AND timestamp <= ? ORDER BY timestamp DESC LIMIT 1",
            (name, thirty_days_ago)
        ).fetchone()

        trend = None
        if old_snapshot and latest.get("google"):
            old_rating = old_snapshot[0] or 0
            new_rating = latest["google"].get("avg_rating", 0) or 0
            if old_rating > 0:
                trend = {
                    "rating_change": round(new_rating - old_rating, 2),
                    "direction": "improving" if new_rating > old_rating else ("declining" if new_rating < old_rating else "stable"),
                }

        report.append({"name": name, "platforms": latest, "trend": trend})

    conn.close()
    output = {"success": True, "competitors_tracked": len(report), "report": report}
    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_compare(args, env, config):
    """Compare your business against tracked competitors."""
    conn = ensure_db()

    # Get your stats
    my_stats = {"avg_rating": 0, "total_reviews": 0}
    if REVIEWS_DB.exists():
        rconn = sqlite3.connect(str(REVIEWS_DB))
        try:
            row = rconn.execute("SELECT AVG(rating), COUNT(*) FROM reviews").fetchone()
            my_stats = {"avg_rating": round(row[0] or 0, 2), "total_reviews": row[1]}
        except sqlite3.OperationalError:
            pass
        finally:
            rconn.close()

    # Get competitor stats
    competitors = conn.execute("SELECT name FROM competitors ORDER BY name").fetchall()
    comparison = []
    for (name,) in competitors:
        row = conn.execute(
            "SELECT avg_rating, review_count FROM competitor_snapshots "
            "WHERE name = ? AND avg_rating IS NOT NULL ORDER BY timestamp DESC LIMIT 1",
            (name,)
        ).fetchone()
        if row:
            rating_diff = round(my_stats["avg_rating"] - (row[0] or 0), 2)
            comparison.append({
                "name": name,
                "avg_rating": row[0],
                "review_count": row[1],
                "rating_vs_you": rating_diff,
                "status": "you lead" if rating_diff > 0 else ("they lead" if rating_diff < 0 else "tied"),
            })
        else:
            comparison.append({"name": name, "data": "insufficient data"})

    conn.close()

    output = {
        "success": True,
        "your_rating": my_stats["avg_rating"],
        "your_reviews": my_stats["total_reviews"],
        "competitors": comparison,
    }

    if args.verbose:
        print("\n  YOU vs COMPETITORS")
        print("  " + "=" * 50)
        print(f"  {'You':<20} ★ {my_stats['avg_rating']:.1f}  ({my_stats['total_reviews']} reviews)")
        for c in comparison:
            if "data" in c:
                print(f"  {c['name']:<20} (no data)")
            else:
                indicator = "▲" if c["rating_vs_you"] > 0 else ("▼" if c["rating_vs_you"] < 0 else "=")
                print(f"  {c['name']:<20} ★ {c['avg_rating']:.1f}  ({c['review_count']} reviews)  {indicator} {c['status']}")
        print()

    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_alerts(args, env, config):
    """Show competitive intelligence alerts."""
    conn = ensure_db()
    rows = conn.execute(
        "SELECT id, competitor_name, alert_type, message, created_at "
        "FROM competitor_alerts WHERE acknowledged = 0 ORDER BY created_at DESC"
    ).fetchall()

    alerts_list = [
        {"id": r[0], "competitor": r[1], "type": r[2], "message": r[3], "created_at": r[4]}
        for r in rows
    ]

    output = {
        "success": True,
        "unacknowledged_alerts": len(alerts_list),
    }
    if args.verbose:
        output["alerts"] = alerts_list
    else:
        output["alerts"] = [{"id": a["id"], "competitor": a["competitor"], "type": a["type"]} for a in alerts_list]

    conn.close()
    print(json.dumps(output, indent=2 if args.verbose else None))


def main():
    parser = argparse.ArgumentParser(
        description="Competitive intelligence monitoring for small businesses"
    )
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output with full details")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # track
    track_p = subparsers.add_parser("track", help="Track a competitor's current metrics")
    track_p.add_argument("--competitor", required=True, help="Competitor business name")
    track_p.add_argument("--platforms", default="google,yelp", help="Platforms to track (default: google,yelp)")

    # report
    subparsers.add_parser("report", help="Generate competitor intelligence report")

    # compare
    subparsers.add_parser("compare", help="Compare your business against competitors")

    # alerts
    subparsers.add_parser("alerts", help="Show competitive intelligence alerts")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    env = load_env()
    config = load_config()

    commands = {
        "track": cmd_track,
        "report": cmd_report,
        "compare": cmd_compare,
        "alerts": cmd_alerts,
    }
    commands[args.command](args, env, config)


if __name__ == "__main__":
    main()
