#!/usr/bin/env python3
"""SMS notification system for small businesses.

Provides SMS messaging via Twilio with opt-in/opt-out management,
segment-based blasts, delivery tracking, and compliance features.
All subscriber and delivery data is persisted in SQLite.

Usage:
    python3 sms_engine.py send --to +15551234567 --message "Your order is ready!"
    python3 sms_engine.py blast --segment vip --message "Exclusive VIP sale this weekend!"
    python3 sms_engine.py opt-in --phone +15551234567 --name "John Doe"
    python3 sms_engine.py opt-out --phone +15551234567
    python3 sms_engine.py stats
"""

import argparse
import json
import os
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path

OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", os.path.expanduser("~/.openclaw"))
ENV_FILE = os.path.join(OPENCLAW_HOME, ".env")
SKILL_DIR = Path(__file__).resolve().parent.parent
CONFIG_FILE = SKILL_DIR / "config.json"
DB_PATH = SKILL_DIR / "data" / "sms.db"

VALID_SEGMENTS = ["all", "vip", "new", "active", "lapsed"]


def load_env():
    """Load environment variables from .env file."""
    env = os.environ.copy()
    if os.path.exists(ENV_FILE):
        with open(ENV_FILE, "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    env[key.strip()] = value.strip().strip("\"'")
    return env


def load_config():
    """Load skill configuration."""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def ensure_db():
    """Initialize the SMS SQLite database."""
    os.makedirs(DB_PATH.parent, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sms_subscribers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone TEXT NOT NULL UNIQUE,
            name TEXT,
            segment TEXT DEFAULT 'new',
            opted_in_at TEXT NOT NULL,
            opted_out_at TEXT,
            status TEXT DEFAULT 'active'
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sms_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subscriber_id INTEGER,
            phone TEXT NOT NULL,
            message TEXT NOT NULL,
            direction TEXT DEFAULT 'outbound',
            twilio_sid TEXT,
            status TEXT DEFAULT 'queued',
            sent_at TEXT NOT NULL,
            delivered_at TEXT,
            send_type TEXT DEFAULT 'single'
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sms_subs_phone ON sms_subscribers(phone)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sms_msgs_date ON sms_messages(sent_at)")
    conn.commit()
    return conn


def send_sms_twilio(env, to_phone, message):
    """Send an SMS message via Twilio API."""
    import requests

    account_sid = env.get("TWILIO_ACCOUNT_SID")
    auth_token = env.get("TWILIO_AUTH_TOKEN")
    from_phone = env.get("TWILIO_PHONE_NUMBER")

    if not all([account_sid, auth_token, from_phone]):
        return {"error": "Missing TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, or TWILIO_PHONE_NUMBER"}

    url = f"https://api.twilio.com/2010-04-01/Accounts/{account_sid}/Messages.json"

    try:
        resp = requests.post(
            url,
            auth=(account_sid, auth_token),
            data={"To": to_phone, "From": from_phone, "Body": message},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
        return {
            "success": True,
            "sid": data.get("sid", ""),
            "status": data.get("status", "queued"),
        }
    except Exception as e:
        return {"error": f"Twilio error: {str(e)}"}


def cmd_send(args, env, config):
    """Send a single SMS message."""
    conn = ensure_db()
    phone = args.to
    message = args.message
    now = datetime.utcnow().isoformat()

    # Check if recipient is opted in
    sub = conn.execute(
        "SELECT id, status FROM sms_subscribers WHERE phone = ?", (phone,)
    ).fetchone()

    if sub and sub[1] != "active":
        print(json.dumps({"success": False, "error": f"Recipient {phone} has opted out of SMS"}))
        conn.close()
        return

    result = send_sms_twilio(env, phone, message)

    if result.get("success"):
        conn.execute(
            "INSERT INTO sms_messages (subscriber_id, phone, message, twilio_sid, status, sent_at, send_type) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (sub[0] if sub else None, phone, message, result.get("sid", ""),
             result.get("status", "queued"), now, "single")
        )
        conn.commit()
        output = {"success": True, "to": phone, "sid": result.get("sid", ""), "status": result.get("status", "")}
    else:
        output = {"success": False, "error": result.get("error", "Unknown error")}

    conn.close()
    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_blast(args, env, config):
    """Send an SMS blast to a subscriber segment."""
    conn = ensure_db()
    segment = args.segment or "all"
    message = args.message
    now = datetime.utcnow().isoformat()

    if segment == "all":
        rows = conn.execute(
            "SELECT id, phone, name FROM sms_subscribers WHERE status = 'active'"
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT id, phone, name FROM sms_subscribers WHERE status = 'active' AND segment = ?",
            (segment,)
        ).fetchall()

    if not rows:
        print(json.dumps({"success": False, "error": f"No active subscribers in segment '{segment}'"}))
        conn.close()
        return

    sent_count = 0
    failed_count = 0
    errors = []

    for sub_id, phone, name in rows:
        personalized = message.replace("{name}", name or "Valued Customer")
        result = send_sms_twilio(env, phone, personalized)

        if result.get("success"):
            conn.execute(
                "INSERT INTO sms_messages (subscriber_id, phone, message, twilio_sid, status, sent_at, send_type) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (sub_id, phone, personalized, result.get("sid", ""),
                 result.get("status", "queued"), now, "blast")
            )
            sent_count += 1
        else:
            failed_count += 1
            errors.append({"phone": phone, "error": result.get("error", "")})

    conn.commit()
    conn.close()

    output = {
        "success": True,
        "segment": segment,
        "total_recipients": len(rows),
        "sent": sent_count,
        "failed": failed_count,
    }
    if args.verbose and errors:
        output["errors"] = errors
    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_opt_in(args, env, config):
    """Opt a phone number into SMS notifications."""
    conn = ensure_db()
    phone = args.phone
    name = args.name or ""
    segment = args.segment or "new"
    now = datetime.utcnow().isoformat()

    existing = conn.execute("SELECT id, status FROM sms_subscribers WHERE phone = ?", (phone,)).fetchone()
    if existing:
        if existing[1] == "active":
            print(json.dumps({"success": False, "error": f"{phone} is already opted in"}))
        else:
            conn.execute(
                "UPDATE sms_subscribers SET status = 'active', opted_in_at = ?, opted_out_at = NULL WHERE phone = ?",
                (now, phone)
            )
            conn.commit()
            print(json.dumps({"success": True, "action": "re-opted-in", "phone": phone}))
    else:
        conn.execute(
            "INSERT INTO sms_subscribers (phone, name, segment, opted_in_at) VALUES (?, ?, ?, ?)",
            (phone, name, segment, now)
        )
        conn.commit()
        print(json.dumps({"success": True, "action": "opted-in", "phone": phone, "segment": segment}))

    conn.close()


def cmd_opt_out(args, env, config):
    """Opt a phone number out of SMS notifications."""
    conn = ensure_db()
    phone = args.phone
    now = datetime.utcnow().isoformat()

    existing = conn.execute("SELECT id FROM sms_subscribers WHERE phone = ?", (phone,)).fetchone()
    if not existing:
        print(json.dumps({"success": False, "error": f"{phone} is not in the subscriber list"}))
    else:
        conn.execute(
            "UPDATE sms_subscribers SET status = 'opted_out', opted_out_at = ? WHERE phone = ?",
            (now, phone)
        )
        conn.commit()
        print(json.dumps({"success": True, "action": "opted-out", "phone": phone}))

    conn.close()


def cmd_stats(args, env, config):
    """Show SMS messaging statistics."""
    conn = ensure_db()

    total_active = conn.execute("SELECT COUNT(*) FROM sms_subscribers WHERE status = 'active'").fetchone()[0]
    total_opted_out = conn.execute("SELECT COUNT(*) FROM sms_subscribers WHERE status = 'opted_out'").fetchone()[0]

    # Segment breakdown
    segments = conn.execute(
        "SELECT segment, COUNT(*) FROM sms_subscribers WHERE status = 'active' GROUP BY segment"
    ).fetchall()

    # Message stats (last 30 days)
    cutoff = (datetime.utcnow() - timedelta(days=30)).isoformat()
    total_sent = conn.execute("SELECT COUNT(*) FROM sms_messages WHERE sent_at >= ?", (cutoff,)).fetchone()[0]
    total_delivered = conn.execute(
        "SELECT COUNT(*) FROM sms_messages WHERE sent_at >= ? AND status = 'delivered'", (cutoff,)
    ).fetchone()[0]
    blasts = conn.execute(
        "SELECT COUNT(*) FROM sms_messages WHERE sent_at >= ? AND send_type = 'blast'", (cutoff,)
    ).fetchone()[0]
    singles = conn.execute(
        "SELECT COUNT(*) FROM sms_messages WHERE sent_at >= ? AND send_type = 'single'", (cutoff,)
    ).fetchone()[0]

    delivery_rate = round(total_delivered / total_sent * 100, 1) if total_sent > 0 else 0

    output = {
        "success": True,
        "period": "30d",
        "subscribers": {
            "active": total_active,
            "opted_out": total_opted_out,
            "segments": {s[0]: s[1] for s in segments},
        },
        "messages": {
            "total_sent": total_sent,
            "delivered": total_delivered,
            "delivery_rate": delivery_rate,
            "blasts": blasts,
            "singles": singles,
        },
    }

    conn.close()
    print(json.dumps(output, indent=2 if args.verbose else None))


def main():
    parser = argparse.ArgumentParser(
        description="SMS notification system for small businesses"
    )
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output with full details")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # send
    send_p = subparsers.add_parser("send", help="Send a single SMS")
    send_p.add_argument("--to", required=True, help="Recipient phone number (E.164 format)")
    send_p.add_argument("--message", required=True, help="Message text")

    # blast
    blast_p = subparsers.add_parser("blast", help="Send SMS blast to a segment")
    blast_p.add_argument("--segment", choices=VALID_SEGMENTS, default="all", help="Target segment")
    blast_p.add_argument("--message", required=True, help="Message text (use {name} for personalization)")

    # opt-in
    optin_p = subparsers.add_parser("opt-in", help="Opt in a phone number")
    optin_p.add_argument("--phone", required=True, help="Phone number (E.164 format)")
    optin_p.add_argument("--name", help="Subscriber name")
    optin_p.add_argument("--segment", choices=VALID_SEGMENTS, help="Subscriber segment")

    # opt-out
    optout_p = subparsers.add_parser("opt-out", help="Opt out a phone number")
    optout_p.add_argument("--phone", required=True, help="Phone number (E.164 format)")

    # stats
    subparsers.add_parser("stats", help="Show SMS messaging statistics")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    env = load_env()
    config = load_config()

    commands = {
        "send": cmd_send,
        "blast": cmd_blast,
        "opt-in": cmd_opt_in,
        "opt-out": cmd_opt_out,
        "stats": cmd_stats,
    }
    commands[args.command](args, env, config)


if __name__ == "__main__":
    main()
