#!/usr/bin/env python3
"""Unified business analytics dashboard for small businesses.

Aggregates data from revenue (Stripe), reputation (Google/Yelp reviews),
social media (X), leads, and email into a single dashboard view. Supports
ASCII-art display, trend analysis, competitor comparison, customer
acquisition cost calculation, and data export.

Usage:
    python3 biz_dashboard.py overview
    python3 biz_dashboard.py trends --metric revenue --period 30d
    python3 biz_dashboard.py competitors
    python3 biz_dashboard.py cac
    python3 biz_dashboard.py export --format json
"""

import argparse
import json
import os
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path

OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", os.path.expanduser("~/.openclaw"))
ENV_FILE = os.path.join(OPENCLAW_HOME, ".env")
SKILL_DIR = Path(__file__).resolve().parent.parent
CONFIG_FILE = SKILL_DIR / "config.json"
REVIEWS_DB = SKILL_DIR / "data" / "reviews.db"
COMPETITORS_DB = SKILL_DIR / "data" / "competitors.db"

VALID_METRICS = ["revenue", "reviews", "social", "leads", "email", "all"]
VALID_PERIODS = ["7d", "14d", "30d", "60d", "90d"]


def load_env():
    """Load environment variables from .env file."""
    env = os.environ.copy()
    if os.path.exists(ENV_FILE):
        with open(ENV_FILE, "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    env[key.strip()] = value.strip().strip("\"'")
    return env


def load_config():
    """Load skill configuration."""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def fetch_stripe_revenue(env, days=30):
    """Fetch revenue data from Stripe API."""
    import requests

    api_key = env.get("STRIPE_SECRET_KEY")
    if not api_key:
        return {"error": "Missing STRIPE_SECRET_KEY", "total": 0, "count": 0}

    cutoff = int((datetime.utcnow() - timedelta(days=days)).timestamp())
    try:
        resp = requests.get(
            "https://api.stripe.com/v1/charges",
            headers={"Authorization": f"Bearer {api_key}"},
            params={"created[gte]": cutoff, "limit": 100, "status": "succeeded"},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
        charges = data.get("data", [])
        total = sum(c.get("amount", 0) for c in charges) / 100.0
        return {"total": round(total, 2), "count": len(charges), "currency": "USD"}
    except Exception as e:
        return {"error": str(e), "total": 0, "count": 0}


def fetch_review_stats(days=30):
    """Fetch review statistics from local SQLite database."""
    if not REVIEWS_DB.exists():
        return {"total": 0, "avg_rating": 0, "positive": 0, "negative": 0, "unresponded": 0}

    cutoff = (datetime.utcnow() - timedelta(days=days)).isoformat()
    conn = sqlite3.connect(str(REVIEWS_DB))
    try:
        total = conn.execute("SELECT COUNT(*) FROM reviews WHERE timestamp >= ?", (cutoff,)).fetchone()[0]
        avg = conn.execute("SELECT COALESCE(AVG(rating), 0) FROM reviews WHERE timestamp >= ?", (cutoff,)).fetchone()[0]
        positive = conn.execute("SELECT COUNT(*) FROM reviews WHERE timestamp >= ? AND rating >= 4", (cutoff,)).fetchone()[0]
        negative = conn.execute("SELECT COUNT(*) FROM reviews WHERE timestamp >= ? AND rating < 3", (cutoff,)).fetchone()[0]
        unresponded = conn.execute("SELECT COUNT(*) FROM reviews WHERE timestamp >= ? AND responded = 0", (cutoff,)).fetchone()[0]
        return {
            "total": total, "avg_rating": round(avg, 2),
            "positive": positive, "negative": negative, "unresponded": unresponded,
        }
    except sqlite3.OperationalError:
        return {"total": 0, "avg_rating": 0, "positive": 0, "negative": 0, "unresponded": 0}
    finally:
        conn.close()


def fetch_social_stats(env, days=30):
    """Fetch social media stats from X API."""
    import requests

    bearer = env.get("X_BEARER_TOKEN")
    user_id = env.get("X_USER_ID")
    if not bearer or not user_id:
        return {"error": "Missing X_BEARER_TOKEN or X_USER_ID", "followers": 0, "tweets": 0, "engagement": 0}

    try:
        resp = requests.get(
            f"https://api.twitter.com/2/users/{user_id}",
            headers={"Authorization": f"Bearer {bearer}"},
            params={"user.fields": "public_metrics"},
            timeout=15,
        )
        resp.raise_for_status()
        metrics = resp.json().get("data", {}).get("public_metrics", {})
        return {
            "followers": metrics.get("followers_count", 0),
            "following": metrics.get("following_count", 0),
            "tweets": metrics.get("tweet_count", 0),
            "listed": metrics.get("listed_count", 0),
        }
    except Exception as e:
        return {"error": str(e), "followers": 0, "tweets": 0}


def fetch_email_stats(env):
    """Fetch email marketing stats from SendGrid."""
    import requests

    api_key = env.get("SENDGRID_API_KEY")
    if not api_key:
        return {"error": "Missing SENDGRID_API_KEY", "sent": 0, "opens": 0, "clicks": 0}

    try:
        resp = requests.get(
            "https://api.sendgrid.com/v3/stats",
            headers={"Authorization": f"Bearer {api_key}"},
            params={"start_date": (datetime.utcnow() - timedelta(days=30)).strftime("%Y-%m-%d")},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
        totals = {"sent": 0, "opens": 0, "clicks": 0, "unsubscribes": 0}
        for day in data:
            for stat in day.get("stats", []):
                m = stat.get("metrics", {})
                totals["sent"] += m.get("delivered", 0)
                totals["opens"] += m.get("unique_opens", 0)
                totals["clicks"] += m.get("unique_clicks", 0)
                totals["unsubscribes"] += m.get("unsubscribes", 0)
        if totals["sent"] > 0:
            totals["open_rate"] = round(totals["opens"] / totals["sent"] * 100, 1)
            totals["click_rate"] = round(totals["clicks"] / totals["sent"] * 100, 1)
        else:
            totals["open_rate"] = 0
            totals["click_rate"] = 0
        return totals
    except Exception as e:
        return {"error": str(e), "sent": 0, "opens": 0, "clicks": 0}


def render_ascii_bar(label, value, max_value, width=30):
    """Render an ASCII bar chart line."""
    if max_value == 0:
        filled = 0
    else:
        filled = int((value / max_value) * width)
    bar = "█" * filled + "░" * (width - filled)
    return f"  {label:<16} [{bar}] {value}"


def render_ascii_dashboard(data):
    """Render the full ASCII dashboard."""
    lines = []
    lines.append("╔══════════════════════════════════════════════════════╗")
    lines.append("║          SMALL BUSINESS DASHBOARD                   ║")
    lines.append("╠══════════════════════════════════════════════════════╣")

    # Revenue
    rev = data.get("revenue", {})
    lines.append("║  REVENUE                                            ║")
    lines.append(f"║    Total:      ${rev.get('total', 0):>10,.2f}  ({rev.get('count', 0)} transactions)  ║")

    # Reputation
    rep = data.get("reviews", {})
    stars = "★" * int(rep.get("avg_rating", 0)) + "☆" * (5 - int(rep.get("avg_rating", 0)))
    lines.append("║  REPUTATION                                         ║")
    lines.append(f"║    Rating:     {stars}  ({rep.get('avg_rating', 0)}/5.0)           ║")
    lines.append(f"║    Reviews:    {rep.get('total', 0):>5}  (+{rep.get('positive', 0)} pos / -{rep.get('negative', 0)} neg)       ║")
    lines.append(f"║    Unresponded:{rep.get('unresponded', 0):>5}                              ║")

    # Social
    soc = data.get("social", {})
    lines.append("║  SOCIAL MEDIA                                       ║")
    lines.append(f"║    Followers:  {soc.get('followers', 0):>8,}                          ║")
    lines.append(f"║    Tweets:     {soc.get('tweets', 0):>8,}                          ║")

    # Email
    em = data.get("email", {})
    lines.append("║  EMAIL MARKETING                                    ║")
    lines.append(f"║    Sent:       {em.get('sent', 0):>8,}                          ║")
    lines.append(f"║    Open Rate:  {em.get('open_rate', 0):>7.1f}%                          ║")
    lines.append(f"║    Click Rate: {em.get('click_rate', 0):>7.1f}%                          ║")

    lines.append("╚══════════════════════════════════════════════════════╝")
    return "\n".join(lines)


def cmd_overview(args, env, config):
    """Show unified business dashboard."""
    days = 30
    data = {
        "revenue": fetch_stripe_revenue(env, days),
        "reviews": fetch_review_stats(days),
        "social": fetch_social_stats(env, days),
        "email": fetch_email_stats(env),
        "generated_at": datetime.utcnow().isoformat(),
        "period_days": days,
    }

    if args.verbose:
        print(render_ascii_dashboard(data))
        print()
        print(json.dumps(data, indent=2))
    else:
        print(json.dumps({
            "success": True,
            "revenue": data["revenue"].get("total", 0),
            "avg_rating": data["reviews"].get("avg_rating", 0),
            "reviews": data["reviews"].get("total", 0),
            "followers": data["social"].get("followers", 0),
            "emails_sent": data["email"].get("sent", 0),
            "open_rate": data["email"].get("open_rate", 0),
        }))


def cmd_trends(args, env, config):
    """Show trend analysis for a specific metric."""
    metric = args.metric or "all"
    period_str = args.period or "30d"
    days = int(period_str.rstrip("d"))

    current = {}
    previous = {}

    if metric in ("revenue", "all"):
        current["revenue"] = fetch_stripe_revenue(env, days).get("total", 0)
        previous["revenue"] = fetch_stripe_revenue(env, days * 2).get("total", 0) - current.get("revenue", 0)

    if metric in ("reviews", "all"):
        current["reviews"] = fetch_review_stats(days)
        prev_stats = fetch_review_stats(days * 2)
        previous["reviews"] = {
            "total": prev_stats["total"] - current["reviews"]["total"],
            "avg_rating": prev_stats["avg_rating"],
        }

    if metric in ("social", "all"):
        current["social"] = fetch_social_stats(env, days)

    if metric in ("email", "all"):
        current["email"] = fetch_email_stats(env)

    trends = {}
    for key in current:
        if key in previous and isinstance(current[key], (int, float)) and isinstance(previous.get(key), (int, float)):
            prev_val = previous[key]
            curr_val = current[key]
            if prev_val > 0:
                change_pct = round((curr_val - prev_val) / prev_val * 100, 1)
            else:
                change_pct = 100.0 if curr_val > 0 else 0
            trends[key] = {
                "current": curr_val,
                "previous": prev_val,
                "change_pct": change_pct,
                "direction": "up" if change_pct > 0 else ("down" if change_pct < 0 else "flat"),
            }
        else:
            trends[key] = {"current": current[key]}

    output = {
        "success": True,
        "metric": metric,
        "period": period_str,
        "trends": trends,
    }

    if args.verbose:
        # ASCII trend display
        for key, val in trends.items():
            if isinstance(val.get("current"), (int, float)):
                direction = val.get("direction", "flat")
                arrow = "↑" if direction == "up" else ("↓" if direction == "down" else "→")
                pct = val.get("change_pct", 0)
                print(f"  {key.upper():<12} {arrow} {pct:>+6.1f}%  (current: {val['current']}, prev: {val.get('previous', 'N/A')})")
        print()

    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_competitors(args, env, config):
    """Show competitor comparison dashboard."""
    competitors = config.get("competitors", [])
    if not competitors:
        print(json.dumps({"success": False, "error": "No competitors configured in config.json"}))
        return

    my_reviews = fetch_review_stats(30)
    my_social = fetch_social_stats(env, 30)

    comparison = {
        "you": {
            "avg_rating": my_reviews.get("avg_rating", 0),
            "total_reviews": my_reviews.get("total", 0),
            "followers": my_social.get("followers", 0),
        },
        "competitors": [],
    }

    if COMPETITORS_DB.exists():
        conn = sqlite3.connect(str(COMPETITORS_DB))
        try:
            for comp in competitors:
                name = comp if isinstance(comp, str) else comp.get("name", "Unknown")
                row = conn.execute(
                    "SELECT avg_rating, review_count, followers FROM competitor_snapshots WHERE name = ? ORDER BY timestamp DESC LIMIT 1",
                    (name,)
                ).fetchone()
                if row:
                    comparison["competitors"].append({
                        "name": name,
                        "avg_rating": row[0],
                        "total_reviews": row[1],
                        "followers": row[2],
                    })
                else:
                    comparison["competitors"].append({"name": name, "data": "no tracking data yet"})
        except sqlite3.OperationalError:
            pass
        finally:
            conn.close()
    else:
        for comp in competitors:
            name = comp if isinstance(comp, str) else comp.get("name", "Unknown")
            comparison["competitors"].append({"name": name, "data": "no tracking data yet"})

    output = {"success": True, "comparison": comparison}

    if args.verbose:
        print("\n  COMPETITOR COMPARISON")
        print("  " + "=" * 50)
        you = comparison["you"]
        print(f"  {'YOU':<20} ★{you['avg_rating']:<6} {you['total_reviews']:>5} reviews  {you['followers']:>8} followers")
        for c in comparison["competitors"]:
            if "data" in c:
                print(f"  {c['name']:<20} (no data yet)")
            else:
                print(f"  {c['name']:<20} ★{c['avg_rating']:<6} {c['total_reviews']:>5} reviews  {c['followers']:>8} followers")
        print()

    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_cac(args, env, config):
    """Calculate customer acquisition cost."""
    rev = fetch_stripe_revenue(env, 30)
    email = fetch_email_stats(env)
    social = fetch_social_stats(env, 30)

    # Estimate costs from config or defaults
    costs = config.get("marketing_costs", {})
    monthly_ad_spend = costs.get("ad_spend", 0)
    monthly_tools = costs.get("tools", 0)
    monthly_content = costs.get("content_creation", 0)
    total_cost = monthly_ad_spend + monthly_tools + monthly_content

    new_customers = rev.get("count", 0)
    cac = round(total_cost / new_customers, 2) if new_customers > 0 else 0

    avg_order = round(rev.get("total", 0) / new_customers, 2) if new_customers > 0 else 0

    output = {
        "success": True,
        "period": "30d",
        "total_marketing_cost": total_cost,
        "new_customers": new_customers,
        "customer_acquisition_cost": cac,
        "avg_order_value": avg_order,
        "revenue": rev.get("total", 0),
        "roi": round((rev.get("total", 0) - total_cost) / total_cost * 100, 1) if total_cost > 0 else 0,
        "breakdown": {
            "ad_spend": monthly_ad_spend,
            "tools": monthly_tools,
            "content_creation": monthly_content,
        },
    }
    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_export(args, env, config):
    """Export dashboard data."""
    days = 30
    data = {
        "exported_at": datetime.utcnow().isoformat(),
        "period_days": days,
        "revenue": fetch_stripe_revenue(env, days),
        "reviews": fetch_review_stats(days),
        "social": fetch_social_stats(env, days),
        "email": fetch_email_stats(env),
    }

    fmt = args.format or "json"
    if fmt == "json":
        print(json.dumps(data, indent=2))
    elif fmt == "text":
        print(render_ascii_dashboard(data))
    else:
        print(json.dumps({"success": False, "error": f"Unsupported format: {fmt}. Use json or text."}))


def main():
    parser = argparse.ArgumentParser(
        description="Unified business analytics dashboard"
    )
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output with ASCII charts")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # overview
    subparsers.add_parser("overview", help="Show unified business dashboard")

    # trends
    trends_p = subparsers.add_parser("trends", help="Show trend analysis")
    trends_p.add_argument("--metric", choices=VALID_METRICS, default="all", help="Metric to analyze")
    trends_p.add_argument("--period", choices=VALID_PERIODS, default="30d", help="Analysis period")

    # competitors
    subparsers.add_parser("competitors", help="Competitor comparison dashboard")

    # cac
    subparsers.add_parser("cac", help="Customer acquisition cost analysis")

    # export
    export_p = subparsers.add_parser("export", help="Export dashboard data")
    export_p.add_argument("--format", choices=["json", "text"], default="json", help="Export format")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    env = load_env()
    config = load_config()

    commands = {
        "overview": cmd_overview,
        "trends": cmd_trends,
        "competitors": cmd_competitors,
        "cac": cmd_cac,
        "export": cmd_export,
    }
    commands[args.command](args, env, config)


if __name__ == "__main__":
    main()
