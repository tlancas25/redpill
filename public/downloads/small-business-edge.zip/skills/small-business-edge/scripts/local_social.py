#!/usr/bin/env python3
"""Localized social media content generator for small businesses.

Generates business-type aware social media content including weekly content
calendars, promotional posts, customer testimonial social proof, and local
event tie-in content. Supports restaurant, salon, service, and retail
business types.

Usage:
    python3 local_social.py generate-week --business-type restaurant --business-name "Joe's Diner" --location "Austin, TX"
    python3 local_social.py promo --type discount --offer "20% off all haircuts"
    python3 local_social.py testimonial --review "Best pizza in town!" --reviewer "Sarah M."
    python3 local_social.py local-event --event "Austin Food Festival" --date 2026-04-15 --tie-in "Visit us after!"
    python3 local_social.py post-now --platform x --content "Fresh batch just out of the oven!"
"""

import argparse
import json
import os
import random
import sys
from datetime import datetime, timedelta
from pathlib import Path

OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", os.path.expanduser("~/.openclaw"))
ENV_FILE = os.path.join(OPENCLAW_HOME, ".env")
SKILL_DIR = Path(__file__).resolve().parent.parent
CONFIG_FILE = SKILL_DIR / "config.json"

BUSINESS_TYPES = ["restaurant", "salon", "service", "retail"]

CONTENT_TEMPLATES = {
    "restaurant": {
        "monday": ["Start your week right with our {specialty}!", "Monday special: {offer}. Who's hungry?"],
        "tuesday": ["Taco Tuesday? We've got you covered! {location}", "Two-for-one {specialty} every Tuesday!"],
        "wednesday": ["Hump day fuel! Our {specialty} will get you through. #WednesdayMotivation", "Midweek treat yourself -- {specialty} is calling!"],
        "thursday": ["Almost Friday! Celebrate early with {specialty} at {name}.", "Throwback Thursday: Remember when you first tried our {specialty}?"],
        "friday": ["TGIF! Kick off the weekend at {name}. {location}", "Friday night plans? {name} has you covered with {specialty}!"],
        "saturday": ["Weekend vibes at {name}! Bring the family for {specialty}.", "Saturday special: {offer} -- only at {name}!"],
        "sunday": ["Lazy Sunday brunch at {name}? Yes please! {location}", "Sunday Funday starts at {name} with our famous {specialty}."],
        "hashtags": ["#LocalEats", "#FoodLover", "#SupportLocal", "#Foodie", "#SmallBizLove"],
    },
    "salon": {
        "monday": ["New week, new look! Book your appointment at {name}.", "Monday makeover time! {specialty} starting at {offer}."],
        "tuesday": ["Transform Tuesday! Fresh styles await at {name}. {location}", "Treat yourself this Tuesday -- {specialty} by our expert team."],
        "wednesday": ["Midweek glow-up at {name}! Walk-ins welcome. {location}", "Wednesday wellness: {specialty} to refresh your look."],
        "thursday": ["Weekend-ready starts Thursday! Book your {specialty} at {name}.", "Throwback to our favorite transformations! Book yours today."],
        "friday": ["Friday glam at {name}! Get party-ready with {specialty}.", "Weekend prep: {specialty} at {name}. Last-minute spots available!"],
        "saturday": ["Saturday pamper session! {specialty} at {name}. {location}", "Self-care Saturday starts at {name}. You deserve it!"],
        "sunday": ["Sunday self-care at {name}. Relax and refresh with {specialty}.", "Book now for next week! {name} fills up fast. {location}"],
        "hashtags": ["#HairGoals", "#SalonLife", "#BeautyLocal", "#SelfCare", "#FreshCut"],
    },
    "service": {
        "monday": ["Starting the week strong! {name} is here for all your {specialty} needs.", "Monday momentum: Let {name} handle your {specialty} this week."],
        "tuesday": ["Did you know? {name} offers {specialty} in {location}.", "Trust the local experts! {name} -- your {specialty} pros."],
        "wednesday": ["Midweek reminder: Don't put off that {specialty} project! Call {name}.", "Wednesday wisdom: Regular {specialty} saves money long-term."],
        "thursday": ["Planning weekend projects? {name} can help with {specialty}!", "Pro tip from {name}: {specialty} done right the first time."],
        "friday": ["Book {name} for your weekend {specialty} needs! {location}", "Friday special: Free estimates on all {specialty} services!"],
        "saturday": ["Weekend warriors! {name} is open for {specialty}. {location}", "Saturday service: {name} is ready to tackle your {specialty} project."],
        "sunday": ["Plan ahead! Schedule your {specialty} with {name} for next week.", "Rest easy knowing {name} has your {specialty} covered. {location}"],
        "hashtags": ["#LocalBusiness", "#ServicePro", "#TrustedLocal", "#SmallBiz", "#HireLocal"],
    },
    "retail": {
        "monday": ["New week, new arrivals at {name}! {location}", "Monday motivation: Treat yourself to something from {name}."],
        "tuesday": ["Fresh stock alert! Check out {specialty} at {name}.", "Tuesday finds at {name}! {specialty} just arrived."],
        "wednesday": ["Midweek shopping therapy at {name}. {location}", "Hump day pick-me-up: {specialty} at unbeatable prices!"],
        "thursday": ["Preview: Weekend sale starts tomorrow at {name}!", "Thursday treasure hunt at {name}! New {specialty} in store."],
        "friday": ["Weekend shopping starts at {name}! {offer}", "TGIF! Celebrate with {specialty} from {name}. {location}"],
        "saturday": ["Saturday shopping at {name}! Bring a friend for {offer}.", "Weekend deal: {offer} at {name}. While supplies last!"],
        "sunday": ["Sunday browsing at {name}. {location}", "Last chance for weekend specials at {name}! {specialty} won't last."],
        "hashtags": ["#ShopLocal", "#RetailTherapy", "#SmallBizSaturday", "#LocalFinds", "#SupportSmall"],
    },
}

PROMO_TEMPLATES = {
    "discount": [
        "{offer} at {name}! Don't miss out. {location}",
        "DEAL ALERT: {offer} -- limited time only at {name}!",
        "Save big! {offer} at {name}. Visit us today!",
    ],
    "event": [
        "Join us for {offer} at {name}! {location}",
        "You're invited! {offer} happening at {name}. Mark your calendar!",
        "Special event at {name}: {offer}. Bring the whole family!",
    ],
    "seasonal": [
        "Seasonal special: {offer} at {name}! {location}",
        "It's that time of year! {offer} -- only at {name}.",
        "Celebrate the season with {offer} at {name}!",
    ],
    "launch": [
        "NEW! Introducing {offer} at {name}! {location}",
        "We're excited to announce: {offer} now available at {name}!",
        "The wait is over! {offer} has arrived at {name}.",
    ],
    "loyalty": [
        "Thank you for being a loyal customer! {offer} at {name}.",
        "VIP exclusive: {offer} at {name}. You earned it!",
        "Loyalty pays: {offer} for our favorite customers at {name}.",
    ],
}


def load_env():
    """Load environment variables from .env file."""
    env = os.environ.copy()
    if os.path.exists(ENV_FILE):
        with open(ENV_FILE, "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    env[key.strip()] = value.strip().strip("\"'")
    return env


def load_config():
    """Load skill configuration."""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def fill_template(template, name, location, specialty="", offer=""):
    """Fill a content template with business details."""
    return template.format(
        name=name, location=location,
        specialty=specialty or "our specialties",
        offer=offer or "special offer",
    )


def cmd_generate_week(args, env, config):
    """Generate a full week of social media content."""
    biz_type = args.business_type or config.get("business", {}).get("type", "service")
    biz_name = args.business_name or config.get("business", {}).get("name", "Our Business")
    location = args.location or config.get("business", {}).get("city", "your area")
    specialty = config.get("social_content", {}).get("specialty", "")

    if biz_type not in CONTENT_TEMPLATES:
        print(json.dumps({"success": False, "error": f"Unsupported business type: {biz_type}. Use: {BUSINESS_TYPES}"}))
        return

    templates = CONTENT_TEMPLATES[biz_type]
    days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    today = datetime.now()
    start = today - timedelta(days=today.weekday())  # Monday

    calendar = []
    for i, day in enumerate(days):
        date = (start + timedelta(days=i)).strftime("%Y-%m-%d")
        post_text = fill_template(
            random.choice(templates[day]), biz_name, location, specialty
        )
        hashtags = " ".join(random.sample(templates["hashtags"], min(3, len(templates["hashtags"]))))
        calendar.append({
            "day": day.capitalize(),
            "date": date,
            "content": f"{post_text} {hashtags}",
            "platform": "all",
            "time": "10:00 AM" if i < 5 else "11:00 AM",
        })

    output = {
        "success": True,
        "business_type": biz_type,
        "business_name": biz_name,
        "week_starting": start.strftime("%Y-%m-%d"),
        "posts": len(calendar),
    }
    if args.verbose:
        output["calendar"] = calendar
    else:
        output["calendar"] = [{"day": c["day"], "date": c["date"],
                                "content": c["content"][:80] + "..."
                                if len(c["content"]) > 80 else c["content"]}
                               for c in calendar]

    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_promo(args, env, config):
    """Generate promotional content."""
    biz_name = config.get("business", {}).get("name", "Our Business")
    location = config.get("business", {}).get("city", "your area")
    promo_type = args.type or "discount"
    offer = args.offer or "special offer"

    if promo_type not in PROMO_TEMPLATES:
        print(json.dumps({"success": False, "error": f"Unsupported promo type: {promo_type}. Use: {list(PROMO_TEMPLATES.keys())}"}))
        return

    templates = PROMO_TEMPLATES[promo_type]
    variants = []
    for tmpl in templates:
        variants.append(fill_template(tmpl, biz_name, location, offer=offer))

    output = {
        "success": True,
        "promo_type": promo_type,
        "variants": len(variants),
        "posts": variants,
    }
    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_testimonial(args, env, config):
    """Generate social proof post from a customer review."""
    biz_name = config.get("business", {}).get("name", "Our Business")
    review = args.review
    reviewer = args.reviewer or "a happy customer"

    templates = [
        f'"{review}" -- {reviewer}\n\nThank you for the kind words! At {biz_name}, every customer matters. #CustomerLove #SupportLocal',
        f'Our customers say it best!\n\n"{review}" -- {reviewer}\n\n{biz_name} is grateful for amazing customers like you! #Testimonial #SmallBiz',
        f'Why choose {biz_name}? Our customers know!\n\n"{review}" -- {reviewer}\n\n#ReviewLove #LocalFavorite #SupportSmall',
    ]

    output = {
        "success": True,
        "reviewer": reviewer,
        "variants": len(templates),
        "posts": templates,
    }
    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_local_event(args, env, config):
    """Generate content tying into a local event."""
    biz_name = config.get("business", {}).get("name", "Our Business")
    location = config.get("business", {}).get("city", "your area")
    event = args.event
    date = args.date
    tie_in = args.tie_in or f"Stop by {biz_name} before or after!"

    posts = [
        f"Excited for {event} on {date}! {tie_in} {location} #LocalEvent #Community #SupportLocal",
        f"{event} is coming to {location} on {date}! {biz_name} will be here to fuel your fun. {tie_in}",
        f"Mark your calendar: {event} ({date})! {biz_name} is proud to be part of the {location} community. {tie_in}",
    ]

    output = {
        "success": True,
        "event": event,
        "date": date,
        "variants": len(posts),
        "posts": posts,
    }
    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_post_now(args, env, config):
    """Post content to a social platform via API."""
    import requests

    platform = args.platform or "x"
    content = args.content

    if platform == "x":
        bearer = env.get("X_BEARER_TOKEN")
        if not bearer:
            print(json.dumps({"success": False, "error": "Missing X_BEARER_TOKEN in environment"}))
            return
        try:
            resp = requests.post(
                "https://api.twitter.com/2/tweets",
                headers={"Authorization": f"Bearer {bearer}", "Content-Type": "application/json"},
                json={"text": content},
                timeout=15,
            )
            resp.raise_for_status()
            data = resp.json()
            output = {"success": True, "platform": platform, "tweet_id": data.get("data", {}).get("id")}
        except requests.RequestException as e:
            output = {"success": False, "error": f"X API error: {str(e)}"}
    else:
        output = {"success": False, "error": f"Platform '{platform}' posting not yet supported. Use 'x'."}

    print(json.dumps(output, indent=2 if args.verbose else None))


def main():
    parser = argparse.ArgumentParser(
        description="Localized social media content generator for small businesses"
    )
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output with full details")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # generate-week
    gw = subparsers.add_parser("generate-week", help="Generate a week of social content")
    gw.add_argument("--business-type", choices=BUSINESS_TYPES, help="Type of business")
    gw.add_argument("--business-name", help="Business name")
    gw.add_argument("--location", help="Business location/city")

    # promo
    promo = subparsers.add_parser("promo", help="Generate promotional content")
    promo.add_argument("--type", choices=list(PROMO_TEMPLATES.keys()), help="Promotion type")
    promo.add_argument("--offer", required=True, help="The offer or promotion details")

    # testimonial
    test = subparsers.add_parser("testimonial", help="Generate testimonial social proof post")
    test.add_argument("--review", required=True, help="The customer review text")
    test.add_argument("--reviewer", help="Reviewer name (default: a happy customer)")

    # local-event
    le = subparsers.add_parser("local-event", help="Generate local event tie-in content")
    le.add_argument("--event", required=True, help="Event name")
    le.add_argument("--date", required=True, help="Event date (YYYY-MM-DD)")
    le.add_argument("--tie-in", help="How your business ties into the event")

    # post-now
    pn = subparsers.add_parser("post-now", help="Post content to a social platform")
    pn.add_argument("--platform", default="x", help="Platform to post to (default: x)")
    pn.add_argument("--content", required=True, help="Content to post")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    env = load_env()
    config = load_config()

    commands = {
        "generate-week": cmd_generate_week,
        "promo": cmd_promo,
        "testimonial": cmd_testimonial,
        "local-event": cmd_local_event,
        "post-now": cmd_post_now,
    }
    commands[args.command](args, env, config)


if __name__ == "__main__":
    main()
