#!/usr/bin/env python3
"""Review monitoring, response generation, and analytics engine.

Integrates with Google Business Profile API and Yelp Fusion API to monitor
reviews, generate AI-assisted contextual responses, track sentiment, and
alert on negative reviews. All review data is persisted in SQLite for
trend analysis.

Usage:
    python3 review_engine.py check --platforms google,yelp
    python3 review_engine.py respond --auto --tone professional
    python3 review_engine.py respond --review-id 42 --tone friendly
    python3 review_engine.py analytics --period 30d
    python3 review_engine.py alerts
"""

import argparse
import json
import os
import sqlite3
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", os.path.expanduser("~/.openclaw"))
ENV_FILE = os.path.join(OPENCLAW_HOME, ".env")
SKILL_DIR = Path(__file__).resolve().parent.parent
CONFIG_FILE = SKILL_DIR / "config.json"
DB_PATH = SKILL_DIR / "data" / "reviews.db"

SUPPORTED_PLATFORMS = ["google", "yelp"]
NEGATIVE_THRESHOLD = 3


def load_env():
    """Load environment variables from .env file."""
    env = os.environ.copy()
    if os.path.exists(ENV_FILE):
        with open(ENV_FILE, "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    env[key.strip()] = value.strip().strip("\"'")
    return env


def load_config():
    """Load skill configuration from config.json."""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def ensure_db():
    """Initialize the reviews SQLite database."""
    os.makedirs(DB_PATH.parent, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            platform TEXT NOT NULL,
            platform_review_id TEXT,
            author TEXT,
            rating INTEGER NOT NULL,
            text TEXT,
            timestamp TEXT NOT NULL,
            sentiment TEXT,
            sentiment_score REAL,
            responded INTEGER DEFAULT 0,
            response_text TEXT,
            response_timestamp TEXT,
            fetched_at TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            review_id INTEGER NOT NULL,
            alert_type TEXT NOT NULL,
            message TEXT NOT NULL,
            created_at TEXT NOT NULL,
            acknowledged INTEGER DEFAULT 0,
            FOREIGN KEY (review_id) REFERENCES reviews(id)
        )
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_reviews_platform
        ON reviews(platform, timestamp)
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_reviews_rating
        ON reviews(rating)
    """)
    conn.commit()
    return conn


def fetch_google_reviews(env, config):
    """Fetch reviews from Google Business Profile API."""
    import requests

    token = env.get("GOOGLE_BUSINESS_ACCESS_TOKEN")
    account_id = env.get("GOOGLE_BUSINESS_ACCOUNT_ID")
    location_id = env.get("GOOGLE_BUSINESS_LOCATION_ID")

    if not all([token, account_id, location_id]):
        return {"error": "Missing GOOGLE_BUSINESS_ACCESS_TOKEN, GOOGLE_BUSINESS_ACCOUNT_ID, or GOOGLE_BUSINESS_LOCATION_ID"}

    url = (
        f"https://mybusiness.googleapis.com/v4/accounts/{account_id}"
        f"/locations/{location_id}/reviews"
    )
    headers = {"Authorization": f"Bearer {token}"}

    try:
        resp = requests.get(url, headers=headers, timeout=15)
        resp.raise_for_status()
        data = resp.json()
        reviews = []
        for r in data.get("reviews", []):
            reviews.append({
                "platform": "google",
                "platform_review_id": r.get("reviewId", ""),
                "author": r.get("reviewer", {}).get("displayName", "Anonymous"),
                "rating": int(r.get("starRating", "FIVE").replace("FIVE", "5").replace("FOUR", "4").replace("THREE", "3").replace("TWO", "2").replace("ONE", "1")),
                "text": r.get("comment", ""),
                "timestamp": r.get("createTime", datetime.utcnow().isoformat()),
            })
        return {"reviews": reviews}
    except requests.RequestException as e:
        return {"error": f"Google API error: {str(e)}"}


def fetch_yelp_reviews(env, config):
    """Fetch reviews from Yelp Fusion API."""
    import requests

    api_key = env.get("YELP_API_KEY")
    business_id = env.get("YELP_BUSINESS_ID")

    if not all([api_key, business_id]):
        return {"error": "Missing YELP_API_KEY or YELP_BUSINESS_ID"}

    url = f"https://api.yelp.com/v3/businesses/{business_id}/reviews"
    headers = {"Authorization": f"Bearer {api_key}"}

    try:
        resp = requests.get(url, headers=headers, params={"sort_by": "newest"}, timeout=15)
        resp.raise_for_status()
        data = resp.json()
        reviews = []
        for r in data.get("reviews", []):
            reviews.append({
                "platform": "yelp",
                "platform_review_id": r.get("id", ""),
                "author": r.get("user", {}).get("name", "Anonymous"),
                "rating": r.get("rating", 0),
                "text": r.get("text", ""),
                "timestamp": r.get("time_created", datetime.utcnow().isoformat()),
            })
        return {"reviews": reviews}
    except requests.RequestException as e:
        return {"error": f"Yelp API error: {str(e)}"}


def analyze_sentiment(text):
    """Basic sentiment analysis based on keyword matching and rating."""
    if not text:
        return "neutral", 0.5

    positive_words = {"great", "excellent", "amazing", "wonderful", "fantastic",
                      "love", "best", "perfect", "awesome", "outstanding",
                      "friendly", "delicious", "recommend", "happy", "pleasant"}
    negative_words = {"terrible", "awful", "horrible", "worst", "bad", "rude",
                      "dirty", "slow", "cold", "disgusting", "never", "disappointed",
                      "waste", "poor", "overpriced", "unprofessional"}

    words = set(text.lower().split())
    pos_count = len(words & positive_words)
    neg_count = len(words & negative_words)
    total = pos_count + neg_count

    if total == 0:
        return "neutral", 0.5

    score = pos_count / total
    if score > 0.6:
        return "positive", round(score, 2)
    elif score < 0.4:
        return "negative", round(score, 2)
    return "mixed", round(score, 2)


def generate_response(review, tone="professional", config=None):
    """Generate a contextual response based on review rating and content."""
    config = config or {}
    biz_name = config.get("business", {}).get("name", "our business")
    rating = review.get("rating", 3)
    author = review.get("author", "valued customer")

    if rating >= 5:
        templates = {
            "professional": f"Thank you for your wonderful 5-star review, {author}! We're delighted that you had such a positive experience with {biz_name}. Your feedback motivates our team to continue delivering excellent service. We look forward to welcoming you back!",
            "friendly": f"Wow, thank you so much, {author}! We're thrilled you had an amazing experience! Your kind words mean the world to our team at {biz_name}. Can't wait to see you again!",
            "formal": f"Dear {author}, we sincerely appreciate your generous 5-star review. At {biz_name}, we strive to exceed expectations and are gratified to learn we achieved that standard during your visit. We would be honored to serve you again.",
        }
    elif rating == 4:
        templates = {
            "professional": f"Thank you for your positive review, {author}! We're glad you enjoyed your experience at {biz_name}. We're always looking to improve -- if there's anything that would make your next visit even better, please let us know!",
            "friendly": f"Thanks so much for the great review, {author}! We're so happy you had a good time at {biz_name}. We'd love to hear what could make it a 5-star experience next time!",
            "formal": f"Dear {author}, thank you for your favorable review of {biz_name}. We appreciate your patronage and welcome any suggestions that could enhance your future visits.",
        }
    elif rating == 3:
        templates = {
            "professional": f"Thank you for your feedback, {author}. We appreciate your honest review and take your comments seriously at {biz_name}. We'd love the opportunity to improve your experience -- please reach out to us directly so we can address your concerns.",
            "friendly": f"Hi {author}, thanks for sharing your thoughts! We want every visit to {biz_name} to be great. We'd love to chat about how we can do better -- feel free to reach out anytime!",
            "formal": f"Dear {author}, we appreciate you taking the time to review {biz_name}. Your candid feedback is valuable, and we would welcome the opportunity to discuss how we might better meet your expectations.",
        }
    else:
        templates = {
            "professional": f"Thank you for bringing this to our attention, {author}. We sincerely apologize that your experience at {biz_name} did not meet expectations. We take all feedback seriously and would like to make this right. Please contact us directly so we can address your concerns personally.",
            "friendly": f"Hi {author}, we're really sorry to hear about your experience. This isn't the standard we hold ourselves to at {biz_name}. We want to make it up to you -- please reach out to us so we can fix this!",
            "formal": f"Dear {author}, we deeply regret that your experience at {biz_name} fell short of our standards. Please accept our sincere apologies. We would appreciate the opportunity to rectify the situation and invite you to contact us at your earliest convenience.",
        }

    return templates.get(tone, templates["professional"])


def store_reviews(conn, reviews):
    """Store new reviews in the database, skipping duplicates."""
    now = datetime.utcnow().isoformat()
    new_count = 0
    for r in reviews:
        existing = conn.execute(
            "SELECT id FROM reviews WHERE platform = ? AND platform_review_id = ?",
            (r["platform"], r["platform_review_id"])
        ).fetchone()
        if existing:
            continue
        sentiment, score = analyze_sentiment(r.get("text", ""))
        conn.execute(
            """INSERT INTO reviews
               (platform, platform_review_id, author, rating, text, timestamp,
                sentiment, sentiment_score, fetched_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (r["platform"], r["platform_review_id"], r["author"], r["rating"],
             r.get("text", ""), r["timestamp"], sentiment, score, now)
        )
        new_count += 1

        # Create alert for negative reviews
        if r["rating"] < NEGATIVE_THRESHOLD:
            review_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            conn.execute(
                "INSERT INTO alerts (review_id, alert_type, message, created_at) VALUES (?, ?, ?, ?)",
                (review_id, "negative_review",
                 f"{r['rating']}-star review from {r['author']} on {r['platform']}: {r.get('text', '')[:100]}",
                 now)
            )
    conn.commit()
    return new_count


def cmd_check(args, env, config):
    """Check for new reviews across platforms."""
    conn = ensure_db()
    platforms = [p.strip() for p in args.platforms.split(",")]
    all_reviews = []
    errors = []

    for platform in platforms:
        if platform not in SUPPORTED_PLATFORMS:
            errors.append(f"Unsupported platform: {platform}")
            continue
        if platform == "google":
            result = fetch_google_reviews(env, config)
        elif platform == "yelp":
            result = fetch_yelp_reviews(env, config)

        if "error" in result:
            errors.append(result["error"])
        else:
            all_reviews.extend(result.get("reviews", []))

    new_count = store_reviews(conn, all_reviews) if all_reviews else 0

    total = conn.execute("SELECT COUNT(*) FROM reviews").fetchone()[0]
    avg_rating = conn.execute("SELECT COALESCE(AVG(rating), 0) FROM reviews").fetchone()[0]
    unresponded = conn.execute("SELECT COUNT(*) FROM reviews WHERE responded = 0").fetchone()[0]

    output = {
        "success": len(errors) == 0,
        "new_reviews": new_count,
        "total_reviews": total,
        "avg_rating": round(avg_rating, 2),
        "unresponded": unresponded,
        "platforms_checked": platforms,
    }
    if errors:
        output["errors"] = errors
    if args.verbose and all_reviews:
        output["reviews"] = all_reviews

    conn.close()
    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_respond(args, env, config):
    """Generate and store responses for reviews."""
    conn = ensure_db()
    tone = args.tone or config.get("review_response", {}).get("default_tone", "professional")
    responses = []

    if args.review_id:
        row = conn.execute(
            "SELECT id, platform, author, rating, text, responded FROM reviews WHERE id = ?",
            (args.review_id,)
        ).fetchone()
        if not row:
            print(json.dumps({"success": False, "error": f"Review {args.review_id} not found"}))
            return
        review = {"id": row[0], "platform": row[1], "author": row[2], "rating": row[3], "text": row[4]}
        response_text = generate_response(review, tone, config)
        now = datetime.utcnow().isoformat()
        conn.execute(
            "UPDATE reviews SET responded = 1, response_text = ?, response_timestamp = ? WHERE id = ?",
            (response_text, now, review["id"])
        )
        responses.append({"review_id": review["id"], "response": response_text})
    elif args.auto:
        rows = conn.execute(
            "SELECT id, platform, author, rating, text FROM reviews WHERE responded = 0 ORDER BY rating ASC"
        ).fetchall()
        now = datetime.utcnow().isoformat()
        for row in rows:
            review = {"id": row[0], "platform": row[1], "author": row[2], "rating": row[3], "text": row[4]}
            response_text = generate_response(review, tone, config)
            conn.execute(
                "UPDATE reviews SET responded = 1, response_text = ?, response_timestamp = ? WHERE id = ?",
                (response_text, now, review["id"])
            )
            responses.append({"review_id": review["id"], "rating": review["rating"], "response": response_text})
    else:
        print(json.dumps({"success": False, "error": "Specify --auto or --review-id"}))
        conn.close()
        return

    conn.commit()
    output = {"success": True, "responses_generated": len(responses)}
    if args.verbose:
        output["responses"] = responses
    conn.close()
    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_analytics(args, env, config):
    """Show review analytics for a given period."""
    conn = ensure_db()
    period_str = args.period or "30d"
    days = int(period_str.rstrip("d"))
    cutoff = (datetime.utcnow() - timedelta(days=days)).isoformat()

    total = conn.execute("SELECT COUNT(*) FROM reviews WHERE timestamp >= ?", (cutoff,)).fetchone()[0]
    avg_rating = conn.execute("SELECT COALESCE(AVG(rating), 0) FROM reviews WHERE timestamp >= ?", (cutoff,)).fetchone()[0]

    by_platform = conn.execute(
        "SELECT platform, COUNT(*), AVG(rating) FROM reviews WHERE timestamp >= ? GROUP BY platform",
        (cutoff,)
    ).fetchall()

    by_rating = conn.execute(
        "SELECT rating, COUNT(*) FROM reviews WHERE timestamp >= ? GROUP BY rating ORDER BY rating DESC",
        (cutoff,)
    ).fetchall()

    by_sentiment = conn.execute(
        "SELECT sentiment, COUNT(*) FROM reviews WHERE timestamp >= ? GROUP BY sentiment",
        (cutoff,)
    ).fetchall()

    responded = conn.execute(
        "SELECT COUNT(*) FROM reviews WHERE timestamp >= ? AND responded = 1", (cutoff,)
    ).fetchone()[0]

    output = {
        "success": True,
        "period": period_str,
        "total_reviews": total,
        "avg_rating": round(avg_rating, 2),
        "response_rate": round(responded / total * 100, 1) if total > 0 else 0,
        "by_platform": {r[0]: {"count": r[1], "avg_rating": round(r[2], 2)} for r in by_platform},
        "by_rating": {str(r[0]): r[1] for r in by_rating},
        "by_sentiment": {r[0]: r[1] for r in by_sentiment},
    }

    conn.close()
    print(json.dumps(output, indent=2 if args.verbose else None))


def cmd_alerts(args, env, config):
    """Show unacknowledged review alerts."""
    conn = ensure_db()
    rows = conn.execute(
        """SELECT a.id, a.alert_type, a.message, a.created_at, r.platform, r.rating, r.author
           FROM alerts a JOIN reviews r ON a.review_id = r.id
           WHERE a.acknowledged = 0
           ORDER BY a.created_at DESC""",
    ).fetchall()

    alerts_list = []
    for row in rows:
        alerts_list.append({
            "alert_id": row[0],
            "type": row[1],
            "message": row[2],
            "created_at": row[3],
            "platform": row[4],
            "rating": row[5],
            "author": row[6],
        })

    output = {
        "success": True,
        "unacknowledged_alerts": len(alerts_list),
    }
    if args.verbose:
        output["alerts"] = alerts_list
    else:
        output["alerts"] = [{"alert_id": a["alert_id"], "type": a["type"],
                             "rating": a["rating"], "platform": a["platform"]}
                            for a in alerts_list]

    conn.close()
    print(json.dumps(output, indent=2 if args.verbose else None))


def main():
    parser = argparse.ArgumentParser(
        description="Review monitoring and response engine for small businesses"
    )
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output with full details")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # check
    check_p = subparsers.add_parser("check", help="Check for new reviews")
    check_p.add_argument("--platforms", default="google,yelp",
                         help="Comma-separated platforms to check (default: google,yelp)")

    # respond
    respond_p = subparsers.add_parser("respond", help="Generate review responses")
    respond_p.add_argument("--auto", action="store_true", help="Auto-respond to all unresponded reviews")
    respond_p.add_argument("--review-id", type=int, help="Respond to a specific review by ID")
    respond_p.add_argument("--tone", choices=["professional", "friendly", "formal"],
                           help="Response tone (default: from config or professional)")

    # analytics
    analytics_p = subparsers.add_parser("analytics", help="Review analytics")
    analytics_p.add_argument("--period", default="30d", help="Analysis period (e.g., 7d, 30d, 90d)")

    # alerts
    subparsers.add_parser("alerts", help="Show unacknowledged review alerts")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    env = load_env()
    config = load_config()

    commands = {
        "check": cmd_check,
        "respond": cmd_respond,
        "analytics": cmd_analytics,
        "alerts": cmd_alerts,
    }
    commands[args.command](args, env, config)


if __name__ == "__main__":
    main()
