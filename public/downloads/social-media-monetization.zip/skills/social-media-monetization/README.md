# Social Media Monetization Skill Pack

**By @OPENCLAwGURU | Part of The X Monetization System**

---

## Overview

Complete toolkit for automating content creation, audience engagement, affiliate marketing, and revenue tracking on X (Twitter). Includes 7 production Python scripts, 2 automation pipelines, and full configuration support.

| Script | Purpose | Lines |
|--------|---------|-------|
| `content_engine.py` | AI-powered content generation with pillar rotation | 489 |
| `engagement_bot.py` | Automated community building and engagement | 582 |
| `scheduler.py` | Content queue management and publishing | 499 |
| `affiliate_tracker.py` | Affiliate link management and commission tracking | 568 |
| `social_analytics.py` | Social media performance analytics | 527 |
| `revenue_tracker.py` | Revenue dashboard across all streams | 450 |
| `stripe_product_manager.py` | Digital product creation and payment links | 485 |

## Installation

```bash
cp -r social-media-monetization/ ~/.openclaw/workspace/skills/social-media-monetization/
cd ~/.openclaw/workspace/skills/social-media-monetization/
pip3 install -r requirements.txt
cp config.example.json config.json
# Edit config.json with your niche, brand voice, and preferences
```

### Environment Variables (add to ~/.openclaw/.env)

```bash
X_CONSUMER_KEY=your_consumer_key
X_CONSUMER_SECRET=your_consumer_secret
X_ACCESS_TOKEN=your_access_token
X_ACCESS_TOKEN_SECRET=your_access_token_secret
X_BEARER_TOKEN=your_bearer_token
STRIPE_SECRET_KEY=sk_live_...
ANTHROPIC_API_KEY=sk-ant-...
```

## Scripts Reference

### content_engine.py
```bash
python3 scripts/content_engine.py generate --pillar value --niche "personal finance"
python3 scripts/content_engine.py daily-queue --niche "fitness coaching" --posts 4
python3 scripts/content_engine.py thread --topic "5 passive income streams" --tweets 7
python3 scripts/content_engine.py optimize --analytics-file analytics.json
```

### engagement_bot.py
```bash
python3 scripts/engagement_bot.py engage --niche "fitness" --actions 20
python3 scripts/engagement_bot.py reply-mentions --since "2h"
python3 scripts/engagement_bot.py discover --niche "SaaS founders" --count 10
python3 scripts/engagement_bot.py full-cycle --niche "crypto" --budget 30
```

### scheduler.py
```bash
python3 scripts/scheduler.py list
python3 scripts/scheduler.py add --text "Your post" --time "2026-03-16T08:00:00-08:00"
python3 scripts/scheduler.py publish-next
python3 scripts/scheduler.py publish-next --dry-run
```

### affiliate_tracker.py
```bash
python3 scripts/affiliate_tracker.py add --name "ConvertKit" --url "https://..." --commission "30%"
python3 scripts/affiliate_tracker.py post --product "ConvertKit" --style "review"
python3 scripts/affiliate_tracker.py dashboard
python3 scripts/affiliate_tracker.py report --period month
```

### social_analytics.py
```bash
python3 scripts/social_analytics.py report --period day
python3 scripts/social_analytics.py report --period week --detailed
python3 scripts/social_analytics.py growth --period month
python3 scripts/social_analytics.py timing --period month
```

### revenue_tracker.py
```bash
python3 scripts/revenue_tracker.py dashboard
python3 scripts/revenue_tracker.py breakdown --period month
python3 scripts/revenue_tracker.py trends --months 6
```

### stripe_product_manager.py
```bash
python3 scripts/stripe_product_manager.py create --name "Growth Playbook" --price 29.99 --type one_time
python3 scripts/stripe_product_manager.py create --name "VIP Circle" --price 9.99 --type recurring --interval month
python3 scripts/stripe_product_manager.py list
```

## Automation (Cron Jobs)

```json
{
  "name": "morning-content-post",
  "schedule": {"kind": "cron", "expr": "0 8 * * *", "tz": "America/Los_Angeles"},
  "payload": {"kind": "agentTurn", "message": "Generate and post a value post", "model": "anthropic/claude-haiku"}
}
```

## Troubleshooting

- **Rate limits**: Free tier = 500 tweets/month. Upgrade to Basic ($100/mo) for 3,000.
- **Generic content**: Customize `brand_voice` in config.json with specific tone examples.
- **Stripe webhooks**: Use `stripe listen --forward-to localhost:5000/webhook` for local testing.

*Part of The X Monetization System by @OPENCLAwGURU*
