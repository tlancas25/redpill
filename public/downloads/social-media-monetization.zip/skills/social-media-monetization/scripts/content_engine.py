#!/usr/bin/env python3
"""Content Engine — AI-powered content generator for social media monetization.

Generates niche-specific posts using content pillar rotation, trending topic
integration, and brand voice configuration. All output is JSON.
"""

import argparse
import json
import os
import sys
import random
import hashlib
from datetime import datetime, timedelta
from pathlib import Path

# ── OpenClaw Patterns ────────────────────────────────────────────────────────
OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", str(Path.home() / ".openclaw"))
SKILL_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = SKILL_DIR / "content_config.json"
COMPACT_MODE = True

# ── Content Pillar Weights ───────────────────────────────────────────────────
PILLAR_WEIGHTS = {
    "value": 0.40,
    "engagement": 0.25,
    "personal": 0.20,
    "promotional": 0.15,
}

# ── Default Templates ────────────────────────────────────────────────────────
DEFAULT_TEMPLATES = {
    "value": [
        "Here's what most people get wrong about {topic}:\n\n{insight}\n\nSave this for later.",
        "{number} things I learned about {topic} the hard way:\n\n{insight}",
        "Stop doing this with {topic}.\n\nInstead: {insight}\n\nYou'll thank me later.",
        "The {topic} cheat sheet nobody shares:\n\n{insight}\n\nBookmark this.",
        "I spent {timeframe} studying {topic}. Here's the truth:\n\n{insight}",
    ],
    "engagement": [
        "Hot take: {opinion}\n\nAgree or disagree?",
        "What's your biggest challenge with {topic}?\n\nDrop it below, I'll share my take.",
        "Unpopular opinion about {topic}:\n\n{opinion}\n\nChange my mind.",
        "Rate your {topic} skills 1-10.\n\nBe honest. I'll share tips for wherever you are.",
        "If you could change ONE thing about {topic}, what would it be?",
    ],
    "personal": [
        "Real talk about my {topic} journey:\n\n{story}\n\nThe lesson? {lesson}",
        "A year ago I was {before}.\n\nToday I'm {after}.\n\nHere's what changed: {insight}",
        "My biggest {topic} mistake:\n\n{story}\n\nDon't repeat it.",
        "Behind the scenes: {story}\n\nThis is what nobody sees.",
        "Honest update on {topic}:\n\n{story}\n\nTransparency > perfection.",
    ],
    "promotional": [
        "I built something for people struggling with {topic}:\n\n{product_desc}\n\n{cta}",
        "New: {product_name}\n\n{product_desc}\n\nLink in bio.",
        "If you've been stuck with {topic}, this might help:\n\n{product_desc}\n\n{cta}",
        "Just dropped: {product_name}\n\n{benefit_1}\n{benefit_2}\n{benefit_3}\n\n{cta}",
    ],
}

TIMEFRAMES = ["3 months", "6 months", "a year", "2 years", "5 years"]
NUMBERS = ["3", "5", "7", "10"]


def load_env():
    """Load environment variables from .env file."""
    env_path = Path(OPENCLAW_HOME) / ".env"
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, val = line.split("=", 1)
                    val = val.strip().strip('"').strip("'")
                    if key not in os.environ:
                        os.environ[key] = val


def load_config():
    """Load content configuration from config file."""
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH) as f:
            return json.load(f)
    return {
        "brand_voice": "professional yet approachable",
        "content_pillars": list(PILLAR_WEIGHTS.keys()),
        "hashtags": {"default": ["#buildinpublic", "#growthhacking"]},
        "cta_rotation": [
            "Follow for more.",
            "Repost if this helped.",
            "Bookmark this for later.",
            "Link in bio for the full guide.",
        ],
        "niche": "digital marketing",
        "posting_times": ["09:00", "12:30", "17:00", "20:00"],
    }


def jout(data):
    """Print JSON output."""
    print(json.dumps(data, indent=2, default=str))


def compact_out(full_data, compact_data=None):
    """Output compact or full data based on mode."""
    if COMPACT_MODE and compact_data:
        print(json.dumps(compact_data, indent=2, default=str))
    else:
        print(json.dumps(full_data, indent=2, default=str))


def select_pillar(history=None):
    """Select content pillar based on weighted rotation.

    If history is provided, adjusts weights to favor underrepresented pillars.
    """
    weights = dict(PILLAR_WEIGHTS)

    if history:
        counts = {p: 0 for p in weights}
        for item in history[-20:]:
            p = item.get("pillar", "value")
            if p in counts:
                counts[p] += 1
        total = sum(counts.values()) or 1
        for p in weights:
            actual_ratio = counts[p] / total
            target_ratio = weights[p]
            if actual_ratio > target_ratio * 1.3:
                weights[p] *= 0.5
            elif actual_ratio < target_ratio * 0.7:
                weights[p] *= 1.5

    pillars = list(weights.keys())
    w = list(weights.values())
    total_w = sum(w)
    w = [x / total_w for x in w]
    return random.choices(pillars, weights=w, k=1)[0]


def get_trending_topics(niche, bearer_token):
    """Fetch trending topics via X Search API for niche relevance."""
    import urllib.request
    import urllib.error
    import urllib.parse

    base_url = "https://api.twitter.com/2"
    query = f"{niche} -is:retweet lang:en"
    params = urllib.parse.urlencode({
        "query": query,
        "max_results": 10,
        "tweet.fields": "public_metrics,created_at",
        "sort_order": "relevancy",
    })
    url = f"{base_url}/tweets/search/recent?{params}"

    req = urllib.request.Request(url)
    req.add_header("Authorization", f"Bearer {bearer_token}")
    req.add_header("User-Agent", "OpenClaw-ContentEngine/1.0")

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            tweets = data.get("data", [])
            topics = []
            for t in tweets:
                metrics = t.get("public_metrics", {})
                engagement = (
                    metrics.get("like_count", 0)
                    + metrics.get("retweet_count", 0) * 2
                    + metrics.get("reply_count", 0) * 3
                )
                topics.append({
                    "text": t["text"][:100],
                    "engagement": engagement,
                    "id": t["id"],
                })
            topics.sort(key=lambda x: x["engagement"], reverse=True)
            return topics[:5]
    except (urllib.error.HTTPError, urllib.error.URLError) as e:
        return [{"text": f"Could not fetch trends: {e}", "engagement": 0}]


def generate_post(pillar, niche, config, trending_context=None):
    """Generate a single post based on pillar, niche, and config."""
    templates = DEFAULT_TEMPLATES.get(pillar, DEFAULT_TEMPLATES["value"])
    template = random.choice(templates)

    topic = niche
    if trending_context:
        topic = trending_context.get("text", niche)[:50]

    placeholders = {
        "topic": topic,
        "niche": niche,
        "insight": f"[AI: Generate a specific, actionable insight about {topic} in the {niche} space]",
        "opinion": f"[AI: Generate a bold opinion about {topic}]",
        "story": f"[AI: Generate a brief personal anecdote about {topic}]",
        "lesson": f"[AI: Generate a key takeaway]",
        "before": f"[AI: Describe a before state related to {topic}]",
        "after": f"[AI: Describe a transformed state]",
        "product_desc": f"[AI: Describe your product for {topic}]",
        "product_name": f"[Product Name]",
        "benefit_1": f"- [Benefit 1]",
        "benefit_2": f"- [Benefit 2]",
        "benefit_3": f"- [Benefit 3]",
        "cta": random.choice(config.get("cta_rotation", ["Follow for more."])),
        "number": random.choice(NUMBERS),
        "timeframe": random.choice(TIMEFRAMES),
    }

    post_text = template
    for key, val in placeholders.items():
        post_text = post_text.replace("{" + key + "}", val)

    # Add hashtags
    niche_hashtags = config.get("hashtags", {}).get(niche, config.get("hashtags", {}).get("default", []))
    if niche_hashtags:
        selected_tags = random.sample(niche_hashtags, min(3, len(niche_hashtags)))
        post_text += "\n\n" + " ".join(selected_tags)

    # Calculate optimal posting time
    posting_times = config.get("posting_times", ["09:00", "12:30", "17:00", "20:00"])
    now = datetime.now()
    scheduled_time = None
    for t in posting_times:
        hour, minute = map(int, t.split(":"))
        candidate = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if candidate > now:
            scheduled_time = candidate
            break
    if not scheduled_time:
        hour, minute = map(int, posting_times[0].split(":"))
        scheduled_time = (now + timedelta(days=1)).replace(
            hour=hour, minute=minute, second=0, microsecond=0
        )

    post_id = hashlib.md5(f"{post_text}{now.isoformat()}".encode()).hexdigest()[:12]

    return {
        "id": post_id,
        "text": post_text,
        "pillar": pillar,
        "niche": niche,
        "char_count": len(post_text),
        "hashtags": niche_hashtags[:3] if niche_hashtags else [],
        "scheduled_time": scheduled_time.isoformat(),
        "brand_voice": config.get("brand_voice", "professional"),
        "trending_context": trending_context.get("text", None) if trending_context else None,
    }


def cmd_generate(args):
    """Generate content posts."""
    config = load_config()
    niche = args.niche or config.get("niche", "digital marketing")
    pillar = args.pillar or select_pillar()
    count = args.count

    trending_context = None
    if args.trending:
        token = os.environ.get("X_BEARER_TOKEN", "")
        if token:
            trends = get_trending_topics(niche, token)
            if trends:
                trending_context = trends[0]
        else:
            trending_context = {"text": f"trending in {niche}", "engagement": 0}

    posts = []
    for _ in range(count):
        if not args.pillar:
            pillar = select_pillar(
                [{"pillar": p.get("pillar")} for p in posts] if posts else None
            )
        post = generate_post(pillar, niche, config, trending_context)
        posts.append(post)

    full_data = {
        "success": True,
        "count": len(posts),
        "niche": niche,
        "posts": posts,
        "pillar_distribution": {
            p: sum(1 for x in posts if x["pillar"] == p) for p in PILLAR_WEIGHTS
        },
    }
    compact_out(full_data, {
        "success": True,
        "count": len(posts),
        "posts": [
            {"id": p["id"], "pillar": p["pillar"], "text": p["text"][:80] + "...", "time": p["scheduled_time"]}
            for p in posts
        ],
    })


def cmd_daily_queue(args):
    """Generate a full day's content queue."""
    config = load_config()
    niche = args.niche or config.get("niche", "digital marketing")
    posting_times = config.get("posting_times", ["09:00", "12:30", "17:00", "20:00"])
    count = len(posting_times)

    # Distribute pillars across the day
    pillar_order = []
    remaining = dict(PILLAR_WEIGHTS)
    for _ in range(count):
        pillar = max(remaining, key=remaining.get)
        pillar_order.append(pillar)
        remaining[pillar] -= 1.0 / count

    posts = []
    now = datetime.now()
    for i, (pillar, time_str) in enumerate(zip(pillar_order, posting_times)):
        post = generate_post(pillar, niche, config)
        hour, minute = map(int, time_str.split(":"))
        scheduled = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if scheduled <= now:
            scheduled += timedelta(days=1)
        post["scheduled_time"] = scheduled.isoformat()
        post["queue_position"] = i + 1
        posts.append(post)

    full_data = {
        "success": True,
        "date": now.strftime("%Y-%m-%d"),
        "count": len(posts),
        "posts": posts,
    }
    compact_out(full_data, {
        "success": True,
        "date": now.strftime("%Y-%m-%d"),
        "count": len(posts),
        "posts": [
            {"pos": p["queue_position"], "pillar": p["pillar"], "time": p["scheduled_time"], "preview": p["text"][:60]}
            for p in posts
        ],
    })


def cmd_thread(args):
    """Generate a multi-post thread."""
    config = load_config()
    niche = args.niche or config.get("niche", "digital marketing")
    topic = args.topic
    thread_length = args.length

    posts = []
    # Thread structure: hook -> body posts -> CTA
    for i in range(thread_length):
        if i == 0:
            text = f"[HOOK] {topic} thread:\n\nMost people don't know this about {topic}.\n\nHere's a breakdown (thread):"
        elif i == thread_length - 1:
            cta = random.choice(config.get("cta_rotation", ["Follow for more."]))
            text = f"[CTA] That's the complete guide to {topic}.\n\n{cta}\n\nRepost the first tweet to share this thread."
        else:
            text = f"[BODY {i}/{thread_length - 2}] [AI: Generate point {i} about {topic} — be specific and actionable]"

        posts.append({
            "position": i + 1,
            "text": text,
            "char_count": len(text),
            "type": "hook" if i == 0 else ("cta" if i == thread_length - 1 else "body"),
        })

    full_data = {
        "success": True,
        "topic": topic,
        "niche": niche,
        "thread_length": thread_length,
        "total_chars": sum(p["char_count"] for p in posts),
        "posts": posts,
    }
    compact_out(full_data, {
        "success": True,
        "topic": topic,
        "length": thread_length,
        "posts": [{"pos": p["position"], "type": p["type"], "preview": p["text"][:60]} for p in posts],
    })


def cmd_optimize(args):
    """Analyze and optimize existing post text."""
    text = args.text
    config = load_config()

    analysis = {
        "original_length": len(text),
        "has_hook": text.startswith(("Here", "Stop", "The", "I ", "My ", "Hot", "New")),
        "has_cta": any(cta.lower() in text.lower() for cta in ["follow", "repost", "bookmark", "link", "comment"]),
        "has_hashtags": "#" in text,
        "has_newlines": "\n" in text,
        "word_count": len(text.split()),
    }

    suggestions = []
    if not analysis["has_hook"]:
        suggestions.append("Add a strong hook in the first line to stop the scroll")
    if not analysis["has_cta"]:
        suggestions.append("Add a call-to-action at the end")
    if not analysis["has_hashtags"]:
        niche_tags = config.get("hashtags", {}).get("default", ["#buildinpublic"])
        suggestions.append(f"Add relevant hashtags: {' '.join(niche_tags[:3])}")
    if not analysis["has_newlines"]:
        suggestions.append("Break text into short paragraphs with line breaks for readability")
    if analysis["word_count"] > 50:
        suggestions.append("Consider shortening — posts under 50 words get higher engagement")
    if analysis["word_count"] < 10:
        suggestions.append("Post may be too short — aim for 20-40 words for optimal engagement")

    score = 100
    if not analysis["has_hook"]:
        score -= 20
    if not analysis["has_cta"]:
        score -= 15
    if not analysis["has_hashtags"]:
        score -= 10
    if not analysis["has_newlines"]:
        score -= 10
    if analysis["word_count"] > 50 or analysis["word_count"] < 10:
        score -= 15

    full_data = {
        "success": True,
        "analysis": analysis,
        "score": max(0, score),
        "suggestions": suggestions,
        "optimized_text": text,
    }
    compact_out(full_data, {
        "success": True,
        "score": max(0, score),
        "suggestion_count": len(suggestions),
        "suggestions": suggestions[:3],
    })


def main():
    load_env()

    parser = argparse.ArgumentParser(
        description="Content Engine — AI-powered content generator (OpenClaw)"
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Full verbose output (default is compact to save tokens)"
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # generate
    sp = subparsers.add_parser("generate", help="Generate content posts")
    sp.add_argument("--pillar", choices=list(PILLAR_WEIGHTS.keys()), help="Content pillar")
    sp.add_argument("--niche", type=str, help="Content niche")
    sp.add_argument("--trending", action="store_true", help="Integrate trending topics from X")
    sp.add_argument("--count", type=int, default=1, help="Number of posts to generate (default: 1)")

    # daily-queue
    sp = subparsers.add_parser("daily-queue", help="Generate full day's content queue")
    sp.add_argument("--niche", type=str, help="Content niche")

    # thread
    sp = subparsers.add_parser("thread", help="Generate a multi-post thread")
    sp.add_argument("topic", help="Thread topic")
    sp.add_argument("--niche", type=str, help="Content niche")
    sp.add_argument("--length", type=int, default=7, help="Thread length (default: 7)")

    # optimize
    sp = subparsers.add_parser("optimize", help="Analyze and optimize post text")
    sp.add_argument("text", help="Post text to optimize")

    args = parser.parse_args()

    global COMPACT_MODE
    COMPACT_MODE = not args.verbose

    commands = {
        "generate": cmd_generate,
        "daily-queue": cmd_daily_queue,
        "thread": cmd_thread,
        "optimize": cmd_optimize,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
