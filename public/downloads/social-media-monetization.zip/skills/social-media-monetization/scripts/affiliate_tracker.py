#!/usr/bin/env python3
"""Affiliate Tracker — Commission tracking and contextual affiliate posts.

Manages affiliate links, tracks conversions, generates contextual affiliate
posts, and provides revenue dashboards. SQLite-backed. All output is JSON.
"""

import argparse
import json
import os
import sys
import sqlite3
import hashlib
import random
from datetime import datetime, timedelta
from pathlib import Path

# ── OpenClaw Patterns ────────────────────────────────────────────────────────
OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", str(Path.home() / ".openclaw"))
SKILL_DIR = Path(__file__).resolve().parent.parent
DB_PATH = SKILL_DIR / "data" / "affiliate.db"
COMPACT_MODE = True

# ── Affiliate Post Templates ─────────────────────────────────────────────────
POST_TEMPLATES = [
    "I've been using {name} for {timeframe} and here's the truth:\n\n{review}\n\n{cta}\n\n(affiliate link)",
    "Tools I actually use daily:\n\n{name} — {description}\n\n{cta}",
    "Asked what I use for {category}?\n\n{name}. Every time.\n\n{review}\n\n{cta}",
    "Stop overpaying for {category}.\n\n{name} does it better for less.\n\n{review}\n\n{cta}",
    "My honest {name} review after {timeframe}:\n\n{review}\n\nWorth it? Absolutely.\n\n{cta}",
]

TIMEFRAMES = ["3 months", "6 months", "a year", "2 years"]
CTAS = [
    "Try it free (link in bio)",
    "Link in bio for the best deal",
    "Get started here (link in bio)",
    "Save 20% with my link (bio)",
]


def load_env():
    """Load environment variables from .env file."""
    env_path = Path(OPENCLAW_HOME) / ".env"
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, val = line.split("=", 1)
                    val = val.strip().strip('"').strip("'")
                    if key not in os.environ:
                        os.environ[key] = val


def compact_out(full_data, compact_data=None):
    """Output compact or full data based on mode."""
    if COMPACT_MODE and compact_data:
        print(json.dumps(compact_data, indent=2, default=str))
    else:
        print(json.dumps(full_data, indent=2, default=str))


def init_db():
    """Initialize SQLite database with affiliate tables."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row

    conn.execute("""
        CREATE TABLE IF NOT EXISTS affiliates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            url TEXT NOT NULL,
            short_code TEXT UNIQUE NOT NULL,
            commission_rate REAL NOT NULL DEFAULT 0.0,
            commission_type TEXT DEFAULT 'percentage',
            network TEXT DEFAULT '',
            category TEXT DEFAULT '',
            description TEXT DEFAULT '',
            active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT (datetime('now'))
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS conversions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            affiliate_id INTEGER NOT NULL,
            click_count INTEGER DEFAULT 0,
            conversion_count INTEGER DEFAULT 0,
            commission_earned REAL DEFAULT 0.0,
            period TEXT NOT NULL,
            recorded_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (affiliate_id) REFERENCES affiliates(id)
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS affiliate_posts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            affiliate_id INTEGER NOT NULL,
            post_text TEXT NOT NULL,
            posted_at TEXT DEFAULT NULL,
            tweet_id TEXT DEFAULT NULL,
            created_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (affiliate_id) REFERENCES affiliates(id)
        )
    """)

    conn.execute("CREATE INDEX IF NOT EXISTS idx_conv_affiliate ON conversions(affiliate_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_conv_period ON conversions(period)")
    conn.commit()
    return conn


def generate_short_code(name, url):
    """Generate a unique short code for tracking."""
    raw = f"{name}{url}{datetime.now().isoformat()}"
    return hashlib.md5(raw.encode()).hexdigest()[:8]


def cmd_add(args):
    """Add a new affiliate link."""
    conn = init_db()

    short_code = generate_short_code(args.name, args.url)

    try:
        cursor = conn.execute(
            """INSERT INTO affiliates (name, url, short_code, commission_rate, commission_type, network, category, description)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (args.name, args.url, short_code, args.commission, args.commission_type,
             args.network or "", args.category or "", args.description or "")
        )
        conn.commit()
        affiliate_id = cursor.lastrowid

        full_data = {
            "success": True,
            "id": affiliate_id,
            "name": args.name,
            "url": args.url,
            "short_code": short_code,
            "commission_rate": args.commission,
            "commission_type": args.commission_type,
            "network": args.network or "",
            "category": args.category or "",
        }
        compact_out(full_data, {
            "success": True,
            "id": affiliate_id,
            "name": args.name,
            "code": short_code,
            "commission": f"{args.commission}{'%' if args.commission_type == 'percentage' else ' flat'}",
        })
    except sqlite3.IntegrityError:
        print(json.dumps({"success": False, "error": "Duplicate affiliate link or short code"}))
        sys.exit(1)
    finally:
        conn.close()


def cmd_list(args):
    """List affiliate links."""
    conn = init_db()

    if args.active_only:
        rows = conn.execute("SELECT * FROM affiliates WHERE active = 1 ORDER BY name").fetchall()
    else:
        rows = conn.execute("SELECT * FROM affiliates ORDER BY name").fetchall()

    affiliates = []
    for row in rows:
        # Get total conversions for this affiliate
        stats = conn.execute(
            """SELECT COALESCE(SUM(click_count), 0) as clicks,
                      COALESCE(SUM(conversion_count), 0) as conversions,
                      COALESCE(SUM(commission_earned), 0) as earned
               FROM conversions WHERE affiliate_id = ?""",
            (row["id"],)
        ).fetchone()

        affiliates.append({
            "id": row["id"],
            "name": row["name"],
            "url": row["url"],
            "short_code": row["short_code"],
            "commission_rate": row["commission_rate"],
            "commission_type": row["commission_type"],
            "network": row["network"],
            "category": row["category"],
            "active": bool(row["active"]),
            "total_clicks": stats["clicks"],
            "total_conversions": stats["conversions"],
            "total_earned": round(stats["earned"], 2),
        })

    conn.close()

    full_data = {
        "success": True,
        "count": len(affiliates),
        "total_earned": round(sum(a["total_earned"] for a in affiliates), 2),
        "affiliates": affiliates,
    }
    compact_out(full_data, {
        "success": True,
        "count": len(affiliates),
        "total_earned": full_data["total_earned"],
        "affiliates": [
            {"name": a["name"], "earned": a["total_earned"], "conversions": a["total_conversions"]}
            for a in affiliates
        ],
    })


def cmd_record(args):
    """Record clicks and conversions for an affiliate."""
    conn = init_db()

    # Find affiliate
    affiliate = conn.execute(
        "SELECT * FROM affiliates WHERE id = ? OR short_code = ?",
        (args.affiliate, args.affiliate)
    ).fetchone()

    if not affiliate:
        conn.close()
        print(json.dumps({"success": False, "error": f"Affiliate not found: {args.affiliate}"}))
        sys.exit(1)

    period = args.period or datetime.now().strftime("%Y-%m")
    clicks = args.clicks or 0
    conversions = args.conversions or 0

    # Calculate commission
    if affiliate["commission_type"] == "percentage":
        commission = conversions * (args.sale_amount or 0) * (affiliate["commission_rate"] / 100)
    else:
        commission = conversions * affiliate["commission_rate"]

    # Check for existing record this period
    existing = conn.execute(
        "SELECT id FROM conversions WHERE affiliate_id = ? AND period = ?",
        (affiliate["id"], period)
    ).fetchone()

    if existing:
        conn.execute(
            """UPDATE conversions SET
               click_count = click_count + ?,
               conversion_count = conversion_count + ?,
               commission_earned = commission_earned + ?
               WHERE id = ?""",
            (clicks, conversions, commission, existing["id"])
        )
    else:
        conn.execute(
            """INSERT INTO conversions (affiliate_id, click_count, conversion_count, commission_earned, period)
               VALUES (?, ?, ?, ?, ?)""",
            (affiliate["id"], clicks, conversions, commission, period)
        )

    conn.commit()
    conn.close()

    print(json.dumps({
        "success": True,
        "affiliate": affiliate["name"],
        "period": period,
        "clicks_added": clicks,
        "conversions_added": conversions,
        "commission_added": round(commission, 2),
    }, indent=2))


def cmd_post(args):
    """Generate a contextual affiliate post."""
    conn = init_db()

    # Find affiliate
    affiliate = conn.execute(
        "SELECT * FROM affiliates WHERE id = ? OR short_code = ? OR name LIKE ?",
        (args.affiliate, args.affiliate, f"%{args.affiliate}%")
    ).fetchone()

    if not affiliate:
        conn.close()
        print(json.dumps({"success": False, "error": f"Affiliate not found: {args.affiliate}"}))
        sys.exit(1)

    template = random.choice(POST_TEMPLATES)

    post_text = template.format(
        name=affiliate["name"],
        category=affiliate["category"] or "this",
        description=affiliate["description"] or f"Great tool for {affiliate['category'] or 'your needs'}",
        review=f"[AI: Write a genuine, specific review of {affiliate['name']} for {affiliate['category'] or 'this niche'}]",
        timeframe=random.choice(TIMEFRAMES),
        cta=random.choice(CTAS),
    )

    # Save generated post
    cursor = conn.execute(
        "INSERT INTO affiliate_posts (affiliate_id, post_text) VALUES (?, ?)",
        (affiliate["id"], post_text)
    )
    conn.commit()
    post_id = cursor.lastrowid
    conn.close()

    full_data = {
        "success": True,
        "post_id": post_id,
        "affiliate_name": affiliate["name"],
        "affiliate_url": affiliate["url"],
        "post_text": post_text,
        "char_count": len(post_text),
        "commission_rate": affiliate["commission_rate"],
    }
    compact_out(full_data, {
        "success": True,
        "post_id": post_id,
        "affiliate": affiliate["name"],
        "preview": post_text[:80],
        "chars": len(post_text),
    })


def cmd_dashboard(args):
    """Show affiliate performance dashboard."""
    conn = init_db()

    # Overall stats
    totals = conn.execute("""
        SELECT COALESCE(SUM(click_count), 0) as total_clicks,
               COALESCE(SUM(conversion_count), 0) as total_conversions,
               COALESCE(SUM(commission_earned), 0) as total_earned
        FROM conversions
    """).fetchone()

    # Per-affiliate breakdown
    affiliates = conn.execute("""
        SELECT a.name, a.network, a.category,
               COALESCE(SUM(c.click_count), 0) as clicks,
               COALESCE(SUM(c.conversion_count), 0) as conversions,
               COALESCE(SUM(c.commission_earned), 0) as earned
        FROM affiliates a
        LEFT JOIN conversions c ON a.id = c.affiliate_id
        WHERE a.active = 1
        GROUP BY a.id
        ORDER BY earned DESC
    """).fetchall()

    # Monthly trend (last 6 months)
    months = []
    for i in range(5, -1, -1):
        d = datetime.now() - timedelta(days=i * 30)
        period = d.strftime("%Y-%m")
        row = conn.execute(
            """SELECT COALESCE(SUM(commission_earned), 0) as earned,
                      COALESCE(SUM(conversion_count), 0) as conversions
               FROM conversions WHERE period = ?""",
            (period,)
        ).fetchone()
        months.append({
            "period": period,
            "earned": round(row["earned"], 2),
            "conversions": row["conversions"],
        })

    # Conversion rate
    total_clicks = totals["total_clicks"]
    total_conversions = totals["total_conversions"]
    conv_rate = (total_conversions / total_clicks * 100) if total_clicks > 0 else 0.0

    conn.close()

    breakdown = [
        {
            "name": a["name"],
            "network": a["network"],
            "category": a["category"],
            "clicks": a["clicks"],
            "conversions": a["conversions"],
            "earned": round(a["earned"], 2),
            "conv_rate": round((a["conversions"] / a["clicks"] * 100) if a["clicks"] > 0 else 0, 2),
        }
        for a in affiliates
    ]

    full_data = {
        "success": True,
        "dashboard": {
            "total_clicks": total_clicks,
            "total_conversions": total_conversions,
            "total_earned": round(totals["total_earned"], 2),
            "conversion_rate": round(conv_rate, 2),
            "active_affiliates": len(breakdown),
        },
        "by_affiliate": breakdown,
        "monthly_trend": months,
    }
    compact_out(full_data, {
        "success": True,
        "total_earned": round(totals["total_earned"], 2),
        "total_conversions": total_conversions,
        "conv_rate": round(conv_rate, 2),
        "top_3": [
            {"name": a["name"], "earned": a["earned"]}
            for a in breakdown[:3]
        ],
    })


def cmd_report(args):
    """Generate a detailed affiliate performance report."""
    conn = init_db()
    period = args.period or datetime.now().strftime("%Y-%m")

    # Period data
    period_data = conn.execute("""
        SELECT a.name, a.network, a.commission_rate, a.commission_type,
               COALESCE(c.click_count, 0) as clicks,
               COALESCE(c.conversion_count, 0) as conversions,
               COALESCE(c.commission_earned, 0) as earned
        FROM affiliates a
        LEFT JOIN conversions c ON a.id = c.affiliate_id AND c.period = ?
        WHERE a.active = 1
        ORDER BY earned DESC
    """, (period,)).fetchall()

    # Previous period for comparison
    try:
        year, month = map(int, period.split("-"))
        if month == 1:
            prev_period = f"{year - 1}-12"
        else:
            prev_period = f"{year}-{month - 1:02d}"
    except ValueError:
        prev_period = period

    prev_data = conn.execute(
        "SELECT COALESCE(SUM(commission_earned), 0) as prev_earned FROM conversions WHERE period = ?",
        (prev_period,)
    ).fetchone()

    current_total = sum(r["earned"] for r in period_data)
    prev_total = prev_data["prev_earned"]
    growth = ((current_total - prev_total) / prev_total * 100) if prev_total > 0 else 0.0

    conn.close()

    report = {
        "success": True,
        "period": period,
        "total_earned": round(current_total, 2),
        "previous_period_earned": round(prev_total, 2),
        "growth_pct": round(growth, 2),
        "affiliates": [
            {
                "name": r["name"],
                "network": r["network"],
                "clicks": r["clicks"],
                "conversions": r["conversions"],
                "earned": round(r["earned"], 2),
                "commission_rate": r["commission_rate"],
            }
            for r in period_data
        ],
    }
    compact_out(report, {
        "success": True,
        "period": period,
        "earned": round(current_total, 2),
        "growth": f"{round(growth, 2)}%",
        "top": [{"name": r["name"], "earned": round(r["earned"], 2)} for r in period_data[:3]],
    })


def cmd_deactivate(args):
    """Deactivate an affiliate link."""
    conn = init_db()
    result = conn.execute(
        "UPDATE affiliates SET active = 0 WHERE id = ? OR short_code = ?",
        (args.affiliate, args.affiliate)
    )
    conn.commit()
    if result.rowcount == 0:
        conn.close()
        print(json.dumps({"success": False, "error": f"Affiliate not found: {args.affiliate}"}))
        sys.exit(1)
    conn.close()
    print(json.dumps({"success": True, "deactivated": args.affiliate}, indent=2))


def main():
    load_env()

    parser = argparse.ArgumentParser(
        description="Affiliate Tracker — Commission tracking and affiliate posts (OpenClaw)"
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Full verbose output (default is compact to save tokens)"
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # add
    sp = subparsers.add_parser("add", help="Add a new affiliate link")
    sp.add_argument("--name", required=True, help="Product/service name")
    sp.add_argument("--url", required=True, help="Affiliate URL")
    sp.add_argument("--commission", type=float, required=True, help="Commission rate")
    sp.add_argument("--commission-type", default="percentage", choices=["percentage", "flat"],
                     help="Commission type (default: percentage)")
    sp.add_argument("--network", help="Affiliate network (e.g., Impact, ShareASale)")
    sp.add_argument("--category", help="Product category")
    sp.add_argument("--description", help="Product description")

    # list
    sp = subparsers.add_parser("list", help="List affiliate links")
    sp.add_argument("--active-only", action="store_true", default=True, help="Show only active (default)")
    sp.add_argument("--all", dest="active_only", action="store_false", help="Show all including inactive")

    # record
    sp = subparsers.add_parser("record", help="Record clicks/conversions")
    sp.add_argument("affiliate", help="Affiliate ID or short code")
    sp.add_argument("--clicks", type=int, default=0, help="Number of clicks")
    sp.add_argument("--conversions", type=int, default=0, help="Number of conversions")
    sp.add_argument("--sale-amount", type=float, default=0, help="Sale amount (for percentage commission)")
    sp.add_argument("--period", help="Period (YYYY-MM, default: current month)")

    # post
    sp = subparsers.add_parser("post", help="Generate contextual affiliate post")
    sp.add_argument("affiliate", help="Affiliate ID, short code, or name")

    # dashboard
    subparsers.add_parser("dashboard", help="Show affiliate performance dashboard")

    # report
    sp = subparsers.add_parser("report", help="Generate detailed report")
    sp.add_argument("--period", help="Period (YYYY-MM, default: current month)")

    # deactivate
    sp = subparsers.add_parser("deactivate", help="Deactivate an affiliate link")
    sp.add_argument("affiliate", help="Affiliate ID or short code")

    args = parser.parse_args()

    global COMPACT_MODE
    COMPACT_MODE = not args.verbose

    commands = {
        "add": cmd_add,
        "list": cmd_list,
        "record": cmd_record,
        "post": cmd_post,
        "dashboard": cmd_dashboard,
        "report": cmd_report,
        "deactivate": cmd_deactivate,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
