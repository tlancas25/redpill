#!/usr/bin/env python3
"""Social Analytics — Performance dashboard for X/Twitter accounts.

Pulls engagement data from X Analytics API, calculates best posting times,
content type performance, and engagement trends. All output is JSON.
"""

import argparse
import json
import os
import sys
import urllib.request
import urllib.error
import urllib.parse
from datetime import datetime, timedelta
from collections import defaultdict
from pathlib import Path

# ── OpenClaw Patterns ────────────────────────────────────────────────────────
OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", str(Path.home() / ".openclaw"))
BASE_URL = "https://api.twitter.com/2"
COMPACT_MODE = True


def load_env():
    """Load environment variables from .env file."""
    env_path = Path(OPENCLAW_HOME) / ".env"
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, val = line.split("=", 1)
                    val = val.strip().strip('"').strip("'")
                    if key not in os.environ:
                        os.environ[key] = val


def get_bearer_token():
    """Load bearer token from environment."""
    token = os.environ.get("X_BEARER_TOKEN", "")
    if not token:
        print(json.dumps({
            "success": False,
            "error": "Missing X_BEARER_TOKEN environment variable",
        }))
        sys.exit(1)
    return token


def get_user_id():
    """Load authenticated user ID from environment or look it up."""
    user_id = os.environ.get("X_USER_ID", "")
    if not user_id:
        username = os.environ.get("X_USERNAME", "")
        if username:
            token = get_bearer_token()
            data = api_get(f"users/by/username/{username}", {}, token)
            user_id = data.get("data", {}).get("id", "")
        if not user_id:
            print(json.dumps({
                "success": False,
                "error": "Set X_USER_ID or X_USERNAME environment variable",
            }))
            sys.exit(1)
    return user_id


def api_get(endpoint, params, token):
    """Make authenticated GET request to X API v2."""
    url = f"{BASE_URL}/{endpoint}"
    if params:
        query_string = urllib.parse.urlencode(params, quote_via=urllib.parse.quote)
        url = f"{url}?{query_string}"

    req = urllib.request.Request(url)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("User-Agent", "OpenClaw-SocialAnalytics/1.0")

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        if e.code == 429:
            retry = e.headers.get("retry-after", "unknown")
            print(json.dumps({
                "success": False, "error": "Rate limited (429)",
                "retry_after_seconds": retry,
            }))
        elif e.code == 401:
            print(json.dumps({"success": False, "error": "Unauthorized (401). Check bearer token."}))
        elif e.code == 403:
            print(json.dumps({"success": False, "error": "Forbidden (403). Check API access level."}))
        else:
            print(json.dumps({"success": False, "error": f"HTTP {e.code}", "details": body[:200]}))
        sys.exit(1)
    except urllib.error.URLError as e:
        print(json.dumps({"success": False, "error": f"Connection error: {e.reason}"}))
        sys.exit(1)


def compact_out(full_data, compact_data=None):
    """Output compact or full data based on mode."""
    if COMPACT_MODE and compact_data:
        print(json.dumps(compact_data, indent=2, default=str))
    else:
        print(json.dumps(full_data, indent=2, default=str))


def get_period_dates(period):
    """Convert period string to start/end dates."""
    now = datetime.now()
    if period == "day":
        start = now - timedelta(days=1)
    elif period == "week":
        start = now - timedelta(weeks=1)
    elif period == "month":
        start = now - timedelta(days=30)
    elif period == "quarter":
        start = now - timedelta(days=90)
    else:
        start = now - timedelta(weeks=1)
    return start, now


def fetch_user_tweets(user_id, token, max_results=100, start_time=None):
    """Fetch user's recent tweets with metrics."""
    params = {
        "max_results": min(max_results, 100),
        "tweet.fields": "created_at,public_metrics,source,entities",
        "exclude": "retweets",
    }
    if start_time:
        params["start_time"] = start_time.strftime("%Y-%m-%dT%H:%M:%SZ")

    data = api_get(f"users/{user_id}/tweets", params, token)
    return data.get("data", [])


def classify_content_type(tweet):
    """Classify a tweet by content type based on text patterns."""
    text = tweet.get("text", "")
    entities = tweet.get("entities", {})

    if text.count("\n") > 3:
        return "thread_hook"
    if entities.get("urls"):
        return "link_share"
    if any(c in text for c in ["?", "Agree", "disagree", "What do you", "Rate your"]):
        return "engagement"
    if any(c in text for c in ["I ", "My ", "my "]):
        return "personal"
    if any(c in text for c in ["link in bio", "check out", "new:", "just dropped"]):
        return "promotional"
    return "value"


def cmd_report(args):
    """Generate engagement performance report."""
    token = get_bearer_token()
    user_id = get_user_id()
    start, end = get_period_dates(args.period)

    tweets = fetch_user_tweets(user_id, token, max_results=100, start_time=start)

    if not tweets:
        print(json.dumps({"success": True, "message": "No tweets found in this period", "count": 0}))
        return

    # Calculate metrics
    total_likes = 0
    total_retweets = 0
    total_replies = 0
    total_impressions = 0
    total_quotes = 0

    tweet_data = []
    for t in tweets:
        m = t.get("public_metrics", {})
        likes = m.get("like_count", 0)
        retweets = m.get("retweet_count", 0)
        replies = m.get("reply_count", 0)
        impressions = m.get("impression_count", 0)
        quotes = m.get("quote_count", 0)

        total_likes += likes
        total_retweets += retweets
        total_replies += replies
        total_impressions += impressions
        total_quotes += quotes

        engagement = likes + retweets + replies + quotes
        eng_rate = (engagement / impressions * 100) if impressions > 0 else 0.0

        tweet_data.append({
            "id": t["id"],
            "text": t["text"][:100],
            "created_at": t.get("created_at", ""),
            "content_type": classify_content_type(t),
            "likes": likes,
            "retweets": retweets,
            "replies": replies,
            "impressions": impressions,
            "engagement_rate": round(eng_rate, 2),
        })

    # Sort by engagement rate
    tweet_data.sort(key=lambda x: x["engagement_rate"], reverse=True)

    total_engagement = total_likes + total_retweets + total_replies + total_quotes
    avg_eng_rate = (total_engagement / total_impressions * 100) if total_impressions > 0 else 0.0

    full_data = {
        "success": True,
        "period": args.period,
        "tweet_count": len(tweets),
        "summary": {
            "total_impressions": total_impressions,
            "total_engagement": total_engagement,
            "total_likes": total_likes,
            "total_retweets": total_retweets,
            "total_replies": total_replies,
            "avg_engagement_rate": round(avg_eng_rate, 2),
            "avg_likes_per_post": round(total_likes / len(tweets), 1),
            "avg_retweets_per_post": round(total_retweets / len(tweets), 1),
        },
        "top_posts": tweet_data[:5],
        "all_posts": tweet_data,
    }
    compact_out(full_data, {
        "success": True,
        "period": args.period,
        "tweets": len(tweets),
        "impressions": total_impressions,
        "eng_rate": round(avg_eng_rate, 2),
        "likes": total_likes,
        "retweets": total_retweets,
        "top_3": [
            {"text": t["text"][:50], "eng_rate": t["engagement_rate"]}
            for t in tweet_data[:3]
        ],
    })


def cmd_growth(args):
    """Analyze follower and engagement growth."""
    token = get_bearer_token()
    user_id = get_user_id()

    # Get current user metrics
    params = {"user.fields": "public_metrics,created_at"}
    user_data = api_get(f"users/{user_id}", params, token)
    user = user_data.get("data", {})
    metrics = user.get("public_metrics", {})

    followers = metrics.get("followers_count", 0)
    following = metrics.get("following_count", 0)
    tweet_count = metrics.get("tweet_count", 0)
    listed = metrics.get("listed_count", 0)

    # Fetch recent tweets for engagement trend
    start = datetime.now() - timedelta(days=30)
    tweets = fetch_user_tweets(user_id, token, max_results=100, start_time=start)

    # Weekly engagement breakdown
    weekly = defaultdict(lambda: {"tweets": 0, "likes": 0, "retweets": 0, "impressions": 0})
    for t in tweets:
        created = t.get("created_at", "")
        if created:
            try:
                dt = datetime.fromisoformat(created.replace("Z", "+00:00"))
                week_key = dt.strftime("%Y-W%U")
                m = t.get("public_metrics", {})
                weekly[week_key]["tweets"] += 1
                weekly[week_key]["likes"] += m.get("like_count", 0)
                weekly[week_key]["retweets"] += m.get("retweet_count", 0)
                weekly[week_key]["impressions"] += m.get("impression_count", 0)
            except (ValueError, TypeError):
                pass

    weeks_sorted = sorted(weekly.items())
    trend = []
    for week, data in weeks_sorted:
        eng = data["likes"] + data["retweets"]
        rate = (eng / data["impressions"] * 100) if data["impressions"] > 0 else 0
        trend.append({
            "week": week,
            "tweets": data["tweets"],
            "likes": data["likes"],
            "impressions": data["impressions"],
            "engagement_rate": round(rate, 2),
        })

    # Calculate growth trajectory
    ratio = followers / max(following, 1)

    full_data = {
        "success": True,
        "current": {
            "followers": followers,
            "following": following,
            "ratio": round(ratio, 2),
            "tweet_count": tweet_count,
            "listed": listed,
        },
        "engagement_trend": trend,
        "posts_last_30d": len(tweets),
        "avg_posts_per_week": round(len(tweets) / 4.3, 1),
    }
    compact_out(full_data, {
        "success": True,
        "followers": followers,
        "ratio": round(ratio, 2),
        "posts_30d": len(tweets),
        "trend": [{"week": t["week"], "eng_rate": t["engagement_rate"]} for t in trend[-4:]],
    })


def cmd_timing(args):
    """Calculate best posting times based on engagement data."""
    token = get_bearer_token()
    user_id = get_user_id()

    start = datetime.now() - timedelta(days=30)
    tweets = fetch_user_tweets(user_id, token, max_results=100, start_time=start)

    if not tweets:
        print(json.dumps({"success": True, "message": "No tweets to analyze", "count": 0}))
        return

    # Group by hour of day and day of week
    hourly = defaultdict(lambda: {"count": 0, "total_engagement": 0, "total_impressions": 0})
    daily = defaultdict(lambda: {"count": 0, "total_engagement": 0, "total_impressions": 0})

    for t in tweets:
        created = t.get("created_at", "")
        if not created:
            continue
        try:
            dt = datetime.fromisoformat(created.replace("Z", "+00:00"))
            hour = dt.hour
            day = dt.strftime("%A")
            m = t.get("public_metrics", {})
            engagement = (m.get("like_count", 0) + m.get("retweet_count", 0) +
                         m.get("reply_count", 0) + m.get("quote_count", 0))
            impressions = m.get("impression_count", 0)

            hourly[hour]["count"] += 1
            hourly[hour]["total_engagement"] += engagement
            hourly[hour]["total_impressions"] += impressions

            daily[day]["count"] += 1
            daily[day]["total_engagement"] += engagement
            daily[day]["total_impressions"] += impressions
        except (ValueError, TypeError):
            continue

    # Calculate avg engagement per hour
    best_hours = []
    for hour, data in sorted(hourly.items()):
        avg_eng = data["total_engagement"] / data["count"] if data["count"] > 0 else 0
        avg_imp = data["total_impressions"] / data["count"] if data["count"] > 0 else 0
        eng_rate = (data["total_engagement"] / data["total_impressions"] * 100) if data["total_impressions"] > 0 else 0
        best_hours.append({
            "hour": f"{hour:02d}:00",
            "posts": data["count"],
            "avg_engagement": round(avg_eng, 1),
            "avg_impressions": round(avg_imp, 0),
            "engagement_rate": round(eng_rate, 2),
        })

    best_hours.sort(key=lambda x: x["avg_engagement"], reverse=True)

    # Best days
    best_days = []
    day_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    for day in day_order:
        if day in daily:
            data = daily[day]
            avg_eng = data["total_engagement"] / data["count"] if data["count"] > 0 else 0
            eng_rate = (data["total_engagement"] / data["total_impressions"] * 100) if data["total_impressions"] > 0 else 0
            best_days.append({
                "day": day,
                "posts": data["count"],
                "avg_engagement": round(avg_eng, 1),
                "engagement_rate": round(eng_rate, 2),
            })

    best_days.sort(key=lambda x: x["avg_engagement"], reverse=True)

    # Top 4 recommended posting times
    recommended = []
    for h in best_hours[:4]:
        recommended.append(h["hour"])

    full_data = {
        "success": True,
        "analyzed_posts": len(tweets),
        "recommended_times": recommended,
        "by_hour": best_hours,
        "by_day": best_days,
    }
    compact_out(full_data, {
        "success": True,
        "posts_analyzed": len(tweets),
        "best_times": recommended,
        "best_days": [d["day"] for d in best_days[:3]],
    })


def cmd_content_breakdown(args):
    """Analyze performance by content type."""
    token = get_bearer_token()
    user_id = get_user_id()

    start = datetime.now() - timedelta(days=30)
    tweets = fetch_user_tweets(user_id, token, max_results=100, start_time=start)

    if not tweets:
        print(json.dumps({"success": True, "message": "No tweets to analyze", "count": 0}))
        return

    # Group by content type
    by_type = defaultdict(lambda: {
        "count": 0, "likes": 0, "retweets": 0, "replies": 0,
        "impressions": 0, "quotes": 0,
    })

    for t in tweets:
        ctype = classify_content_type(t)
        m = t.get("public_metrics", {})
        by_type[ctype]["count"] += 1
        by_type[ctype]["likes"] += m.get("like_count", 0)
        by_type[ctype]["retweets"] += m.get("retweet_count", 0)
        by_type[ctype]["replies"] += m.get("reply_count", 0)
        by_type[ctype]["impressions"] += m.get("impression_count", 0)
        by_type[ctype]["quotes"] += m.get("quote_count", 0)

    breakdown = []
    for ctype, data in by_type.items():
        total_eng = data["likes"] + data["retweets"] + data["replies"] + data["quotes"]
        eng_rate = (total_eng / data["impressions"] * 100) if data["impressions"] > 0 else 0
        breakdown.append({
            "type": ctype,
            "count": data["count"],
            "pct_of_total": round(data["count"] / len(tweets) * 100, 1),
            "total_likes": data["likes"],
            "total_retweets": data["retweets"],
            "total_replies": data["replies"],
            "total_impressions": data["impressions"],
            "avg_engagement": round(total_eng / data["count"], 1) if data["count"] > 0 else 0,
            "engagement_rate": round(eng_rate, 2),
        })

    breakdown.sort(key=lambda x: x["engagement_rate"], reverse=True)

    # Recommendation
    best_type = breakdown[0]["type"] if breakdown else "value"
    worst_type = breakdown[-1]["type"] if len(breakdown) > 1 else None

    recommendations = []
    if best_type:
        recommendations.append(f"Double down on '{best_type}' posts — highest engagement rate")
    if worst_type and worst_type != best_type:
        recommendations.append(f"Reduce '{worst_type}' posts or improve their quality")

    full_data = {
        "success": True,
        "analyzed_posts": len(tweets),
        "breakdown": breakdown,
        "recommendations": recommendations,
    }
    compact_out(full_data, {
        "success": True,
        "posts": len(tweets),
        "breakdown": [
            {"type": b["type"], "count": b["count"], "eng_rate": b["engagement_rate"]}
            for b in breakdown
        ],
        "tip": recommendations[0] if recommendations else None,
    })


def main():
    load_env()

    parser = argparse.ArgumentParser(
        description="Social Analytics — Performance dashboard for X (OpenClaw)"
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Full verbose output (default is compact to save tokens)"
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # report
    sp = subparsers.add_parser("report", help="Generate engagement report")
    sp.add_argument("--period", default="week", choices=["day", "week", "month", "quarter"],
                     help="Report period (default: week)")

    # growth
    subparsers.add_parser("growth", help="Analyze growth trends")

    # timing
    subparsers.add_parser("timing", help="Calculate best posting times")

    # content-breakdown
    subparsers.add_parser("content-breakdown", help="Performance by content type")

    args = parser.parse_args()

    global COMPACT_MODE
    COMPACT_MODE = not args.verbose

    commands = {
        "report": cmd_report,
        "growth": cmd_growth,
        "timing": cmd_timing,
        "content-breakdown": cmd_content_breakdown,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
