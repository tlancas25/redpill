#!/usr/bin/env python3
"""Content Scheduler — SQLite-backed content queue manager.

Manages a queue of posts with scheduling, status tracking, and
integration with the x-post skill for publishing. All output is JSON.
"""

import argparse
import json
import os
import sys
import sqlite3
import subprocess
from datetime import datetime
from pathlib import Path

# ── OpenClaw Patterns ────────────────────────────────────────────────────────
OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", str(Path.home() / ".openclaw"))
SKILL_DIR = Path(__file__).resolve().parent.parent
DB_PATH = SKILL_DIR / "data" / "scheduler.db"
COMPACT_MODE = True

# ── X-Post Skill Path ───────────────────────────────────────────────────────
X_POST_SCRIPT = Path(OPENCLAW_HOME) / "workspace" / "skills" / "x-post" / "scripts" / "x_post.py"


def load_env():
    """Load environment variables from .env file."""
    env_path = Path(OPENCLAW_HOME) / ".env"
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, val = line.split("=", 1)
                    val = val.strip().strip('"').strip("'")
                    if key not in os.environ:
                        os.environ[key] = val


def compact_out(full_data, compact_data=None):
    """Output compact or full data based on mode."""
    if COMPACT_MODE and compact_data:
        print(json.dumps(compact_data, indent=2, default=str))
    else:
        print(json.dumps(full_data, indent=2, default=str))


def init_db():
    """Initialize SQLite database and create tables if needed."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            text TEXT NOT NULL,
            scheduled_time TEXT NOT NULL,
            status TEXT DEFAULT 'queued',
            pillar TEXT DEFAULT '',
            media_path TEXT DEFAULT '',
            hashtags TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now')),
            published_at TEXT DEFAULT NULL,
            tweet_id TEXT DEFAULT NULL,
            error TEXT DEFAULT NULL
        )
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_queue_status ON queue(status)
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_queue_scheduled ON queue(scheduled_time)
    """)
    conn.commit()
    return conn


def cmd_list(args):
    """List queued content."""
    conn = init_db()
    status_filter = args.status

    if status_filter == "all":
        rows = conn.execute(
            "SELECT * FROM queue ORDER BY scheduled_time ASC"
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM queue WHERE status = ? ORDER BY scheduled_time ASC",
            (status_filter,)
        ).fetchall()

    items = []
    for row in rows:
        items.append({
            "id": row["id"],
            "text": row["text"],
            "scheduled_time": row["scheduled_time"],
            "status": row["status"],
            "pillar": row["pillar"],
            "media_path": row["media_path"],
            "created_at": row["created_at"],
            "published_at": row["published_at"],
            "tweet_id": row["tweet_id"],
            "error": row["error"],
        })

    conn.close()

    # Status summary
    status_counts = {}
    for item in items:
        s = item["status"]
        status_counts[s] = status_counts.get(s, 0) + 1

    full_data = {
        "success": True,
        "count": len(items),
        "status_filter": status_filter,
        "status_summary": status_counts,
        "items": items,
    }
    compact_out(full_data, {
        "success": True,
        "count": len(items),
        "status_summary": status_counts,
        "items": [
            {"id": i["id"], "status": i["status"], "time": i["scheduled_time"], "preview": i["text"][:60]}
            for i in items[:20]
        ],
    })


def cmd_add(args):
    """Add a post to the queue."""
    conn = init_db()

    text = args.text
    scheduled_time = args.time or datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    media_path = args.media or ""
    pillar = args.pillar or ""

    if args.dry_run:
        print(json.dumps({
            "success": True,
            "dry_run": True,
            "would_add": {
                "text": text,
                "scheduled_time": scheduled_time,
                "pillar": pillar,
                "media_path": media_path,
            },
        }, indent=2))
        return

    cursor = conn.execute(
        """INSERT INTO queue (text, scheduled_time, pillar, media_path)
           VALUES (?, ?, ?, ?)""",
        (text, scheduled_time, pillar, media_path)
    )
    conn.commit()
    post_id = cursor.lastrowid
    conn.close()

    full_data = {
        "success": True,
        "id": post_id,
        "text": text,
        "scheduled_time": scheduled_time,
        "pillar": pillar,
        "status": "queued",
    }
    compact_out(full_data, {
        "success": True,
        "id": post_id,
        "scheduled_time": scheduled_time,
        "preview": text[:60],
    })


def cmd_import(args):
    """Import posts from stdin (JSON array or newline-delimited JSON)."""
    conn = init_db()

    try:
        raw = sys.stdin.read().strip()
        if not raw:
            print(json.dumps({"success": False, "error": "No input received on stdin"}))
            sys.exit(1)

        # Try parsing as JSON array first
        try:
            posts = json.loads(raw)
            if isinstance(posts, dict):
                # If it's a single object, or has a "posts" key
                posts = posts.get("posts", [posts])
        except json.JSONDecodeError:
            # Try newline-delimited JSON
            posts = []
            for line in raw.split("\n"):
                line = line.strip()
                if line:
                    posts.append(json.loads(line))

        imported = 0
        errors = 0
        for post in posts:
            text = post.get("text", "")
            if not text:
                errors += 1
                continue
            scheduled_time = post.get("scheduled_time", datetime.now().strftime("%Y-%m-%dT%H:%M:%S"))
            pillar = post.get("pillar", "")
            media_path = post.get("media_path", "")

            if args.dry_run:
                imported += 1
                continue

            conn.execute(
                """INSERT INTO queue (text, scheduled_time, pillar, media_path)
                   VALUES (?, ?, ?, ?)""",
                (text, scheduled_time, pillar, media_path)
            )
            imported += 1

        if not args.dry_run:
            conn.commit()
        conn.close()

        print(json.dumps({
            "success": True,
            "dry_run": args.dry_run,
            "imported": imported,
            "errors": errors,
        }, indent=2))

    except json.JSONDecodeError as e:
        print(json.dumps({"success": False, "error": f"Invalid JSON input: {e}"}))
        sys.exit(1)
    except Exception as e:
        print(json.dumps({"success": False, "error": str(e)}))
        sys.exit(1)


def cmd_publish_next(args):
    """Publish the next queued post that is due."""
    conn = init_db()
    now = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")

    # Find next due post
    row = conn.execute(
        """SELECT * FROM queue
           WHERE status = 'queued' AND scheduled_time <= ?
           ORDER BY scheduled_time ASC
           LIMIT 1""",
        (now,)
    ).fetchone()

    if not row:
        # Check if there are any queued posts at all
        next_post = conn.execute(
            "SELECT scheduled_time FROM queue WHERE status = 'queued' ORDER BY scheduled_time ASC LIMIT 1"
        ).fetchone()

        msg = "No posts due for publishing"
        if next_post:
            msg += f". Next scheduled: {next_post['scheduled_time']}"

        conn.close()
        print(json.dumps({"success": True, "message": msg, "published": False}, indent=2))
        return

    post_id = row["id"]
    text = row["text"]

    if args.dry_run:
        conn.close()
        print(json.dumps({
            "success": True,
            "dry_run": True,
            "would_publish": {
                "id": post_id,
                "text": text[:100],
                "scheduled_time": row["scheduled_time"],
            },
        }, indent=2))
        return

    # Attempt to publish via x-post skill
    tweet_id = None
    error = None

    if X_POST_SCRIPT.exists():
        try:
            result = subprocess.run(
                ["python3", str(X_POST_SCRIPT), "post", text],
                capture_output=True, text=True, timeout=30,
                env={**os.environ}
            )
            if result.returncode == 0:
                try:
                    output = json.loads(result.stdout)
                    tweet_id = output.get("tweet_id", output.get("id", ""))
                except json.JSONDecodeError:
                    tweet_id = "published"
            else:
                error = result.stderr[:200] if result.stderr else "Unknown publish error"
        except subprocess.TimeoutExpired:
            error = "Publish command timed out"
        except Exception as e:
            error = str(e)
    else:
        error = f"x-post skill not found at {X_POST_SCRIPT}. Install x-post skill or publish manually."

    # Update status
    if error:
        conn.execute(
            "UPDATE queue SET status = 'failed', error = ? WHERE id = ?",
            (error, post_id)
        )
        status = "failed"
    else:
        conn.execute(
            "UPDATE queue SET status = 'published', published_at = ?, tweet_id = ? WHERE id = ?",
            (datetime.now().isoformat(), str(tweet_id), post_id)
        )
        status = "published"

    conn.commit()
    conn.close()

    full_data = {
        "success": status == "published",
        "id": post_id,
        "status": status,
        "text": text,
        "tweet_id": tweet_id,
        "error": error,
    }
    compact_out(full_data, {
        "success": status == "published",
        "id": post_id,
        "status": status,
        "tweet_id": tweet_id,
        "error": error,
    })


def cmd_clear(args):
    """Clear posts from the queue by status."""
    conn = init_db()
    status = args.status

    if args.dry_run:
        count = conn.execute(
            "SELECT COUNT(*) as cnt FROM queue WHERE status = ?", (status,)
        ).fetchone()["cnt"]
        conn.close()
        print(json.dumps({
            "success": True,
            "dry_run": True,
            "would_clear": count,
            "status": status,
        }, indent=2))
        return

    cursor = conn.execute("DELETE FROM queue WHERE status = ?", (status,))
    deleted = cursor.rowcount
    conn.commit()

    # Get remaining counts
    remaining = conn.execute(
        "SELECT status, COUNT(*) as cnt FROM queue GROUP BY status"
    ).fetchall()
    remaining_map = {r["status"]: r["cnt"] for r in remaining}
    conn.close()

    print(json.dumps({
        "success": True,
        "cleared": deleted,
        "status": status,
        "remaining": remaining_map,
    }, indent=2))


def cmd_update(args):
    """Update a queued post."""
    conn = init_db()

    row = conn.execute("SELECT * FROM queue WHERE id = ?", (args.id,)).fetchone()
    if not row:
        conn.close()
        print(json.dumps({"success": False, "error": f"Post {args.id} not found"}))
        sys.exit(1)

    if row["status"] != "queued":
        conn.close()
        print(json.dumps({
            "success": False,
            "error": f"Cannot update post with status '{row['status']}'. Only 'queued' posts can be updated.",
        }))
        sys.exit(1)

    updates = []
    params = []
    if args.text:
        updates.append("text = ?")
        params.append(args.text)
    if args.time:
        updates.append("scheduled_time = ?")
        params.append(args.time)

    if not updates:
        conn.close()
        print(json.dumps({"success": False, "error": "Nothing to update. Provide --text or --time."}))
        sys.exit(1)

    params.append(args.id)
    conn.execute(f"UPDATE queue SET {', '.join(updates)} WHERE id = ?", params)
    conn.commit()

    updated = conn.execute("SELECT * FROM queue WHERE id = ?", (args.id,)).fetchone()
    conn.close()

    print(json.dumps({
        "success": True,
        "id": args.id,
        "text": updated["text"][:100],
        "scheduled_time": updated["scheduled_time"],
        "status": updated["status"],
    }, indent=2))


def main():
    load_env()

    parser = argparse.ArgumentParser(
        description="Content Scheduler — SQLite-backed queue manager (OpenClaw)"
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Full verbose output (default is compact to save tokens)"
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # list
    sp = subparsers.add_parser("list", help="List queued content")
    sp.add_argument("--status", default="queued", choices=["queued", "published", "failed", "all"],
                     help="Filter by status (default: queued)")

    # add
    sp = subparsers.add_parser("add", help="Add a post to the queue")
    sp.add_argument("--text", required=True, help="Post text")
    sp.add_argument("--time", help="Scheduled time (ISO format, default: now)")
    sp.add_argument("--media", help="Path to media file")
    sp.add_argument("--pillar", help="Content pillar tag")
    sp.add_argument("--dry-run", action="store_true", help="Preview without adding")

    # import
    sp = subparsers.add_parser("import", help="Import posts from stdin (JSON)")
    sp.add_argument("--dry-run", action="store_true", help="Preview without importing")

    # publish-next
    sp = subparsers.add_parser("publish-next", help="Publish next due post")
    sp.add_argument("--dry-run", action="store_true", help="Preview without publishing")

    # clear
    sp = subparsers.add_parser("clear", help="Clear posts by status")
    sp.add_argument("--status", required=True, choices=["queued", "published", "failed"],
                     help="Status to clear")
    sp.add_argument("--dry-run", action="store_true", help="Preview without clearing")

    # update
    sp = subparsers.add_parser("update", help="Update a queued post")
    sp.add_argument("id", type=int, help="Post ID to update")
    sp.add_argument("--text", help="New post text")
    sp.add_argument("--time", help="New scheduled time")

    args = parser.parse_args()

    global COMPACT_MODE
    COMPACT_MODE = not args.verbose

    commands = {
        "list": cmd_list,
        "add": cmd_add,
        "import": cmd_import,
        "publish-next": cmd_publish_next,
        "clear": cmd_clear,
        "update": cmd_update,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
