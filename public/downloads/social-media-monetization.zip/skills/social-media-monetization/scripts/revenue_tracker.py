#!/usr/bin/env python3
"""Revenue Tracker — Unified revenue dashboard combining Stripe + affiliate data.

Pulls payment data from Stripe API, combines with affiliate tracker data,
calculates MRR, revenue by stream, and growth projections. All output is JSON.
"""

import argparse
import json
import os
import sys
import sqlite3
from datetime import datetime, timedelta
from collections import defaultdict
from pathlib import Path

# ── OpenClaw Patterns ────────────────────────────────────────────────────────
OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", str(Path.home() / ".openclaw"))
SKILL_DIR = Path(__file__).resolve().parent.parent
AFFILIATE_DB = SKILL_DIR / "data" / "affiliate.db"
COMPACT_MODE = True


def load_env():
    """Load environment variables from .env file."""
    env_path = Path(OPENCLAW_HOME) / ".env"
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, val = line.split("=", 1)
                    val = val.strip().strip('"').strip("'")
                    if key not in os.environ:
                        os.environ[key] = val


def compact_out(full_data, compact_data=None):
    """Output compact or full data based on mode."""
    if COMPACT_MODE and compact_data:
        print(json.dumps(compact_data, indent=2, default=str))
    else:
        print(json.dumps(full_data, indent=2, default=str))


def init_stripe():
    """Initialize Stripe client."""
    try:
        import stripe
    except ImportError:
        print(json.dumps({"success": False, "error": "stripe not installed. Run: pip3 install stripe"}))
        sys.exit(1)

    api_key = os.environ.get("STRIPE_SECRET_KEY", "")
    if not api_key:
        env_path = Path(OPENCLAW_HOME) / ".env"
        if env_path.exists():
            with open(env_path) as f:
                for line in f:
                    if line.startswith("STRIPE_SECRET_KEY="):
                        api_key = line.split("=", 1)[1].strip().strip('"').strip("'")
                        break

    if not api_key:
        print(json.dumps({
            "success": False,
            "error": "STRIPE_SECRET_KEY not found",
            "hint": "Set STRIPE_SECRET_KEY in ~/.openclaw/.env",
        }))
        sys.exit(1)

    stripe.api_key = api_key
    return stripe


def get_affiliate_data():
    """Pull aggregate affiliate data from SQLite."""
    if not AFFILIATE_DB.exists():
        return {"total_earned": 0, "total_conversions": 0, "monthly": {}}

    conn = sqlite3.connect(str(AFFILIATE_DB))
    conn.row_factory = sqlite3.Row

    totals = conn.execute("""
        SELECT COALESCE(SUM(commission_earned), 0) as earned,
               COALESCE(SUM(conversion_count), 0) as conversions
        FROM conversions
    """).fetchone()

    monthly = {}
    rows = conn.execute("""
        SELECT period, SUM(commission_earned) as earned, SUM(conversion_count) as conversions
        FROM conversions GROUP BY period ORDER BY period
    """).fetchall()
    for row in rows:
        monthly[row["period"]] = {
            "earned": round(row["earned"], 2),
            "conversions": row["conversions"],
        }

    conn.close()
    return {
        "total_earned": round(totals["earned"], 2),
        "total_conversions": totals["conversions"],
        "monthly": monthly,
    }


def cmd_dashboard(args):
    """Show unified revenue dashboard."""
    stripe = init_stripe()
    affiliate_data = get_affiliate_data()

    try:
        # Stripe balance
        balance = stripe.Balance.retrieve()
        available = balance.available[0].amount / 100 if balance.available else 0
        pending = balance.pending[0].amount / 100 if balance.pending else 0

        # Recent charges (last 30 days)
        thirty_days_ago = int((datetime.now() - timedelta(days=30)).timestamp())
        charges = stripe.Charge.list(limit=100, created={"gte": thirty_days_ago})
        total_charges = sum(c.amount for c in charges.data if c.paid) / 100
        charge_count = sum(1 for c in charges.data if c.paid)

        # Active subscriptions for MRR
        subs = stripe.Subscription.list(status="active", limit=100)
        mrr = 0
        for sub in subs.data:
            for item in sub["items"]["data"]:
                price = item.get("price", {})
                amount = price.get("unit_amount", 0) / 100
                interval = price.get("recurring", {}).get("interval", "month")
                if interval == "year":
                    mrr += amount / 12
                elif interval == "month":
                    mrr += amount
                elif interval == "week":
                    mrr += amount * 4.33

        # Refunds
        refunds = stripe.Refund.list(limit=100, created={"gte": thirty_days_ago})
        total_refunded = sum(r.amount for r in refunds.data) / 100

        # Customer count
        customers = stripe.Customer.list(limit=1)
        total_customers = customers.get("total_count", len(customers.data))

    except Exception as e:
        print(json.dumps({"success": False, "error": f"Stripe API error: {e}"}))
        sys.exit(1)

    # Combined revenue
    stripe_revenue_30d = total_charges - total_refunded
    affiliate_revenue = affiliate_data["total_earned"]
    total_revenue_30d = stripe_revenue_30d + affiliate_revenue

    full_data = {
        "success": True,
        "dashboard": {
            "total_revenue_30d": round(total_revenue_30d, 2),
            "stripe_revenue_30d": round(stripe_revenue_30d, 2),
            "affiliate_revenue_total": round(affiliate_revenue, 2),
            "mrr": round(mrr, 2),
            "arr": round(mrr * 12, 2),
            "available_balance": round(available, 2),
            "pending_balance": round(pending, 2),
            "charges_30d": charge_count,
            "refunds_30d": round(total_refunded, 2),
            "active_subscriptions": len(subs.data),
            "total_customers": total_customers,
            "affiliate_conversions": affiliate_data["total_conversions"],
        },
    }
    compact_out(full_data, {
        "success": True,
        "revenue_30d": round(total_revenue_30d, 2),
        "mrr": round(mrr, 2),
        "arr": round(mrr * 12, 2),
        "subs": len(subs.data),
        "customers": total_customers,
        "affiliate": round(affiliate_revenue, 2),
    })


def cmd_breakdown(args):
    """Revenue breakdown by stream."""
    stripe = init_stripe()
    affiliate_data = get_affiliate_data()

    try:
        thirty_days_ago = int((datetime.now() - timedelta(days=30)).timestamp())

        # One-time payments
        charges = stripe.Charge.list(limit=100, created={"gte": thirty_days_ago})
        one_time = 0
        subscription_charges = 0
        for c in charges.data:
            if not c.paid:
                continue
            if c.invoice:
                subscription_charges += c.amount / 100
            else:
                one_time += c.amount / 100

        # Subscription MRR
        subs = stripe.Subscription.list(status="active", limit=100)
        mrr = 0
        sub_breakdown = defaultdict(lambda: {"count": 0, "mrr": 0})
        for sub in subs.data:
            for item in sub["items"]["data"]:
                price = item.get("price", {})
                product_id = price.get("product", "unknown")
                amount = price.get("unit_amount", 0) / 100
                interval = price.get("recurring", {}).get("interval", "month")
                monthly = amount
                if interval == "year":
                    monthly = amount / 12
                elif interval == "week":
                    monthly = amount * 4.33
                mrr += monthly
                sub_breakdown[product_id]["count"] += 1
                sub_breakdown[product_id]["mrr"] += monthly

    except Exception as e:
        print(json.dumps({"success": False, "error": f"Stripe API error: {e}"}))
        sys.exit(1)

    streams = {
        "subscriptions": {
            "mrr": round(mrr, 2),
            "charges_30d": round(subscription_charges, 2),
            "active_count": sum(s["count"] for s in sub_breakdown.values()),
        },
        "one_time_sales": {
            "revenue_30d": round(one_time, 2),
        },
        "affiliate": {
            "total_earned": affiliate_data["total_earned"],
            "conversions": affiliate_data["total_conversions"],
        },
    }

    total = mrr + one_time + affiliate_data["total_earned"]
    if total > 0:
        streams["subscriptions"]["pct"] = round(mrr / total * 100, 1)
        streams["one_time_sales"]["pct"] = round(one_time / total * 100, 1)
        streams["affiliate"]["pct"] = round(affiliate_data["total_earned"] / total * 100, 1)

    full_data = {
        "success": True,
        "total_monthly": round(total, 2),
        "streams": streams,
        "subscription_products": dict(sub_breakdown),
    }
    compact_out(full_data, {
        "success": True,
        "total": round(total, 2),
        "subs_mrr": round(mrr, 2),
        "one_time": round(one_time, 2),
        "affiliate": affiliate_data["total_earned"],
    })


def cmd_trends(args):
    """Revenue trends over time."""
    stripe = init_stripe()
    months = args.months

    try:
        monthly_data = []
        for i in range(months - 1, -1, -1):
            start_date = datetime.now().replace(day=1) - timedelta(days=i * 30)
            start_ts = int(start_date.replace(day=1, hour=0, minute=0, second=0).timestamp())
            if start_date.month == 12:
                end_date = start_date.replace(year=start_date.year + 1, month=1, day=1)
            else:
                end_date = start_date.replace(month=start_date.month + 1, day=1)
            end_ts = int(end_date.timestamp())

            charges = stripe.Charge.list(
                limit=100,
                created={"gte": start_ts, "lt": end_ts}
            )
            revenue = sum(c.amount for c in charges.data if c.paid) / 100
            refunds = stripe.Refund.list(
                limit=100,
                created={"gte": start_ts, "lt": end_ts}
            )
            refunded = sum(r.amount for r in refunds.data) / 100

            period = start_date.strftime("%Y-%m")

            # Get affiliate data for this month
            affiliate_monthly = get_affiliate_data().get("monthly", {})
            aff_earned = affiliate_monthly.get(period, {}).get("earned", 0)

            monthly_data.append({
                "period": period,
                "stripe_revenue": round(revenue - refunded, 2),
                "affiliate_revenue": round(aff_earned, 2),
                "total_revenue": round(revenue - refunded + aff_earned, 2),
                "charges": len([c for c in charges.data if c.paid]),
                "refunds": round(refunded, 2),
            })

    except Exception as e:
        print(json.dumps({"success": False, "error": f"Stripe API error: {e}"}))
        sys.exit(1)

    # Calculate growth
    if len(monthly_data) >= 2:
        current = monthly_data[-1]["total_revenue"]
        previous = monthly_data[-2]["total_revenue"]
        growth = ((current - previous) / previous * 100) if previous > 0 else 0
    else:
        growth = 0

    full_data = {
        "success": True,
        "months": months,
        "monthly_growth_pct": round(growth, 2),
        "data": monthly_data,
    }
    compact_out(full_data, {
        "success": True,
        "growth": f"{round(growth, 2)}%",
        "months": [
            {"period": m["period"], "total": m["total_revenue"]}
            for m in monthly_data
        ],
    })


def cmd_projections(args):
    """Revenue projections based on current trends."""
    stripe = init_stripe()

    try:
        # Current MRR
        subs = stripe.Subscription.list(status="active", limit=100)
        mrr = 0
        for sub in subs.data:
            for item in sub["items"]["data"]:
                price = item.get("price", {})
                amount = price.get("unit_amount", 0) / 100
                interval = price.get("recurring", {}).get("interval", "month")
                if interval == "year":
                    mrr += amount / 12
                elif interval == "month":
                    mrr += amount
                elif interval == "week":
                    mrr += amount * 4.33

        # Recent one-time revenue (last 90 days avg monthly)
        ninety_days_ago = int((datetime.now() - timedelta(days=90)).timestamp())
        charges = stripe.Charge.list(limit=100, created={"gte": ninety_days_ago})
        one_time_total = sum(c.amount for c in charges.data if c.paid and not c.invoice) / 100
        monthly_one_time = one_time_total / 3

    except Exception as e:
        print(json.dumps({"success": False, "error": f"Stripe API error: {e}"}))
        sys.exit(1)

    affiliate = get_affiliate_data()
    monthly_aff = affiliate["total_earned"] / max(len(affiliate.get("monthly", {})), 1)

    current_monthly = mrr + monthly_one_time + monthly_aff
    growth_rate = args.growth_rate / 100

    projections = []
    for month in range(1, 13):
        projected_mrr = mrr * ((1 + growth_rate) ** month)
        projected_one_time = monthly_one_time * ((1 + growth_rate * 0.5) ** month)
        projected_affiliate = monthly_aff * ((1 + growth_rate * 0.3) ** month)
        total = projected_mrr + projected_one_time + projected_affiliate

        target_date = datetime.now() + timedelta(days=month * 30)
        projections.append({
            "month": month,
            "date": target_date.strftime("%Y-%m"),
            "projected_mrr": round(projected_mrr, 2),
            "projected_one_time": round(projected_one_time, 2),
            "projected_affiliate": round(projected_affiliate, 2),
            "projected_total": round(total, 2),
        })

    full_data = {
        "success": True,
        "current_monthly": round(current_monthly, 2),
        "current_mrr": round(mrr, 2),
        "growth_rate_pct": args.growth_rate,
        "projections": projections,
        "12_month_total": round(sum(p["projected_total"] for p in projections), 2),
    }
    compact_out(full_data, {
        "success": True,
        "current": round(current_monthly, 2),
        "mrr": round(mrr, 2),
        "growth": f"{args.growth_rate}%/mo",
        "3mo": round(projections[2]["projected_total"], 2) if len(projections) > 2 else 0,
        "6mo": round(projections[5]["projected_total"], 2) if len(projections) > 5 else 0,
        "12mo": round(projections[11]["projected_total"], 2) if len(projections) > 11 else 0,
    })


def main():
    load_env()

    parser = argparse.ArgumentParser(
        description="Revenue Tracker — Unified revenue dashboard (OpenClaw)"
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Full verbose output (default is compact to save tokens)"
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # dashboard
    subparsers.add_parser("dashboard", help="Show unified revenue dashboard")

    # breakdown
    subparsers.add_parser("breakdown", help="Revenue breakdown by stream")

    # trends
    sp = subparsers.add_parser("trends", help="Revenue trends over time")
    sp.add_argument("--months", type=int, default=6, help="Number of months (default: 6)")

    # projections
    sp = subparsers.add_parser("projections", help="Revenue projections")
    sp.add_argument("--growth-rate", type=float, default=10.0,
                     help="Expected monthly growth rate %% (default: 10)")

    args = parser.parse_args()

    global COMPACT_MODE
    COMPACT_MODE = not args.verbose

    commands = {
        "dashboard": cmd_dashboard,
        "breakdown": cmd_breakdown,
        "trends": cmd_trends,
        "projections": cmd_projections,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
