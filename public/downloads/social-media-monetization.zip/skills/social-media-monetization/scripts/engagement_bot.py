#!/usr/bin/env python3
"""Engagement Bot — Automated community building for X/Twitter.

Discovers high-value accounts, scores engagement opportunities,
and manages reply interactions with rate limit awareness.
All output is JSON.
"""

import argparse
import json
import os
import sys
import time
import urllib.request
import urllib.error
import urllib.parse
from datetime import datetime, timedelta
from pathlib import Path

# ── OpenClaw Patterns ────────────────────────────────────────────────────────
OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", str(Path.home() / ".openclaw"))
COMPACT_MODE = True
BASE_URL = "https://api.twitter.com/2"

# ── Rate Limit Tracking ─────────────────────────────────────────────────────
RATE_LIMITS = {
    "search": {"limit": 180, "remaining": 180, "reset": 0},
    "users": {"limit": 300, "remaining": 300, "reset": 0},
    "tweets": {"limit": 200, "remaining": 200, "reset": 0},
}


def load_env():
    """Load environment variables from .env file."""
    env_path = Path(OPENCLAW_HOME) / ".env"
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, val = line.split("=", 1)
                    val = val.strip().strip('"').strip("'")
                    if key not in os.environ:
                        os.environ[key] = val


def get_bearer_token():
    """Load bearer token from environment."""
    token = os.environ.get("X_BEARER_TOKEN", "")
    if not token:
        print(json.dumps({
            "success": False,
            "error": "Missing X_BEARER_TOKEN environment variable",
            "hint": "Export X_BEARER_TOKEN with your X API v2 bearer token.",
        }))
        sys.exit(1)
    return token


def api_request(endpoint, params=None, token=None, endpoint_type="search"):
    """Make authenticated GET request to X API v2 with rate limit tracking."""
    global RATE_LIMITS

    # Check rate limits before making request
    rl = RATE_LIMITS.get(endpoint_type, RATE_LIMITS["search"])
    if rl["remaining"] <= 0 and time.time() < rl["reset"]:
        wait_time = int(rl["reset"] - time.time())
        print(json.dumps({
            "success": False,
            "error": f"Rate limited on {endpoint_type}",
            "wait_seconds": wait_time,
            "reset_at": datetime.fromtimestamp(rl["reset"]).isoformat(),
        }))
        sys.exit(1)

    url = f"{BASE_URL}/{endpoint}"
    if params:
        query_string = urllib.parse.urlencode(params, quote_via=urllib.parse.quote)
        url = f"{url}?{query_string}"

    req = urllib.request.Request(url)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("User-Agent", "OpenClaw-EngagementBot/1.0")

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            # Track rate limits from headers
            headers = resp.headers
            if headers.get("x-rate-limit-remaining"):
                rl["remaining"] = int(headers.get("x-rate-limit-remaining", 0))
            if headers.get("x-rate-limit-reset"):
                rl["reset"] = int(headers.get("x-rate-limit-reset", 0))
            if headers.get("x-rate-limit-limit"):
                rl["limit"] = int(headers.get("x-rate-limit-limit", 0))

            data = json.loads(resp.read().decode("utf-8"))
            return data
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        if e.code == 429:
            retry_after = e.headers.get("retry-after", "unknown")
            reset_ts = e.headers.get("x-rate-limit-reset", "0")
            rl["remaining"] = 0
            rl["reset"] = int(reset_ts) if reset_ts.isdigit() else time.time() + 900
            print(json.dumps({
                "success": False,
                "error": "Rate limited (429)",
                "retry_after_seconds": retry_after,
                "endpoint_type": endpoint_type,
            }))
        elif e.code == 401:
            print(json.dumps({
                "success": False,
                "error": "Unauthorized (401). Check your bearer token.",
            }))
        elif e.code == 403:
            print(json.dumps({
                "success": False,
                "error": "Forbidden (403). Your API plan may not include this endpoint.",
            }))
        else:
            print(json.dumps({
                "success": False,
                "error": f"HTTP {e.code}",
                "details": body[:200],
            }))
        sys.exit(1)
    except urllib.error.URLError as e:
        print(json.dumps({
            "success": False,
            "error": f"Connection error: {str(e.reason)}",
        }))
        sys.exit(1)


def compact_out(full_data, compact_data=None):
    """Output compact or full data based on mode."""
    if COMPACT_MODE and compact_data:
        print(json.dumps(compact_data, indent=2, default=str))
    else:
        print(json.dumps(full_data, indent=2, default=str))


def calculate_engagement_score(tweet, author_followers=0):
    """Score an engagement opportunity (0-100).

    Factors: author followers, post age, niche relevance, reply count.
    Higher score = better opportunity for engagement.
    """
    metrics = tweet.get("public_metrics", {})
    score = 0.0

    # Author influence (0-30 points)
    if author_followers >= 100000:
        score += 30
    elif author_followers >= 10000:
        score += 25
    elif author_followers >= 1000:
        score += 20
    elif author_followers >= 100:
        score += 10
    else:
        score += 5

    # Engagement velocity (0-25 points)
    likes = metrics.get("like_count", 0)
    retweets = metrics.get("retweet_count", 0)
    replies = metrics.get("reply_count", 0)
    total_engagement = likes + retweets * 2 + replies * 3

    if total_engagement >= 1000:
        score += 25
    elif total_engagement >= 100:
        score += 20
    elif total_engagement >= 10:
        score += 15
    elif total_engagement >= 1:
        score += 5

    # Reply opportunity (0-20 points) — fewer replies = less competition
    if replies == 0:
        score += 20
    elif replies < 5:
        score += 15
    elif replies < 20:
        score += 10
    else:
        score += 5

    # Recency (0-25 points)
    created_at = tweet.get("created_at", "")
    if created_at:
        try:
            post_time = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
            age_hours = (datetime.now(post_time.tzinfo) - post_time).total_seconds() / 3600
            if age_hours < 1:
                score += 25
            elif age_hours < 4:
                score += 20
            elif age_hours < 12:
                score += 15
            elif age_hours < 24:
                score += 10
            else:
                score += 5
        except (ValueError, TypeError):
            score += 10

    return min(100, int(score))


def cmd_engage(args):
    """Find and score engagement opportunities in a niche."""
    token = get_bearer_token()
    niche = args.niche
    max_actions = args.actions
    budget_minutes = args.budget

    # Search for recent niche posts
    query = f"{niche} -is:retweet lang:en"
    params = {
        "query": query,
        "max_results": min(max_actions * 3, 100),
        "tweet.fields": "created_at,public_metrics,author_id",
        "expansions": "author_id",
        "user.fields": "public_metrics,username,name",
    }

    data = api_request("tweets/search/recent", params=params, token=token, endpoint_type="search")

    tweets = data.get("data", [])
    includes = data.get("includes", {})

    # Build author map with follower counts
    author_map = {}
    for user in includes.get("users", []):
        user_metrics = user.get("public_metrics", {})
        author_map[user["id"]] = {
            "username": user.get("username", ""),
            "name": user.get("name", ""),
            "followers": user_metrics.get("followers_count", 0),
        }

    # Score each opportunity
    opportunities = []
    for tweet in tweets:
        author_id = tweet.get("author_id", "")
        author = author_map.get(author_id, {})
        score = calculate_engagement_score(tweet, author.get("followers", 0))
        opportunities.append({
            "tweet_id": tweet["id"],
            "text": tweet["text"][:200],
            "author": author.get("username", "unknown"),
            "author_followers": author.get("followers", 0),
            "score": score,
            "metrics": {
                "likes": tweet.get("public_metrics", {}).get("like_count", 0),
                "replies": tweet.get("public_metrics", {}).get("reply_count", 0),
                "retweets": tweet.get("public_metrics", {}).get("retweet_count", 0),
            },
            "created_at": tweet.get("created_at", ""),
            "suggested_action": "reply" if score >= 50 else "like",
            "reply_prompt": f"[AI: Craft a thoughtful reply about {niche} to: {tweet['text'][:100]}]" if score >= 50 else None,
        })

    # Sort by score, take top actions
    opportunities.sort(key=lambda x: x["score"], reverse=True)
    top_opportunities = opportunities[:max_actions]

    full_data = {
        "success": True,
        "niche": niche,
        "total_found": len(opportunities),
        "top_opportunities": len(top_opportunities),
        "avg_score": int(sum(o["score"] for o in top_opportunities) / len(top_opportunities)) if top_opportunities else 0,
        "estimated_time_minutes": budget_minutes,
        "opportunities": top_opportunities,
        "rate_limits": {k: {"remaining": v["remaining"], "limit": v["limit"]} for k, v in RATE_LIMITS.items()},
    }
    compact_out(full_data, {
        "success": True,
        "niche": niche,
        "found": len(top_opportunities),
        "avg_score": full_data["avg_score"],
        "opportunities": [
            {"author": o["author"], "score": o["score"], "action": o["suggested_action"]}
            for o in top_opportunities
        ],
    })


def cmd_reply_mentions(args):
    """Find and prepare replies to mentions and relevant conversations."""
    token = get_bearer_token()
    username = args.username.lstrip("@")

    # Search for mentions
    query = f"@{username} -is:retweet"
    params = {
        "query": query,
        "max_results": min(args.limit, 100),
        "tweet.fields": "created_at,public_metrics,author_id,in_reply_to_user_id",
        "expansions": "author_id",
        "user.fields": "username,name,public_metrics",
    }

    data = api_request("tweets/search/recent", params=params, token=token, endpoint_type="search")

    tweets = data.get("data", [])
    includes = data.get("includes", {})

    author_map = {}
    for user in includes.get("users", []):
        author_map[user["id"]] = {
            "username": user.get("username", ""),
            "name": user.get("name", ""),
            "followers": user.get("public_metrics", {}).get("followers_count", 0),
        }

    mentions = []
    for tweet in tweets:
        author_id = tweet.get("author_id", "")
        author = author_map.get(author_id, {})
        score = calculate_engagement_score(tweet, author.get("followers", 0))
        mentions.append({
            "tweet_id": tweet["id"],
            "text": tweet["text"][:200],
            "author": author.get("username", "unknown"),
            "author_followers": author.get("followers", 0),
            "priority_score": score,
            "created_at": tweet.get("created_at", ""),
            "reply_prompt": f"[AI: Craft a helpful reply to @{author.get('username', 'user')}: {tweet['text'][:100]}]",
        })

    mentions.sort(key=lambda x: x["priority_score"], reverse=True)

    full_data = {
        "success": True,
        "username": username,
        "mention_count": len(mentions),
        "mentions": mentions,
    }
    compact_out(full_data, {
        "success": True,
        "username": username,
        "count": len(mentions),
        "mentions": [
            {"author": m["author"], "score": m["priority_score"], "preview": m["text"][:60]}
            for m in mentions
        ],
    })


def cmd_discover(args):
    """Discover high-value accounts to engage with in a niche."""
    token = get_bearer_token()
    niche = args.niche

    # Find influential posters in the niche
    query = f"{niche} -is:retweet lang:en"
    params = {
        "query": query,
        "max_results": 50,
        "tweet.fields": "public_metrics,author_id",
        "expansions": "author_id",
        "user.fields": "public_metrics,username,name,description",
    }

    data = api_request("tweets/search/recent", params=params, token=token, endpoint_type="search")
    includes = data.get("includes", {})

    # Aggregate and rank accounts
    accounts = {}
    for user in includes.get("users", []):
        uid = user["id"]
        user_metrics = user.get("public_metrics", {})
        followers = user_metrics.get("followers_count", 0)
        following = user_metrics.get("following_count", 0)

        # Calculate influence score
        ratio = followers / max(following, 1)
        influence = 0
        if followers >= 10000:
            influence += 40
        elif followers >= 1000:
            influence += 25
        elif followers >= 100:
            influence += 10

        if ratio >= 10:
            influence += 30
        elif ratio >= 2:
            influence += 20
        elif ratio >= 1:
            influence += 10

        tweet_count = user_metrics.get("tweet_count", 0)
        if tweet_count >= 1000:
            influence += 20
        elif tweet_count >= 100:
            influence += 10

        listed_count = user_metrics.get("listed_count", 0)
        if listed_count >= 100:
            influence += 10

        accounts[uid] = {
            "username": user.get("username", ""),
            "name": user.get("name", ""),
            "description": user.get("description", "")[:100],
            "followers": followers,
            "following": following,
            "ratio": round(ratio, 2),
            "influence_score": min(100, influence),
            "tweet_count": tweet_count,
        }

    # Sort by influence score
    ranked = sorted(accounts.values(), key=lambda x: x["influence_score"], reverse=True)
    top_accounts = ranked[:args.limit]

    full_data = {
        "success": True,
        "niche": niche,
        "accounts_found": len(ranked),
        "top_accounts": top_accounts,
    }
    compact_out(full_data, {
        "success": True,
        "niche": niche,
        "count": len(top_accounts),
        "accounts": [
            {"user": a["username"], "followers": a["followers"], "score": a["influence_score"]}
            for a in top_accounts
        ],
    })


def cmd_full_cycle(args):
    """Run a full engagement cycle: discover, score, and prepare actions."""
    token = get_bearer_token()
    niche = args.niche
    budget_minutes = args.budget

    # Step 1: Discover accounts
    query = f"{niche} -is:retweet lang:en"
    params = {
        "query": query,
        "max_results": 30,
        "tweet.fields": "created_at,public_metrics,author_id",
        "expansions": "author_id",
        "user.fields": "public_metrics,username,name",
    }

    data = api_request("tweets/search/recent", params=params, token=token, endpoint_type="search")
    tweets = data.get("data", [])
    includes = data.get("includes", {})

    author_map = {}
    for user in includes.get("users", []):
        author_map[user["id"]] = {
            "username": user.get("username", ""),
            "followers": user.get("public_metrics", {}).get("followers_count", 0),
        }

    # Step 2: Score and prioritize
    actions = []
    for tweet in tweets:
        author = author_map.get(tweet.get("author_id", ""), {})
        score = calculate_engagement_score(tweet, author.get("followers", 0))

        action_type = "skip"
        if score >= 70:
            action_type = "reply_with_value"
        elif score >= 50:
            action_type = "reply"
        elif score >= 30:
            action_type = "like_and_follow"
        else:
            action_type = "like"

        actions.append({
            "tweet_id": tweet["id"],
            "author": author.get("username", "unknown"),
            "score": score,
            "action": action_type,
            "text_preview": tweet["text"][:80],
            "reply_prompt": f"[AI: Reply to @{author.get('username', '')}: {tweet['text'][:80]}]" if "reply" in action_type else None,
        })

    actions.sort(key=lambda x: x["score"], reverse=True)

    # Estimate time per action
    time_per_action = {"reply_with_value": 3, "reply": 2, "like_and_follow": 1, "like": 0.5}
    total_time = 0
    scheduled_actions = []
    for action in actions:
        action_time = time_per_action.get(action["action"], 1)
        if total_time + action_time <= budget_minutes:
            total_time += action_time
            scheduled_actions.append(action)

    summary_stats = {
        "replies": sum(1 for a in scheduled_actions if "reply" in a["action"]),
        "likes": sum(1 for a in scheduled_actions if a["action"] in ("like", "like_and_follow")),
        "follows": sum(1 for a in scheduled_actions if a["action"] == "like_and_follow"),
    }

    full_data = {
        "success": True,
        "niche": niche,
        "total_found": len(actions),
        "scheduled_actions": len(scheduled_actions),
        "estimated_time_minutes": int(total_time),
        "budget_minutes": budget_minutes,
        "action_summary": summary_stats,
        "actions": scheduled_actions,
        "rate_limits": {k: {"remaining": v["remaining"], "limit": v["limit"]} for k, v in RATE_LIMITS.items()},
    }
    compact_out(full_data, {
        "success": True,
        "niche": niche,
        "actions": len(scheduled_actions),
        "time_min": int(total_time),
        "summary": summary_stats,
        "top_3": [
            {"author": a["author"], "score": a["score"], "action": a["action"]}
            for a in scheduled_actions[:3]
        ],
    })


def main():
    load_env()

    parser = argparse.ArgumentParser(
        description="Engagement Bot — Automated community building (OpenClaw)"
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Full verbose output (default is compact to save tokens)"
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # engage
    sp = subparsers.add_parser("engage", help="Find and score engagement opportunities")
    sp.add_argument("--niche", required=True, help="Target niche")
    sp.add_argument("--actions", type=int, default=10, help="Max actions to suggest (default: 10)")
    sp.add_argument("--budget", type=int, default=30, help="Time budget in minutes (default: 30)")

    # reply-mentions
    sp = subparsers.add_parser("reply-mentions", help="Find and prepare replies to mentions")
    sp.add_argument("username", help="Your X username")
    sp.add_argument("--limit", type=int, default=20, help="Max mentions to fetch (default: 20)")

    # discover
    sp = subparsers.add_parser("discover", help="Discover high-value accounts in a niche")
    sp.add_argument("--niche", required=True, help="Target niche")
    sp.add_argument("--limit", type=int, default=15, help="Max accounts to return (default: 15)")

    # full-cycle
    sp = subparsers.add_parser("full-cycle", help="Run full engagement cycle")
    sp.add_argument("--niche", required=True, help="Target niche")
    sp.add_argument("--budget", type=int, default=30, help="Time budget in minutes (default: 30)")

    args = parser.parse_args()

    global COMPACT_MODE
    COMPACT_MODE = not args.verbose

    commands = {
        "engage": cmd_engage,
        "reply-mentions": cmd_reply_mentions,
        "discover": cmd_discover,
        "full-cycle": cmd_full_cycle,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
