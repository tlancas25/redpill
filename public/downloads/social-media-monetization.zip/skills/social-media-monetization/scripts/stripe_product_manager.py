#!/usr/bin/env python3
"""Stripe Product Manager — Digital product and subscription tier management.

Creates Stripe products, prices, payment links, and manages subscription
tiers for digital products. All output is JSON.
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

# ── OpenClaw Patterns ────────────────────────────────────────────────────────
OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", str(Path.home() / ".openclaw"))
COMPACT_MODE = True


def load_env():
    """Load environment variables from .env file."""
    env_path = Path(OPENCLAW_HOME) / ".env"
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, val = line.split("=", 1)
                    val = val.strip().strip('"').strip("'")
                    if key not in os.environ:
                        os.environ[key] = val


def compact_out(full_data, compact_data=None):
    """Output compact or full data based on mode."""
    if COMPACT_MODE and compact_data:
        print(json.dumps(compact_data, indent=2, default=str))
    else:
        print(json.dumps(full_data, indent=2, default=str))


def init_stripe():
    """Initialize Stripe client."""
    try:
        import stripe
    except ImportError:
        print(json.dumps({"success": False, "error": "stripe not installed. Run: pip3 install stripe"}))
        sys.exit(1)

    api_key = os.environ.get("STRIPE_SECRET_KEY", "")
    if not api_key:
        env_path = Path(OPENCLAW_HOME) / ".env"
        if env_path.exists():
            with open(env_path) as f:
                for line in f:
                    if line.startswith("STRIPE_SECRET_KEY="):
                        api_key = line.split("=", 1)[1].strip().strip('"').strip("'")
                        break

    if not api_key:
        print(json.dumps({
            "success": False,
            "error": "STRIPE_SECRET_KEY not found",
            "hint": "Set STRIPE_SECRET_KEY in ~/.openclaw/.env",
        }))
        sys.exit(1)

    stripe.api_key = api_key
    return stripe


def cmd_create(args):
    """Create a new digital product with price and payment link."""
    stripe = init_stripe()

    price_cents = int(args.price * 100)
    product_type = args.type

    try:
        # Create product
        product_params = {
            "name": args.name,
            "type": "service",
            "metadata": {
                "created_by": "openclaw-product-manager",
                "product_type": product_type,
            },
        }
        if args.description:
            product_params["description"] = args.description

        product = stripe.Product.create(**product_params)

        # Create price
        price_params = {
            "product": product.id,
            "unit_amount": price_cents,
            "currency": "usd",
        }

        if product_type == "subscription":
            interval = args.interval or "month"
            price_params["recurring"] = {"interval": interval}
        elif product_type == "one-time":
            pass  # No recurring needed

        price = stripe.Price.create(**price_params)

        # Create payment link
        payment_link = stripe.PaymentLink.create(
            line_items=[{"price": price.id, "quantity": 1}],
            metadata={"product_name": args.name},
        )

        full_data = {
            "success": True,
            "product": {
                "id": product.id,
                "name": product.name,
                "description": product.get("description", ""),
                "type": product_type,
            },
            "price": {
                "id": price.id,
                "amount": f"${args.price:.2f}",
                "currency": "usd",
                "recurring": product_type == "subscription",
                "interval": args.interval if product_type == "subscription" else None,
            },
            "payment_link": {
                "id": payment_link.id,
                "url": payment_link.url,
            },
        }
        compact_out(full_data, {
            "success": True,
            "product_id": product.id,
            "price_id": price.id,
            "amount": f"${args.price:.2f}",
            "type": product_type,
            "payment_url": payment_link.url,
        })

    except Exception as e:
        print(json.dumps({"success": False, "error": str(e)}))
        sys.exit(1)


def cmd_create_tier(args):
    """Create a subscription tier system (e.g., Basic/Pro/Enterprise)."""
    stripe = init_stripe()

    tiers = []
    tier_configs = [
        {"name": f"{args.name} - Basic", "multiplier": 1.0},
        {"name": f"{args.name} - Pro", "multiplier": 2.5},
        {"name": f"{args.name} - Enterprise", "multiplier": 5.0},
    ]

    if args.custom_tiers:
        try:
            tier_configs = json.loads(args.custom_tiers)
        except json.JSONDecodeError:
            print(json.dumps({"success": False, "error": "Invalid JSON for --custom-tiers"}))
            sys.exit(1)

    base_price = args.base_price
    interval = args.interval or "month"

    try:
        for tier_config in tier_configs:
            tier_name = tier_config.get("name", f"{args.name} - Tier")
            multiplier = tier_config.get("multiplier", 1.0)
            tier_price = base_price * multiplier
            price_cents = int(tier_price * 100)

            # Create product
            product = stripe.Product.create(
                name=tier_name,
                type="service",
                metadata={
                    "created_by": "openclaw-product-manager",
                    "product_type": "subscription_tier",
                    "tier_group": args.name,
                },
            )

            # Create price
            price = stripe.Price.create(
                product=product.id,
                unit_amount=price_cents,
                currency="usd",
                recurring={"interval": interval},
            )

            # Create payment link
            payment_link = stripe.PaymentLink.create(
                line_items=[{"price": price.id, "quantity": 1}],
            )

            tiers.append({
                "tier_name": tier_name,
                "product_id": product.id,
                "price_id": price.id,
                "amount": f"${tier_price:.2f}/{interval}",
                "payment_url": payment_link.url,
            })

        full_data = {
            "success": True,
            "tier_group": args.name,
            "interval": interval,
            "tiers_created": len(tiers),
            "tiers": tiers,
        }
        compact_out(full_data, {
            "success": True,
            "group": args.name,
            "tiers": [
                {"name": t["tier_name"], "price": t["amount"], "url": t["payment_url"]}
                for t in tiers
            ],
        })

    except Exception as e:
        print(json.dumps({"success": False, "error": str(e)}))
        sys.exit(1)


def cmd_list(args):
    """List products and their prices."""
    stripe = init_stripe()

    try:
        products = stripe.Product.list(
            active=True if not args.include_inactive else None,
            limit=args.limit,
        )

        items = []
        for product in products.data:
            # Get prices for this product
            prices = stripe.Price.list(product=product.id, active=True, limit=10)

            price_list = []
            for price in prices.data:
                recurring = price.get("recurring")
                price_list.append({
                    "id": price.id,
                    "amount": f"${price.unit_amount / 100:.2f}",
                    "currency": price.currency,
                    "recurring": bool(recurring),
                    "interval": recurring.get("interval") if recurring else None,
                })

            items.append({
                "id": product.id,
                "name": product.name,
                "description": product.get("description", ""),
                "active": product.active,
                "type": product.metadata.get("product_type", "unknown"),
                "tier_group": product.metadata.get("tier_group", ""),
                "prices": price_list,
                "created": datetime.fromtimestamp(product.created).isoformat(),
            })

        full_data = {
            "success": True,
            "count": len(items),
            "products": items,
        }
        compact_out(full_data, {
            "success": True,
            "count": len(items),
            "products": [
                {
                    "name": p["name"],
                    "type": p["type"],
                    "prices": [pr["amount"] for pr in p["prices"]],
                }
                for p in items
            ],
        })

    except Exception as e:
        print(json.dumps({"success": False, "error": str(e)}))
        sys.exit(1)


def cmd_deactivate(args):
    """Deactivate a product."""
    stripe = init_stripe()

    try:
        product = stripe.Product.modify(args.product_id, active=False)

        # Also deactivate associated prices
        prices = stripe.Price.list(product=args.product_id, active=True)
        deactivated_prices = []
        for price in prices.data:
            stripe.Price.modify(price.id, active=False)
            deactivated_prices.append(price.id)

        print(json.dumps({
            "success": True,
            "product_id": product.id,
            "product_name": product.name,
            "status": "deactivated",
            "prices_deactivated": deactivated_prices,
        }, indent=2))

    except Exception as e:
        print(json.dumps({"success": False, "error": str(e)}))
        sys.exit(1)


def cmd_update_price(args):
    """Create a new price for an existing product (Stripe prices are immutable)."""
    stripe = init_stripe()

    price_cents = int(args.price * 100)

    try:
        # Verify product exists
        product = stripe.Product.retrieve(args.product_id)

        price_params = {
            "product": args.product_id,
            "unit_amount": price_cents,
            "currency": "usd",
        }

        if args.recurring:
            interval = args.interval or "month"
            price_params["recurring"] = {"interval": interval}

        new_price = stripe.Price.create(**price_params)

        # Optionally deactivate old price
        if args.deactivate_old:
            old_prices = stripe.Price.list(product=args.product_id, active=True)
            for op in old_prices.data:
                if op.id != new_price.id:
                    stripe.Price.modify(op.id, active=False)

        # Create new payment link
        payment_link = stripe.PaymentLink.create(
            line_items=[{"price": new_price.id, "quantity": 1}],
        )

        print(json.dumps({
            "success": True,
            "product_id": product.id,
            "product_name": product.name,
            "new_price_id": new_price.id,
            "amount": f"${args.price:.2f}",
            "payment_url": payment_link.url,
            "old_prices_deactivated": args.deactivate_old,
        }, indent=2))

    except Exception as e:
        print(json.dumps({"success": False, "error": str(e)}))
        sys.exit(1)


def cmd_stats(args):
    """Show product sales statistics."""
    stripe = init_stripe()

    try:
        product = stripe.Product.retrieve(args.product_id)
        prices = stripe.Price.list(product=args.product_id, limit=10)
        price_ids = [p.id for p in prices.data]

        # Get subscription count
        total_subs = 0
        active_subs = 0
        for price in prices.data:
            if price.recurring:
                subs = stripe.Subscription.list(price=price.id, limit=100)
                total_subs += len(subs.data)
                active_subs += sum(1 for s in subs.data if s.status == "active")

        # Get recent charges via invoices
        thirty_days_ago = int((datetime.now() - timedelta(days=30)).timestamp())
        from datetime import timedelta

        revenue_30d = 0
        charge_count = 0

        # Use payment intents to find revenue
        charges = stripe.Charge.list(limit=100, created={"gte": thirty_days_ago})
        for charge in charges.data:
            if charge.paid and charge.metadata.get("product_id") == args.product_id:
                revenue_30d += charge.amount / 100
                charge_count += 1

        print(json.dumps({
            "success": True,
            "product_id": product.id,
            "product_name": product.name,
            "active": product.active,
            "price_count": len(prices.data),
            "prices": [f"${p.unit_amount / 100:.2f}" for p in prices.data],
            "total_subscriptions": total_subs,
            "active_subscriptions": active_subs,
            "revenue_30d": round(revenue_30d, 2),
            "charges_30d": charge_count,
        }, indent=2))

    except Exception as e:
        print(json.dumps({"success": False, "error": str(e)}))
        sys.exit(1)


def main():
    load_env()

    parser = argparse.ArgumentParser(
        description="Stripe Product Manager — Digital product management (OpenClaw)"
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Full verbose output (default is compact to save tokens)"
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # create
    sp = subparsers.add_parser("create", help="Create a new product")
    sp.add_argument("--name", required=True, help="Product name")
    sp.add_argument("--price", type=float, required=True, help="Price in dollars (e.g., 97.00)")
    sp.add_argument("--type", required=True, choices=["one-time", "subscription"],
                     help="Product type")
    sp.add_argument("--description", help="Product description")
    sp.add_argument("--interval", choices=["week", "month", "year"],
                     help="Billing interval (for subscriptions)")

    # create-tier
    sp = subparsers.add_parser("create-tier", help="Create subscription tier system")
    sp.add_argument("--name", required=True, help="Tier group name")
    sp.add_argument("--base-price", type=float, required=True, help="Base tier price in dollars")
    sp.add_argument("--interval", choices=["week", "month", "year"], default="month",
                     help="Billing interval (default: month)")
    sp.add_argument("--custom-tiers", help='Custom tiers JSON: [{"name": "...", "multiplier": 1.0}]')

    # list
    sp = subparsers.add_parser("list", help="List products")
    sp.add_argument("--limit", type=int, default=20, help="Max products to list (default: 20)")
    sp.add_argument("--include-inactive", action="store_true", help="Include inactive products")

    # deactivate
    sp = subparsers.add_parser("deactivate", help="Deactivate a product")
    sp.add_argument("product_id", help="Stripe product ID")

    # update-price
    sp = subparsers.add_parser("update-price", help="Create new price for a product")
    sp.add_argument("product_id", help="Stripe product ID")
    sp.add_argument("--price", type=float, required=True, help="New price in dollars")
    sp.add_argument("--recurring", action="store_true", help="Make it a recurring price")
    sp.add_argument("--interval", choices=["week", "month", "year"], help="Billing interval")
    sp.add_argument("--deactivate-old", action="store_true", help="Deactivate old prices")

    # stats
    sp = subparsers.add_parser("stats", help="Show product sales stats")
    sp.add_argument("product_id", help="Stripe product ID")

    args = parser.parse_args()

    global COMPACT_MODE
    COMPACT_MODE = not args.verbose

    commands = {
        "create": cmd_create,
        "create-tier": cmd_create_tier,
        "list": cmd_list,
        "deactivate": cmd_deactivate,
        "update-price": cmd_update_price,
        "stats": cmd_stats,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
