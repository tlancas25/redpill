#!/usr/bin/env python3
"""Listing Marketer — AI-powered listing promotion & marketing automation.

Generates listing descriptions, social media post packs, open house campaigns,
and just-sold announcements for real estate agents.
"""

import argparse
import json
import os
import sqlite3
import sys
import hashlib
from datetime import datetime, timezone, timedelta
from pathlib import Path

# --- Configuration ---

OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", str(Path.home() / ".openclaw"))
DATA_DIR = os.path.join(OPENCLAW_HOME, "data", "real-estate-agent")
DB_PATH = os.path.join(DATA_DIR, "listings.db")
CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")
VERBOSE = False


def load_env():
    """Load environment variables from .openclaw/.env file."""
    env_path = os.path.join(OPENCLAW_HOME, ".env")
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, val = line.split("=", 1)
                    os.environ.setdefault(key.strip(), val.strip().strip("\"'"))


def load_config():
    """Load skill configuration."""
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH) as f:
            return json.load(f)
    return {}


def output(data):
    """Print JSON output, compact by default."""
    if VERBOSE:
        print(json.dumps(data, indent=2, default=str))
    else:
        print(json.dumps(data, default=str))


def ensure_db():
    """Initialize SQLite database and return connection."""
    os.makedirs(DATA_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS listings (
            id TEXT PRIMARY KEY,
            address TEXT NOT NULL,
            beds INTEGER, baths REAL, sqft INTEGER,
            price REAL, features TEXT, description TEXT,
            status TEXT DEFAULT 'active',
            created_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS campaigns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            listing_id TEXT NOT NULL,
            type TEXT NOT NULL,
            content TEXT NOT NULL,
            schedule TEXT,
            status TEXT DEFAULT 'draft',
            created_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
            FOREIGN KEY (listing_id) REFERENCES listings(id)
        )
    """)
    conn.commit()
    return conn


def generate_listing_id(address):
    """Generate deterministic listing ID from address."""
    return hashlib.sha256(address.lower().strip().encode()).hexdigest()[:12]


# --- Description Generation ---

DESCRIPTION_TEMPLATES = {
    "luxury": (
        "Exquisite {beds}-bedroom, {baths}-bathroom residence spanning {sqft:,} sq ft "
        "in the prestigious {area} neighborhood. {feature_text} "
        "Offered at ${price:,.0f}, this exceptional home represents the pinnacle of "
        "refined living. Schedule your private showing today."
    ),
    "family": (
        "Welcome home to this charming {beds}-bedroom, {baths}-bathroom gem with "
        "{sqft:,} sq ft of living space. {feature_text} "
        "Perfectly situated in {area}, this home is priced at ${price:,.0f}. "
        "Your family's next chapter starts here!"
    ),
    "starter": (
        "Don't miss this incredible opportunity! This {beds}-bed, {baths}-bath home "
        "offers {sqft:,} sq ft in {area}. {feature_text} "
        "Listed at just ${price:,.0f} — an unbeatable value. Book your tour now!"
    ),
    "investment": (
        "Prime investment opportunity in {area}. This {beds}BR/{baths}BA property "
        "with {sqft:,} sq ft offers excellent rental potential. {feature_text} "
        "Asking ${price:,.0f}. Strong ROI in a high-demand market."
    )
}

FEATURE_PHRASES = {
    "pool": "The stunning pool area is perfect for entertaining year-round.",
    "garage": "An attached garage provides convenience and additional storage.",
    "updated kitchen": "The beautifully updated kitchen features modern finishes and premium appliances.",
    "hardwood": "Gorgeous hardwood floors flow throughout the main living areas.",
    "fireplace": "A cozy fireplace anchors the living room.",
    "backyard": "The spacious backyard offers endless possibilities for outdoor living.",
    "view": "Breathtaking views greet you from every window.",
    "new roof": "A brand-new roof provides peace of mind for years to come.",
    "smart home": "Integrated smart home technology offers modern convenience at your fingertips.",
    "open floor plan": "The open floor plan creates an inviting, light-filled living space.",
    "granite": "Elegant granite countertops grace the kitchen and baths.",
    "stainless": "Premium stainless steel appliances complete the gourmet kitchen.",
    "walk-in closet": "Generous walk-in closets offer abundant storage.",
    "master suite": "The luxurious master suite is your private retreat.",
    "solar": "Energy-efficient solar panels reduce utility costs significantly."
}


def classify_listing(price, sqft):
    """Determine listing tier for template selection."""
    price_per_sqft = price / max(sqft, 1)
    if price >= 750000 or price_per_sqft >= 400:
        return "luxury"
    elif price >= 400000:
        return "family"
    elif price <= 250000:
        return "starter"
    return "family"


def build_feature_text(features):
    """Convert feature list into descriptive sentences."""
    if not features:
        return ""
    sentences = []
    for feat in features:
        key = feat.lower().strip()
        if key in FEATURE_PHRASES:
            sentences.append(FEATURE_PHRASES[key])
        else:
            sentences.append(f"Features include {feat}.")
    return " ".join(sentences[:4])


def cmd_describe(args):
    """Generate an AI-powered listing description."""
    conn = ensure_db()
    features = [f.strip() for f in args.features.split(",")] if args.features else []
    area = args.area or "the neighborhood"

    tier = args.style or classify_listing(args.price, args.sqft)
    template = DESCRIPTION_TEMPLATES.get(tier, DESCRIPTION_TEMPLATES["family"])
    feature_text = build_feature_text(features)

    description = template.format(
        beds=args.beds, baths=args.baths, sqft=args.sqft,
        price=args.price, area=area, feature_text=feature_text
    )

    listing_id = generate_listing_id(args.address)
    conn.execute("""
        INSERT OR REPLACE INTO listings (id, address, beds, baths, sqft, price, features, description)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (listing_id, args.address, args.beds, args.baths, args.sqft,
          args.price, json.dumps(features), description))
    conn.commit()

    output({
        "listing_id": listing_id, "address": args.address,
        "tier": tier, "description": description,
        "word_count": len(description.split())
    })


# --- Social Media Pack ---

def cmd_social_pack(args):
    """Generate a 5-post social media content pack for a listing."""
    conn = ensure_db()
    listing = conn.execute("SELECT * FROM listings WHERE id = ?", (args.listing_id,)).fetchone()
    if not listing:
        output({"error": "Listing not found. Run 'describe' first.", "listing_id": args.listing_id})
        sys.exit(1)

    listing = dict(listing)
    config = load_config()
    agent_name = config.get("agent", {}).get("name", "Your Agent")
    agent_phone = config.get("agent", {}).get("phone", "")
    features = json.loads(listing.get("features") or "[]")
    feat_highlight = features[0] if features else "an amazing layout"

    posts = [
        {
            "post_number": 1, "type": "just_listed", "platform": "all",
            "text": (
                f"JUST LISTED! {listing['beds']}BR/{listing['baths']}BA | "
                f"{listing['sqft']:,} sq ft\n"
                f"{listing['address']}\n"
                f"${listing['price']:,.0f}\n\n"
                f"This one won't last! DM me or call {agent_phone} for details.\n"
                f"#JustListed #RealEstate #NewListing #HomeForSale"
            ),
            "schedule": "Day 1"
        },
        {
            "post_number": 2, "type": "feature_highlight", "platform": "instagram",
            "text": (
                f"FEATURE SPOTLIGHT: {feat_highlight}\n\n"
                f"This {listing['beds']}-bedroom beauty at {listing['address']} "
                f"has it all. What feature matters most to you?\n\n"
                f"Listed at ${listing['price']:,.0f} | {agent_name}\n"
                f"#HomeFeatures #DreamHome #RealEstateLife"
            ),
            "schedule": "Day 3"
        },
        {
            "post_number": 3, "type": "neighborhood", "platform": "facebook",
            "text": (
                f"NEIGHBORHOOD LOVE: Why buyers are choosing this area!\n\n"
                f"Great schools, walkable streets, and a thriving community — "
                f"all just steps from {listing['address']}.\n\n"
                f"${listing['price']:,.0f} | {listing['beds']}BR/{listing['baths']}BA\n"
                f"Comment DETAILS to learn more!\n"
                f"#Neighborhood #CommunityLiving #HomeBuyers"
            ),
            "schedule": "Day 5"
        },
        {
            "post_number": 4, "type": "price_value", "platform": "all",
            "text": (
                f"VALUE ALERT: ${listing['price']:,.0f} for {listing['sqft']:,} sq ft!\n\n"
                f"That's ${listing['price'] / max(listing['sqft'], 1):,.0f}/sq ft in today's market.\n"
                f"{listing['address']} — {listing['beds']}BR/{listing['baths']}BA\n\n"
                f"Don't wait — schedule your showing with {agent_name}.\n"
                f"#PriceReduction #HomeValue #BuyNow"
            ),
            "schedule": "Day 7"
        },
        {
            "post_number": 5, "type": "open_house_tease", "platform": "all",
            "text": (
                f"COMING THIS WEEKEND: Open House!\n"
                f"{listing['address']}\n"
                f"${listing['price']:,.0f} | {listing['beds']}BR/{listing['baths']}BA | "
                f"{listing['sqft']:,} sq ft\n\n"
                f"Come see what everyone's talking about.\n"
                f"Contact {agent_name} at {agent_phone}\n"
                f"#OpenHouse #WeekendPlans #HouseHunting"
            ),
            "schedule": "Day 10"
        }
    ]

    # Store campaign
    for post in posts:
        conn.execute(
            "INSERT INTO campaigns (listing_id, type, content, schedule) VALUES (?, ?, ?, ?)",
            (args.listing_id, post["type"], post["text"], post["schedule"])
        )
    conn.commit()

    output({"listing_id": args.listing_id, "post_count": len(posts), "posts": posts})


# --- Open House Campaign ---

def cmd_open_house(args):
    """Generate an open house countdown campaign."""
    conn = ensure_db()
    listing = conn.execute("SELECT * FROM listings WHERE id = ?", (args.listing_id,)).fetchone()
    if not listing:
        output({"error": "Listing not found", "listing_id": args.listing_id})
        sys.exit(1)

    listing = dict(listing)
    config = load_config()
    agent_name = config.get("agent", {}).get("name", "Your Agent")
    oh_date = datetime.strptime(args.date, "%Y-%m-%d")
    campaign_start = datetime.strptime(args.campaign_start, "%Y-%m-%d") if args.campaign_start else oh_date - timedelta(days=7)

    sequence = []
    days_before = (oh_date - campaign_start).days

    messages = [
        {"offset": 0, "channel": "email", "subject": "Open House Announcement",
         "body": f"You're invited! Open house at {listing['address']} on {args.date} at {args.time}. "
                 f"{listing['beds']}BR/{listing['baths']}BA, {listing['sqft']:,} sq ft, ${listing['price']:,.0f}. "
                 f"RSVP to {agent_name} to reserve your spot."},
        {"offset": max(1, days_before // 2), "channel": "social",
         "subject": "Countdown Post",
         "body": f"MARK YOUR CALENDARS! Open house this {oh_date.strftime('%A')} at "
                 f"{listing['address']}. {args.time}. See you there! #OpenHouse"},
        {"offset": days_before - 1, "channel": "sms",
         "subject": "Day-Before Reminder",
         "body": f"Reminder: Open house TOMORROW at {listing['address']}, {args.time}. "
                 f"${listing['price']:,.0f}. Looking forward to seeing you! — {agent_name}"},
        {"offset": days_before, "channel": "social",
         "subject": "Day-Of Post",
         "body": f"HAPPENING NOW! Open house at {listing['address']}. "
                 f"Stop by until {args.time}. {listing['beds']}BR/{listing['baths']}BA | "
                 f"${listing['price']:,.0f} #OpenHouseToday"},
    ]

    for msg in messages:
        send_date = campaign_start + timedelta(days=msg["offset"])
        sequence.append({
            "send_date": send_date.strftime("%Y-%m-%d"),
            "channel": msg["channel"],
            "subject": msg["subject"],
            "body": msg["body"]
        })

    output({
        "listing_id": args.listing_id, "open_house_date": args.date,
        "open_house_time": args.time, "campaign_start": campaign_start.strftime("%Y-%m-%d"),
        "message_count": len(sequence), "sequence": sequence
    })


# --- Just Sold ---

def cmd_just_sold(args):
    """Generate a just-sold announcement package."""
    conn = ensure_db()
    listing = conn.execute("SELECT * FROM listings WHERE id = ?", (args.listing_id,)).fetchone()
    if not listing:
        output({"error": "Listing not found", "listing_id": args.listing_id})
        sys.exit(1)

    listing = dict(listing)
    config = load_config()
    agent_name = config.get("agent", {}).get("name", "Your Agent")
    sale_price = args.sale_price or listing["price"]
    dom = args.days_on_market or 14

    # Update listing status
    conn.execute("UPDATE listings SET status = 'sold' WHERE id = ?", (args.listing_id,))
    conn.commit()

    social_post = (
        f"JUST SOLD! {listing['address']}\n\n"
        f"{'Over asking!' if sale_price > listing['price'] else 'At asking price!'} "
        f"Sold in just {dom} days.\n\n"
        f"Thinking of selling? Your home could be next. "
        f"Contact {agent_name} for a free market analysis.\n"
        f"#JustSold #RealEstate #SoldByMe #Results"
    )

    email_template = (
        f"Great news from the market! {listing['address']} has officially SOLD.\n\n"
        f"Listed at: ${listing['price']:,.0f}\n"
        f"Sold at: ${sale_price:,.0f}\n"
        f"Days on market: {dom}\n\n"
        f"The market remains active in this area. If you've been considering "
        f"selling your home, now is an excellent time. I'd love to provide you "
        f"with a complimentary market analysis.\n\n"
        f"Best,\n{agent_name}"
    )

    output({
        "listing_id": args.listing_id, "status": "sold",
        "list_price": listing["price"], "sale_price": sale_price,
        "days_on_market": dom,
        "social_post": social_post, "email_template": email_template
    })


# --- Main ---

def main():
    global VERBOSE
    parser = argparse.ArgumentParser(
        description="Listing Marketer — AI-powered listing promotion automation"
    )
    parser.add_argument("--verbose", action="store_true", help="Verbose JSON output")
    sub = parser.add_subparsers(dest="command", required=True)

    # describe
    p_desc = sub.add_parser("describe", help="Generate listing description")
    p_desc.add_argument("--address", required=True)
    p_desc.add_argument("--beds", type=int, required=True)
    p_desc.add_argument("--baths", type=float, required=True)
    p_desc.add_argument("--sqft", type=int, required=True)
    p_desc.add_argument("--price", type=float, required=True)
    p_desc.add_argument("--features", default=None, help="Comma-separated features")
    p_desc.add_argument("--area", default=None)
    p_desc.add_argument("--style", default=None,
                        choices=["luxury", "family", "starter", "investment"])

    # social-pack
    p_social = sub.add_parser("social-pack", help="Generate social media post pack")
    p_social.add_argument("--listing-id", required=True)

    # open-house
    p_oh = sub.add_parser("open-house", help="Generate open house campaign")
    p_oh.add_argument("--listing-id", required=True)
    p_oh.add_argument("--date", required=True, help="YYYY-MM-DD")
    p_oh.add_argument("--time", required=True, help="e.g. '1:00 PM - 4:00 PM'")
    p_oh.add_argument("--campaign-start", default=None, help="YYYY-MM-DD")

    # just-sold
    p_sold = sub.add_parser("just-sold", help="Generate just-sold announcement")
    p_sold.add_argument("--listing-id", required=True)
    p_sold.add_argument("--sale-price", type=float, default=None)
    p_sold.add_argument("--days-on-market", type=int, default=None)

    args = parser.parse_args()
    VERBOSE = args.verbose
    load_env()

    commands = {
        "describe": cmd_describe, "social-pack": cmd_social_pack,
        "open-house": cmd_open_house, "just-sold": cmd_just_sold
    }

    try:
        commands[args.command](args)
    except Exception as e:
        output({"error": str(e), "command": args.command})
        sys.exit(1)


if __name__ == "__main__":
    main()
