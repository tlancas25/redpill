#!/usr/bin/env python3
"""Lead Engine — Lead capture, CRM & scoring for real estate agents.

SQLite-backed lead database with automated scoring, pipeline management,
follow-up scheduling, and nurture campaign tracking.
"""

import argparse
import json
import os
import sqlite3
import sys
import hashlib
from datetime import datetime, timezone, timedelta
from pathlib import Path

# --- Configuration ---

OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", str(Path.home() / ".openclaw"))
DATA_DIR = os.path.join(OPENCLAW_HOME, "data", "real-estate-agent")
DB_PATH = os.path.join(DATA_DIR, "leads.db")
CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")
VERBOSE = False


def load_env():
    """Load environment variables from .openclaw/.env file."""
    env_path = os.path.join(OPENCLAW_HOME, ".env")
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, val = line.split("=", 1)
                    os.environ.setdefault(key.strip(), val.strip().strip("\"'"))


def load_config():
    """Load skill configuration."""
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH) as f:
            return json.load(f)
    return {}


def output(data):
    """Print JSON output, compact by default."""
    if VERBOSE:
        print(json.dumps(data, indent=2, default=str))
    else:
        print(json.dumps(data, default=str))


def ensure_db():
    """Initialize SQLite database and return connection."""
    os.makedirs(DATA_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS leads (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            phone TEXT,
            email TEXT,
            source TEXT DEFAULT 'manual',
            interest TEXT DEFAULT 'buying',
            area TEXT,
            budget REAL,
            timeline TEXT DEFAULT 'exploring',
            stage TEXT DEFAULT 'nurture',
            score INTEGER DEFAULT 0,
            pre_approved INTEGER DEFAULT 0,
            notes TEXT,
            engagement_count INTEGER DEFAULT 0,
            last_contact TEXT,
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
            updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS interactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lead_id TEXT NOT NULL,
            type TEXT NOT NULL,
            channel TEXT DEFAULT 'manual',
            message TEXT,
            direction TEXT DEFAULT 'outbound',
            created_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
            FOREIGN KEY (lead_id) REFERENCES leads(id)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS followups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lead_id TEXT NOT NULL,
            due_date TEXT NOT NULL,
            action TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            completed_at TEXT,
            FOREIGN KEY (lead_id) REFERENCES leads(id)
        )
    """)
    conn.commit()
    return conn


def generate_id(name, email):
    """Generate deterministic lead ID."""
    raw = f"{name.lower().strip()}:{(email or '').lower().strip()}"
    return hashlib.sha256(raw.encode()).hexdigest()[:12]


# --- Scoring Algorithm ---

TIMELINE_SCORES = {
    "immediate": 30, "1-3months": 25, "3-6months": 15,
    "6-12months": 8, "exploring": 3
}

SOURCE_SCORES = {
    "referral": 25, "zillow": 18, "realtor.com": 18, "open-house": 20,
    "website": 15, "social": 12, "cold-call": 8, "manual": 5, "other": 5
}


def calculate_score(lead):
    """Score a lead 0-100 based on multiple weighted factors."""
    config = load_config()
    weights = config.get("lead_scoring_weights", {})

    timeline_w = weights.get("timeline", 1.0)
    source_w = weights.get("source", 1.0)
    engagement_w = weights.get("engagement", 1.0)
    preapproval_w = weights.get("pre_approval", 1.0)
    recency_w = weights.get("recency", 1.0)

    score = 0.0
    # Timeline urgency (0-30)
    score += TIMELINE_SCORES.get(lead["timeline"], 3) * timeline_w
    # Source quality (0-25)
    score += SOURCE_SCORES.get(lead["source"], 5) * source_w
    # Engagement (0-20) — capped at 10 interactions
    eng = min(lead["engagement_count"] or 0, 10)
    score += (eng * 2) * engagement_w
    # Pre-approval (0-15)
    if lead["pre_approved"]:
        score += 15 * preapproval_w
    # Recency (0-10)
    if lead["last_contact"]:
        try:
            last = datetime.fromisoformat(lead["last_contact"].replace("Z", "+00:00"))
            days_ago = (datetime.now(timezone.utc) - last).days
            recency = max(0, 10 - days_ago)
            score += recency * recency_w
        except (ValueError, TypeError):
            pass

    return min(100, max(0, int(score)))


def classify_stage(score):
    """Auto-classify lead stage from score."""
    if score >= 70:
        return "hot"
    elif score >= 40:
        return "warm"
    return "nurture"


# --- Commands ---

def cmd_add(args):
    """Add a new lead to the database."""
    conn = ensure_db()
    lead_id = generate_id(args.name, args.email)

    existing = conn.execute("SELECT id FROM leads WHERE id = ?", (lead_id,)).fetchone()
    if existing:
        output({"error": "Lead already exists", "lead_id": lead_id})
        sys.exit(1)

    lead_data = {
        "id": lead_id, "name": args.name, "phone": args.phone,
        "email": args.email, "source": args.source, "interest": args.interest,
        "area": args.area, "budget": args.budget, "timeline": args.timeline,
        "pre_approved": 1 if args.pre_approved else 0,
        "engagement_count": 0, "last_contact": None
    }
    score = calculate_score(lead_data)
    stage = classify_stage(score)

    conn.execute("""
        INSERT INTO leads (id, name, phone, email, source, interest, area, budget,
                           timeline, stage, score, pre_approved)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (lead_id, args.name, args.phone, args.email, args.source, args.interest,
          args.area, args.budget, args.timeline, stage, score,
          1 if args.pre_approved else 0))

    # Schedule initial follow-up
    due = datetime.now(timezone.utc) + timedelta(hours=2 if stage == "hot" else 24)
    conn.execute(
        "INSERT INTO followups (lead_id, due_date, action) VALUES (?, ?, ?)",
        (lead_id, due.isoformat(), f"Initial contact — {stage} lead")
    )
    conn.commit()

    output({"success": True, "lead_id": lead_id, "name": args.name,
            "score": score, "stage": stage})


def cmd_pipeline(args):
    """Show the current lead pipeline grouped by stage."""
    conn = ensure_db()
    stages = ["hot", "warm", "nurture", "closed-won", "closed-lost"]
    pipeline = {}
    for stage in stages:
        rows = conn.execute(
            "SELECT id, name, score, area, budget, timeline, last_contact "
            "FROM leads WHERE stage = ? ORDER BY score DESC",
            (stage,)
        ).fetchall()
        pipeline[stage] = [dict(r) for r in rows]

    total = sum(len(v) for v in pipeline.values())
    summary = {s: len(v) for s, v in pipeline.items()}

    if VERBOSE:
        output({"total": total, "summary": summary, "pipeline": pipeline})
    else:
        output({"total": total, "summary": summary,
                "hot": [{"id": l["id"], "name": l["name"], "score": l["score"]}
                        for l in pipeline.get("hot", [])],
                "warm_count": len(pipeline.get("warm", []))})


def cmd_auto_followup(args):
    """Show and process pending follow-ups."""
    conn = ensure_db()
    now = datetime.now(timezone.utc).isoformat()
    rows = conn.execute("""
        SELECT f.id, f.lead_id, f.due_date, f.action, l.name, l.phone, l.email, l.stage
        FROM followups f JOIN leads l ON f.lead_id = l.id
        WHERE f.status = 'pending' AND f.due_date <= ?
        ORDER BY f.due_date ASC LIMIT ?
    """, (now, args.limit)).fetchall()

    followups = [dict(r) for r in rows]
    output({"pending_count": len(followups), "followups": followups})


def cmd_message(args):
    """Log a message/interaction with a lead."""
    conn = ensure_db()
    lead = conn.execute("SELECT * FROM leads WHERE id = ?", (args.lead_id,)).fetchone()
    if not lead:
        output({"error": "Lead not found", "lead_id": args.lead_id})
        sys.exit(1)

    now = datetime.now(timezone.utc).isoformat()
    conn.execute(
        "INSERT INTO interactions (lead_id, type, channel, message, direction) VALUES (?, ?, ?, ?, ?)",
        (args.lead_id, args.type, args.channel, args.message, args.direction)
    )
    conn.execute(
        "UPDATE leads SET engagement_count = engagement_count + 1, last_contact = ?, updated_at = ? WHERE id = ?",
        (now, now, args.lead_id)
    )

    # Recalculate score
    updated = conn.execute("SELECT * FROM leads WHERE id = ?", (args.lead_id,)).fetchone()
    new_score = calculate_score(dict(updated))
    new_stage = classify_stage(new_score) if dict(updated)["stage"] not in ("closed-won", "closed-lost") else dict(updated)["stage"]
    conn.execute(
        "UPDATE leads SET score = ?, stage = ? WHERE id = ?",
        (new_score, new_stage, args.lead_id)
    )

    # Schedule next follow-up
    interval = {"hot": 1, "warm": 3, "nurture": 7}.get(new_stage, 7)
    due = datetime.now(timezone.utc) + timedelta(days=interval)
    conn.execute(
        "INSERT INTO followups (lead_id, due_date, action) VALUES (?, ?, ?)",
        (args.lead_id, due.isoformat(), f"Follow-up after {args.type}")
    )
    conn.commit()

    output({"success": True, "lead_id": args.lead_id, "new_score": new_score,
            "stage": new_stage, "next_followup": due.isoformat()})


def cmd_nurture(args):
    """Get leads in nurture stage needing attention."""
    conn = ensure_db()
    cutoff = (datetime.now(timezone.utc) - timedelta(days=args.days_since_contact)).isoformat()
    rows = conn.execute("""
        SELECT id, name, email, phone, score, area, interest, last_contact
        FROM leads WHERE stage = 'nurture'
        AND (last_contact IS NULL OR last_contact < ?)
        ORDER BY score DESC LIMIT ?
    """, (cutoff, args.limit)).fetchall()

    leads = [dict(r) for r in rows]
    output({"count": len(leads), "leads": leads})


def cmd_search(args):
    """Search leads by name, area, or interest."""
    conn = ensure_db()
    query = f"%{args.query}%"
    rows = conn.execute("""
        SELECT id, name, email, phone, score, stage, area, interest, budget
        FROM leads WHERE name LIKE ? OR area LIKE ? OR email LIKE ? OR interest LIKE ?
        ORDER BY score DESC LIMIT 25
    """, (query, query, query, query)).fetchall()

    output({"count": len(rows), "results": [dict(r) for r in rows]})


def cmd_stats(args):
    """Show lead statistics and conversion metrics."""
    conn = ensure_db()
    total = conn.execute("SELECT COUNT(*) as c FROM leads").fetchone()["c"]
    by_stage = {}
    for row in conn.execute("SELECT stage, COUNT(*) as c FROM leads GROUP BY stage"):
        by_stage[row["stage"]] = row["c"]

    avg_score = conn.execute("SELECT AVG(score) as a FROM leads WHERE stage NOT IN ('closed-won','closed-lost')").fetchone()["a"]
    by_source = {}
    for row in conn.execute("SELECT source, COUNT(*) as c FROM leads GROUP BY source ORDER BY c DESC LIMIT 10"):
        by_source[row["source"]] = row["c"]

    pending_followups = conn.execute(
        "SELECT COUNT(*) as c FROM followups WHERE status = 'pending' AND due_date <= ?",
        (datetime.now(timezone.utc).isoformat(),)
    ).fetchone()["c"]

    won = by_stage.get("closed-won", 0)
    lost = by_stage.get("closed-lost", 0)
    conversion = round(won / max(won + lost, 1) * 100, 1)

    # Recent activity
    week_ago = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()
    new_this_week = conn.execute(
        "SELECT COUNT(*) as c FROM leads WHERE created_at >= ?", (week_ago,)
    ).fetchone()["c"]
    interactions_this_week = conn.execute(
        "SELECT COUNT(*) as c FROM interactions WHERE created_at >= ?", (week_ago,)
    ).fetchone()["c"]

    output({
        "total_leads": total,
        "by_stage": by_stage,
        "avg_score": round(avg_score or 0, 1),
        "by_source": by_source,
        "pending_followups": pending_followups,
        "conversion_rate": conversion,
        "this_week": {"new_leads": new_this_week, "interactions": interactions_this_week}
    })


# --- Main ---

def main():
    global VERBOSE
    parser = argparse.ArgumentParser(
        description="Lead Engine — Real estate lead capture & CRM"
    )
    parser.add_argument("--verbose", action="store_true", help="Verbose JSON output")
    sub = parser.add_subparsers(dest="command", required=True)

    # add
    p_add = sub.add_parser("add", help="Add a new lead")
    p_add.add_argument("--name", required=True)
    p_add.add_argument("--phone", default=None)
    p_add.add_argument("--email", default=None)
    p_add.add_argument("--source", default="manual",
                       choices=["referral", "zillow", "realtor.com", "open-house",
                                "website", "social", "cold-call", "manual", "other"])
    p_add.add_argument("--interest", default="buying",
                       choices=["buying", "selling", "both", "renting", "investing"])
    p_add.add_argument("--area", default=None)
    p_add.add_argument("--budget", type=float, default=None)
    p_add.add_argument("--timeline", default="exploring",
                       choices=["immediate", "1-3months", "3-6months", "6-12months", "exploring"])
    p_add.add_argument("--pre-approved", action="store_true")

    # pipeline
    sub.add_parser("pipeline", help="Show lead pipeline")

    # auto-followup
    p_follow = sub.add_parser("auto-followup", help="Show pending follow-ups")
    p_follow.add_argument("--limit", type=int, default=20)

    # message
    p_msg = sub.add_parser("message", help="Log an interaction")
    p_msg.add_argument("--lead-id", required=True)
    p_msg.add_argument("--type", default="note",
                       choices=["call", "text", "email", "showing", "note", "meeting"])
    p_msg.add_argument("--channel", default="manual",
                       choices=["phone", "sms", "email", "in-person", "manual"])
    p_msg.add_argument("--message", default="")
    p_msg.add_argument("--direction", default="outbound", choices=["inbound", "outbound"])

    # nurture
    p_nurture = sub.add_parser("nurture", help="Get leads needing nurture attention")
    p_nurture.add_argument("--days-since-contact", type=int, default=7)
    p_nurture.add_argument("--limit", type=int, default=20)

    # search
    p_search = sub.add_parser("search", help="Search leads")
    p_search.add_argument("query")

    # stats
    sub.add_parser("stats", help="Lead statistics and metrics")

    args = parser.parse_args()
    VERBOSE = args.verbose
    load_env()

    commands = {
        "add": cmd_add, "pipeline": cmd_pipeline, "auto-followup": cmd_auto_followup,
        "message": cmd_message, "nurture": cmd_nurture, "search": cmd_search,
        "stats": cmd_stats
    }

    try:
        commands[args.command](args)
    except Exception as e:
        output({"error": str(e), "command": args.command})
        sys.exit(1)


if __name__ == "__main__":
    main()
