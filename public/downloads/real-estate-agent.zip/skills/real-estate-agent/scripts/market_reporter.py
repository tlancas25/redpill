#!/usr/bin/env python3
"""Market Reporter — Real estate market analysis, CMA generation & newsletters.

Pulls comparable sales data, generates comparative market analyses,
weekly area updates, and monthly newsletter content for agents.
"""

import argparse
import json
import os
import sqlite3
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

# --- Configuration ---

OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", str(Path.home() / ".openclaw"))
DATA_DIR = os.path.join(OPENCLAW_HOME, "data", "real-estate-agent")
DB_PATH = os.path.join(DATA_DIR, "market.db")
CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")
VERBOSE = False

# API configuration
RAPIDAPI_HOST = "zillow-com1.p.rapidapi.com"
RAPIDAPI_BASE = f"https://{RAPIDAPI_HOST}"


def load_env():
    """Load environment variables from .openclaw/.env file."""
    env_path = os.path.join(OPENCLAW_HOME, ".env")
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, val = line.split("=", 1)
                    os.environ.setdefault(key.strip(), val.strip().strip("\"'"))


def load_config():
    """Load skill configuration."""
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH) as f:
            return json.load(f)
    return {}


def output(data):
    """Print JSON output, compact by default."""
    if VERBOSE:
        print(json.dumps(data, indent=2, default=str))
    else:
        print(json.dumps(data, default=str))


def get_api_headers():
    """Return headers for RapidAPI/Zillow requests."""
    api_key = os.environ.get("RAPIDAPI_KEY", "")
    if not api_key:
        output({"error": "RAPIDAPI_KEY not set. Add it to ~/.openclaw/.env"})
        sys.exit(1)
    return {
        "X-RapidAPI-Key": api_key,
        "X-RapidAPI-Host": RAPIDAPI_HOST
    }


def ensure_db():
    """Initialize SQLite database and return connection."""
    os.makedirs(DATA_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS comps_cache (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            address TEXT NOT NULL,
            zpid TEXT,
            beds INTEGER, baths REAL, sqft INTEGER,
            price REAL, sold_date TEXT, status TEXT,
            lot_size INTEGER, year_built INTEGER,
            latitude REAL, longitude REAL,
            fetched_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            area TEXT,
            content TEXT NOT NULL,
            created_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
        )
    """)
    conn.commit()
    return conn


def fetch_comps(address, radius_miles=1.0, months=6):
    """Fetch comparable sales from Zillow API via RapidAPI."""
    try:
        import requests
    except ImportError:
        output({"error": "requests not installed. Run: pip3 install requests"})
        sys.exit(1)

    headers = get_api_headers()

    # Step 1: Get property details and ZPID
    resp = requests.get(
        f"{RAPIDAPI_BASE}/propertyExtendedSearch",
        headers=headers,
        params={"location": address, "status_type": "RecentlySold",
                "soldInLast": f"{months}"},
        timeout=15
    )
    resp.raise_for_status()
    data = resp.json()

    props = data.get("props", [])
    if not props:
        return []

    comps = []
    for p in props[:20]:
        comps.append({
            "zpid": p.get("zpid"),
            "address": p.get("address", ""),
            "beds": p.get("bedrooms"),
            "baths": p.get("bathrooms"),
            "sqft": p.get("livingArea"),
            "price": p.get("price"),
            "sold_date": p.get("dateSold", ""),
            "status": p.get("homeStatus", ""),
            "lot_size": p.get("lotAreaValue"),
            "year_built": p.get("yearBuilt"),
            "latitude": p.get("latitude"),
            "longitude": p.get("longitude")
        })

    return comps


def cache_comps(conn, comps):
    """Store fetched comps in local cache."""
    for c in comps:
        conn.execute("""
            INSERT INTO comps_cache (address, zpid, beds, baths, sqft, price,
                sold_date, status, lot_size, year_built, latitude, longitude)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (c["address"], c.get("zpid"), c.get("beds"), c.get("baths"),
              c.get("sqft"), c.get("price"), c.get("sold_date"), c.get("status"),
              c.get("lot_size"), c.get("year_built"),
              c.get("latitude"), c.get("longitude")))
    conn.commit()


# --- CMA Generation ---

def cmd_cma(args):
    """Generate a Comparative Market Analysis."""
    conn = ensure_db()
    comps = fetch_comps(args.address, args.radius, args.months)
    if not comps:
        output({"error": "No comparable sales found", "address": args.address})
        sys.exit(1)

    cache_comps(conn, comps)

    # Calculate statistics
    prices = [c["price"] for c in comps if c.get("price")]
    sqfts = [c["sqft"] for c in comps if c.get("sqft")]
    price_per_sqft = [c["price"] / c["sqft"] for c in comps
                      if c.get("price") and c.get("sqft") and c["sqft"] > 0]

    if not prices:
        output({"error": "No valid price data in comps"})
        sys.exit(1)

    avg_price = sum(prices) / len(prices)
    median_price = sorted(prices)[len(prices) // 2]
    avg_ppsf = sum(price_per_sqft) / len(price_per_sqft) if price_per_sqft else 0
    median_ppsf = sorted(price_per_sqft)[len(price_per_sqft) // 2] if price_per_sqft else 0

    analysis = {
        "subject": args.address,
        "comp_count": len(comps),
        "radius_miles": args.radius,
        "months_back": args.months,
        "price_analysis": {
            "average": round(avg_price),
            "median": round(median_price),
            "low": min(prices),
            "high": max(prices),
            "range": max(prices) - min(prices)
        },
        "price_per_sqft": {
            "average": round(avg_ppsf, 2),
            "median": round(median_ppsf, 2),
            "low": round(min(price_per_sqft), 2) if price_per_sqft else 0,
            "high": round(max(price_per_sqft), 2) if price_per_sqft else 0
        },
        "suggested_range": {
            "low": round(median_price * 0.95),
            "target": round(median_price),
            "high": round(median_price * 1.05)
        }
    }

    if VERBOSE:
        analysis["comps"] = comps

    # Store report
    conn.execute(
        "INSERT INTO reports (type, area, content) VALUES (?, ?, ?)",
        ("cma", args.address, json.dumps(analysis, default=str))
    )
    conn.commit()

    output(analysis)


# --- Weekly Market Update ---

def cmd_weekly(args):
    """Generate a weekly market update for social media."""
    conn = ensure_db()
    comps = fetch_comps(args.area, radius_miles=3.0, months=1)
    if not comps:
        output({"error": "No recent sales data", "area": args.area})
        sys.exit(1)

    cache_comps(conn, comps)

    prices = [c["price"] for c in comps if c.get("price")]
    sqfts = [c["sqft"] for c in comps if c.get("sqft")]
    price_per_sqft = [c["price"] / c["sqft"] for c in comps
                      if c.get("price") and c.get("sqft") and c["sqft"] > 0]

    avg_price = sum(prices) / len(prices) if prices else 0
    avg_ppsf = sum(price_per_sqft) / len(price_per_sqft) if price_per_sqft else 0

    config = load_config()
    agent_name = config.get("agent", {}).get("name", "Your Agent")
    today = datetime.now(timezone.utc).strftime("%B %d, %Y")

    social_post = (
        f"WEEKLY MARKET UPDATE: {args.area}\n"
        f"{today}\n\n"
        f"Sales this month: {len(comps)}\n"
        f"Avg price: ${avg_price:,.0f}\n"
        f"Avg $/sqft: ${avg_ppsf:,.0f}\n"
        f"Price range: ${min(prices):,.0f} - ${max(prices):,.0f}\n\n"
        f"Want to know what your home is worth? DM me!\n"
        f"— {agent_name}\n"
        f"#MarketUpdate #RealEstateMarket #{args.area.replace(' ', '')}"
    )

    report = {
        "area": args.area, "date": today, "sales_count": len(comps),
        "avg_price": round(avg_price), "avg_price_per_sqft": round(avg_ppsf, 2),
        "price_range": {"low": min(prices), "high": max(prices)},
        "social_post": social_post
    }

    conn.execute(
        "INSERT INTO reports (type, area, content) VALUES (?, ?, ?)",
        ("weekly", args.area, json.dumps(report, default=str))
    )
    conn.commit()

    output(report)


# --- Monthly Newsletter ---

def cmd_newsletter(args):
    """Generate a monthly newsletter covering multiple areas."""
    areas = [a.strip() for a in args.areas.split(",")]
    config = load_config()
    agent_name = config.get("agent", {}).get("name", "Your Agent")
    agent_phone = config.get("agent", {}).get("phone", "")
    brokerage = config.get("agent", {}).get("brokerage", "")

    now = datetime.now(timezone.utc)
    month_name = now.strftime("%B %Y")

    sections = []
    for area in areas:
        try:
            comps = fetch_comps(area, radius_miles=3.0, months=1)
        except Exception as e:
            sections.append({"area": area, "error": str(e)})
            continue

        if not comps:
            sections.append({"area": area, "note": "No recent data available"})
            continue

        prices = [c["price"] for c in comps if c.get("price")]
        avg_price = sum(prices) / len(prices) if prices else 0

        sections.append({
            "area": area,
            "sales_count": len(comps),
            "avg_price": round(avg_price),
            "price_range": {"low": min(prices), "high": max(prices)} if prices else {},
            "snippet": (
                f"In {area}, we saw {len(comps)} sales this month with an "
                f"average price of ${avg_price:,.0f}. "
                f"{'The market remains active.' if len(comps) >= 5 else 'Inventory is tight.'}"
            )
        })

    newsletter = {
        "title": f"{month_name} Market Newsletter",
        "agent": agent_name,
        "brokerage": brokerage,
        "date": month_name,
        "greeting": (
            f"Happy {now.strftime('%B')}! Here's your monthly real estate "
            f"market update for the areas I serve."
        ),
        "sections": sections,
        "closing": (
            f"Have questions about your home's value or the market? "
            f"I'm always here to help. Reach me at {agent_phone}.\n\n"
            f"Best regards,\n{agent_name}\n{brokerage}"
        ),
        "area_count": len(sections)
    }

    conn = ensure_db()
    conn.execute(
        "INSERT INTO reports (type, area, content) VALUES (?, ?, ?)",
        ("newsletter", ",".join(areas), json.dumps(newsletter, default=str))
    )
    conn.commit()

    output(newsletter)


# --- Trend Analysis ---

def cmd_trends(args):
    """Analyze price trends for a zip code over time."""
    conn = ensure_db()
    comps = fetch_comps(args.zip, radius_miles=5.0, months=args.months)
    if not comps:
        output({"error": "No sales data found", "zip": args.zip})
        sys.exit(1)

    cache_comps(conn, comps)

    # Group by month
    monthly = {}
    for c in comps:
        if not c.get("price") or not c.get("sold_date"):
            continue
        try:
            sold = datetime.fromisoformat(c["sold_date"].replace("Z", "+00:00"))
            month_key = sold.strftime("%Y-%m")
        except (ValueError, TypeError):
            month_key = "unknown"
        if month_key not in monthly:
            monthly[month_key] = {"prices": [], "sqfts": [], "count": 0}
        monthly[month_key]["prices"].append(c["price"])
        if c.get("sqft"):
            monthly[month_key]["sqfts"].append(c["sqft"])
        monthly[month_key]["count"] += 1

    trend_data = []
    for month in sorted(monthly.keys()):
        m = monthly[month]
        avg_p = sum(m["prices"]) / len(m["prices"])
        ppsf_list = [p / s for p, s in zip(m["prices"], m["sqfts"]) if s > 0]
        avg_ppsf = sum(ppsf_list) / len(ppsf_list) if ppsf_list else 0
        trend_data.append({
            "month": month, "sales_count": m["count"],
            "avg_price": round(avg_p), "avg_price_per_sqft": round(avg_ppsf, 2)
        })

    # Calculate overall trend
    if len(trend_data) >= 2:
        first_avg = trend_data[0]["avg_price"]
        last_avg = trend_data[-1]["avg_price"]
        pct_change = round((last_avg - first_avg) / max(first_avg, 1) * 100, 1)
        direction = "up" if pct_change > 0 else "down" if pct_change < 0 else "flat"
    else:
        pct_change = 0
        direction = "insufficient_data"

    result = {
        "zip": args.zip, "months_analyzed": args.months,
        "total_sales": len(comps),
        "trend_direction": direction,
        "price_change_pct": pct_change,
        "monthly_data": trend_data
    }

    conn.execute(
        "INSERT INTO reports (type, area, content) VALUES (?, ?, ?)",
        ("trends", args.zip, json.dumps(result, default=str))
    )
    conn.commit()

    output(result)


# --- Main ---

def main():
    global VERBOSE
    parser = argparse.ArgumentParser(
        description="Market Reporter — Real estate market analysis & reports"
    )
    parser.add_argument("--verbose", action="store_true", help="Verbose JSON output")
    sub = parser.add_subparsers(dest="command", required=True)

    # cma
    p_cma = sub.add_parser("cma", help="Generate Comparative Market Analysis")
    p_cma.add_argument("--address", required=True)
    p_cma.add_argument("--radius", type=float, default=1.0, help="Radius in miles")
    p_cma.add_argument("--months", type=int, default=6, help="Months of history")

    # weekly
    p_weekly = sub.add_parser("weekly", help="Generate weekly market update")
    p_weekly.add_argument("--area", required=True)

    # newsletter
    p_news = sub.add_parser("newsletter", help="Generate monthly newsletter")
    p_news.add_argument("--areas", required=True, help="Comma-separated areas")

    # trends
    p_trends = sub.add_parser("trends", help="Price trend analysis")
    p_trends.add_argument("--zip", required=True)
    p_trends.add_argument("--months", type=int, default=12)

    args = parser.parse_args()
    VERBOSE = args.verbose
    load_env()

    commands = {
        "cma": cmd_cma, "weekly": cmd_weekly,
        "newsletter": cmd_newsletter, "trends": cmd_trends
    }

    try:
        commands[args.command](args)
    except Exception as e:
        output({"error": str(e), "command": args.command})
        sys.exit(1)


if __name__ == "__main__":
    main()
