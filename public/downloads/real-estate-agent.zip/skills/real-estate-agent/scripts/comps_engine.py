#!/usr/bin/env python3
"""Comps Engine — Property comparison, neighborhood analysis & price trends.

Searches comparable properties, generates neighborhood scorecards,
and analyzes price trends using property data APIs.
"""

import argparse
import json
import os
import sqlite3
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

# --- Configuration ---

OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", str(Path.home() / ".openclaw"))
DATA_DIR = os.path.join(OPENCLAW_HOME, "data", "real-estate-agent")
DB_PATH = os.path.join(DATA_DIR, "comps.db")
CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")
VERBOSE = False

RAPIDAPI_ZILLOW_HOST = "zillow-com1.p.rapidapi.com"
RAPIDAPI_ZILLOW_BASE = f"https://{RAPIDAPI_ZILLOW_HOST}"
WALKSCORE_BASE = "https://api.walkscore.com/score"
GOOGLE_MAPS_BASE = "https://maps.googleapis.com/maps/api"


def load_env():
    """Load environment variables from .openclaw/.env file."""
    env_path = os.path.join(OPENCLAW_HOME, ".env")
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, val = line.split("=", 1)
                    os.environ.setdefault(key.strip(), val.strip().strip("\"'"))


def load_config():
    """Load skill configuration."""
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH) as f:
            return json.load(f)
    return {}


def output(data):
    """Print JSON output, compact by default."""
    if VERBOSE:
        print(json.dumps(data, indent=2, default=str))
    else:
        print(json.dumps(data, default=str))


def ensure_db():
    """Initialize SQLite database and return connection."""
    os.makedirs(DATA_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS properties (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            zpid TEXT UNIQUE,
            address TEXT NOT NULL,
            beds INTEGER, baths REAL, sqft INTEGER,
            price REAL, status TEXT,
            lot_size INTEGER, year_built INTEGER,
            latitude REAL, longitude REAL,
            price_per_sqft REAL,
            sold_date TEXT,
            fetched_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS neighborhoods (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            address TEXT NOT NULL,
            walk_score INTEGER, transit_score INTEGER, bike_score INTEGER,
            school_rating REAL, nearest_schools TEXT,
            amenities TEXT, commute_data TEXT,
            fetched_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
        )
    """)
    conn.commit()
    return conn


def get_rapidapi_headers():
    """Return headers for RapidAPI requests."""
    api_key = os.environ.get("RAPIDAPI_KEY", "")
    if not api_key:
        output({"error": "RAPIDAPI_KEY not set. Add it to ~/.openclaw/.env"})
        sys.exit(1)
    return {"X-RapidAPI-Key": api_key, "X-RapidAPI-Host": RAPIDAPI_ZILLOW_HOST}


def api_request(url, headers, params, description="API"):
    """Make an API request with error handling and rate limit awareness."""
    try:
        import requests
    except ImportError:
        output({"error": "requests not installed. Run: pip3 install requests"})
        sys.exit(1)

    try:
        resp = requests.get(url, headers=headers, params=params, timeout=15)
        if resp.status_code == 429:
            output({"error": f"{description}: Rate limited. Wait and retry.",
                    "retry_after": resp.headers.get("Retry-After", "60")})
            sys.exit(1)
        resp.raise_for_status()
        return resp.json()
    except requests.exceptions.Timeout:
        output({"error": f"{description}: Request timed out"})
        sys.exit(1)
    except requests.exceptions.RequestException as e:
        output({"error": f"{description}: {str(e)}"})
        sys.exit(1)


# --- Comp Search ---

def cmd_search(args):
    """Search for comparable properties near an address."""
    conn = ensure_db()
    headers = get_rapidapi_headers()

    params = {
        "location": args.address,
        "status_type": "RecentlySold",
        "soldInLast": str(args.months),
    }
    if args.beds:
        params["bedsMin"] = str(args.beds)
        params["bedsMax"] = str(args.beds + 1)
    if args.baths:
        params["bathsMin"] = str(args.baths)
    if args.sqft_range:
        lo, hi = args.sqft_range.split("-")
        params["sqftMin"] = lo.strip()
        params["sqftMax"] = hi.strip()

    data = api_request(
        f"{RAPIDAPI_ZILLOW_BASE}/propertyExtendedSearch",
        headers, params, "Zillow Search"
    )

    props = data.get("props", [])
    results = []
    for p in props[:args.limit]:
        sqft = p.get("livingArea") or 0
        price = p.get("price") or 0
        ppsf = round(price / sqft, 2) if sqft > 0 else 0

        prop = {
            "zpid": p.get("zpid"),
            "address": p.get("address", ""),
            "beds": p.get("bedrooms"),
            "baths": p.get("bathrooms"),
            "sqft": sqft,
            "price": price,
            "price_per_sqft": ppsf,
            "sold_date": p.get("dateSold", ""),
            "year_built": p.get("yearBuilt"),
            "lot_size": p.get("lotAreaValue"),
            "status": p.get("homeStatus", ""),
            "latitude": p.get("latitude"),
            "longitude": p.get("longitude")
        }
        results.append(prop)

        # Cache in DB
        conn.execute("""
            INSERT OR REPLACE INTO properties
                (zpid, address, beds, baths, sqft, price, status, lot_size,
                 year_built, latitude, longitude, price_per_sqft, sold_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (prop["zpid"], prop["address"], prop["beds"], prop["baths"],
              prop["sqft"], prop["price"], prop["status"], prop["lot_size"],
              prop["year_built"], prop["latitude"], prop["longitude"],
              prop["price_per_sqft"], prop["sold_date"]))

    conn.commit()

    # Summary stats
    prices = [r["price"] for r in results if r["price"]]
    ppsfs = [r["price_per_sqft"] for r in results if r["price_per_sqft"]]

    summary = {
        "search_address": args.address,
        "total_found": len(results),
        "months": args.months,
    }
    if prices:
        summary["price_stats"] = {
            "avg": round(sum(prices) / len(prices)),
            "median": round(sorted(prices)[len(prices) // 2]),
            "low": min(prices), "high": max(prices)
        }
    if ppsfs:
        summary["ppsf_stats"] = {
            "avg": round(sum(ppsfs) / len(ppsfs), 2),
            "median": round(sorted(ppsfs)[len(ppsfs) // 2], 2)
        }

    if VERBOSE:
        summary["properties"] = results
    else:
        summary["sample"] = results[:5]

    output(summary)


# --- Price Trends ---

def cmd_trends(args):
    """Analyze price trends for a zip code."""
    conn = ensure_db()
    headers = get_rapidapi_headers()

    data = api_request(
        f"{RAPIDAPI_ZILLOW_BASE}/propertyExtendedSearch",
        headers,
        {"location": args.zip, "status_type": "RecentlySold",
         "soldInLast": str(args.months)},
        "Zillow Trends"
    )

    props = data.get("props", [])
    if not props:
        output({"error": "No sales data found", "zip": args.zip})
        sys.exit(1)

    # Group by month
    monthly = {}
    for p in props:
        price = p.get("price")
        sqft = p.get("livingArea")
        sold = p.get("dateSold", "")
        if not price or not sold:
            continue
        try:
            dt = datetime.fromisoformat(sold.replace("Z", "+00:00"))
            key = dt.strftime("%Y-%m")
        except (ValueError, TypeError):
            continue
        if key not in monthly:
            monthly[key] = {"prices": [], "sqfts": [], "count": 0}
        monthly[key]["prices"].append(price)
        if sqft:
            monthly[key]["sqfts"].append(sqft)
        monthly[key]["count"] += 1

    trend_points = []
    for month in sorted(monthly.keys()):
        m = monthly[month]
        avg_p = sum(m["prices"]) / len(m["prices"])
        ppsf_list = [p / s for p, s in zip(m["prices"], m["sqfts"]) if s > 0]
        avg_ppsf = sum(ppsf_list) / len(ppsf_list) if ppsf_list else 0
        trend_points.append({
            "month": month, "sales": m["count"],
            "avg_price": round(avg_p),
            "avg_ppsf": round(avg_ppsf, 2)
        })

    # Trend direction
    if len(trend_points) >= 2:
        first = trend_points[0]["avg_price"]
        last = trend_points[-1]["avg_price"]
        change_pct = round((last - first) / max(first, 1) * 100, 1)
        direction = "appreciating" if change_pct > 2 else "declining" if change_pct < -2 else "stable"
    else:
        change_pct = 0
        direction = "insufficient_data"

    output({
        "zip": args.zip, "months": args.months,
        "total_sales": sum(m["count"] for m in monthly.values()),
        "direction": direction, "change_pct": change_pct,
        "monthly": trend_points
    })


# --- Neighborhood Scorecard ---

def cmd_neighborhood(args):
    """Generate a neighborhood scorecard for a property address."""
    conn = ensure_db()

    # Check cache first (24-hour TTL)
    cached = conn.execute(
        "SELECT * FROM neighborhoods WHERE address = ? AND fetched_at > ?",
        (args.address,
         (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat())
    ).fetchone()

    if cached and not args.refresh:
        output(dict(cached))
        return

    try:
        import requests
    except ImportError:
        output({"error": "requests not installed. Run: pip3 install requests"})
        sys.exit(1)

    scorecard = {"address": args.address}

    # Walk Score
    walkscore_key = os.environ.get("WALKSCORE_API_KEY", "")
    if walkscore_key:
        try:
            resp = requests.get(WALKSCORE_BASE, params={
                "format": "json", "address": args.address,
                "wsapikey": walkscore_key, "transit": 1, "bike": 1
            }, timeout=10)
            ws = resp.json()
            scorecard["walk_score"] = ws.get("walkscore", 0)
            scorecard["transit_score"] = ws.get("transit", {}).get("score", 0)
            scorecard["bike_score"] = ws.get("bike", {}).get("score", 0)
            scorecard["walk_description"] = ws.get("description", "")
        except Exception:
            scorecard["walk_score_error"] = "Walk Score API unavailable"
    else:
        scorecard["walk_score_note"] = "Set WALKSCORE_API_KEY for walkability data"

    # Nearby places via Google Maps
    gmaps_key = os.environ.get("GOOGLE_MAPS_API_KEY", "")
    if gmaps_key:
        # Geocode the address first
        try:
            geo_resp = requests.get(
                f"{GOOGLE_MAPS_BASE}/geocode/json",
                params={"address": args.address, "key": gmaps_key},
                timeout=10
            )
            geo = geo_resp.json()
            if geo.get("results"):
                loc = geo["results"][0]["geometry"]["location"]
                lat, lng = loc["lat"], loc["lng"]
                scorecard["coordinates"] = {"lat": lat, "lng": lng}

                # Search nearby amenities
                amenity_types = ["school", "grocery_or_supermarket", "park",
                                 "restaurant", "hospital"]
                amenities = {}
                for place_type in amenity_types:
                    try:
                        places_resp = requests.get(
                            f"{GOOGLE_MAPS_BASE}/place/nearbysearch/json",
                            params={
                                "location": f"{lat},{lng}", "radius": 2000,
                                "type": place_type, "key": gmaps_key
                            },
                            timeout=10
                        )
                        places = places_resp.json().get("results", [])
                        amenities[place_type] = {
                            "count": len(places),
                            "nearest": [
                                {"name": p["name"],
                                 "rating": p.get("rating", "N/A")}
                                for p in places[:3]
                            ]
                        }
                    except Exception:
                        amenities[place_type] = {"error": "lookup failed"}

                scorecard["amenities"] = amenities

                # School details
                schools = amenities.get("school", {}).get("nearest", [])
                if schools:
                    ratings = [s["rating"] for s in schools
                               if isinstance(s.get("rating"), (int, float))]
                    scorecard["school_rating"] = (
                        round(sum(ratings) / len(ratings), 1) if ratings else None
                    )
                    scorecard["nearest_schools"] = [s["name"] for s in schools]
        except Exception as e:
            scorecard["amenities_error"] = str(e)
    else:
        scorecard["amenities_note"] = "Set GOOGLE_MAPS_API_KEY for amenity data"

    # Overall neighborhood grade
    ws = scorecard.get("walk_score", 0)
    ts = scorecard.get("transit_score", 0)
    bs = scorecard.get("bike_score", 0)
    sr = scorecard.get("school_rating") or 0
    composite = (ws * 0.3) + (ts * 0.2) + (bs * 0.15) + (sr * 7 * 0.35)

    if composite >= 75:
        grade = "A"
    elif composite >= 60:
        grade = "B"
    elif composite >= 45:
        grade = "C"
    elif composite >= 30:
        grade = "D"
    else:
        grade = "F"

    scorecard["composite_score"] = round(composite, 1)
    scorecard["grade"] = grade

    # Cache results
    conn.execute("""
        INSERT OR REPLACE INTO neighborhoods
            (address, walk_score, transit_score, bike_score, school_rating,
             nearest_schools, amenities, commute_data)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (args.address, scorecard.get("walk_score"),
          scorecard.get("transit_score"), scorecard.get("bike_score"),
          scorecard.get("school_rating"),
          json.dumps(scorecard.get("nearest_schools", [])),
          json.dumps(scorecard.get("amenities", {})),
          json.dumps(scorecard.get("commute_data", {}))))
    conn.commit()

    output(scorecard)


# --- Main ---

def main():
    global VERBOSE
    parser = argparse.ArgumentParser(
        description="Comps Engine — Property comparison & neighborhood analysis"
    )
    parser.add_argument("--verbose", action="store_true", help="Verbose JSON output")
    sub = parser.add_subparsers(dest="command", required=True)

    # search
    p_search = sub.add_parser("search", help="Search comparable properties")
    p_search.add_argument("--address", required=True)
    p_search.add_argument("--radius", type=float, default=1.0, help="Radius in miles")
    p_search.add_argument("--beds", type=int, default=None)
    p_search.add_argument("--baths", type=float, default=None)
    p_search.add_argument("--sqft-range", default=None, help="e.g. '1500-2500'")
    p_search.add_argument("--months", type=int, default=6)
    p_search.add_argument("--limit", type=int, default=20)

    # trends
    p_trends = sub.add_parser("trends", help="Price trend analysis by zip")
    p_trends.add_argument("--zip", required=True)
    p_trends.add_argument("--months", type=int, default=12)

    # neighborhood
    p_hood = sub.add_parser("neighborhood", help="Neighborhood scorecard")
    p_hood.add_argument("--address", required=True)
    p_hood.add_argument("--refresh", action="store_true", help="Force refresh cache")

    args = parser.parse_args()
    VERBOSE = args.verbose
    load_env()

    commands = {
        "search": cmd_search, "trends": cmd_trends, "neighborhood": cmd_neighborhood
    }

    try:
        commands[args.command](args)
    except Exception as e:
        output({"error": str(e), "command": args.command})
        sys.exit(1)


if __name__ == "__main__":
    main()
