#!/usr/bin/env python3
"""Client Comms — Automated client messaging, templates & milestone tracking.

Handles market update broadcasts, listing alerts, nurture touchpoints,
and transaction milestone communications via SMS (Twilio) and email (SendGrid).
"""

import argparse
import json
import os
import sqlite3
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

# --- Configuration ---

OPENCLAW_HOME = os.environ.get("OPENCLAW_HOME", str(Path.home() / ".openclaw"))
DATA_DIR = os.path.join(OPENCLAW_HOME, "data", "real-estate-agent")
DB_PATH = os.path.join(DATA_DIR, "comms.db")
CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")
VERBOSE = False


def load_env():
    """Load environment variables from .openclaw/.env file."""
    env_path = os.path.join(OPENCLAW_HOME, ".env")
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, val = line.split("=", 1)
                    os.environ.setdefault(key.strip(), val.strip().strip("\"'"))


def load_config():
    """Load skill configuration."""
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH) as f:
            return json.load(f)
    return {}


def output(data):
    """Print JSON output, compact by default."""
    if VERBOSE:
        print(json.dumps(data, indent=2, default=str))
    else:
        print(json.dumps(data, default=str))


def ensure_db():
    """Initialize SQLite database and return connection."""
    os.makedirs(DATA_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recipient TEXT NOT NULL,
            channel TEXT NOT NULL,
            template_id TEXT,
            subject TEXT,
            body TEXT NOT NULL,
            status TEXT DEFAULT 'queued',
            external_id TEXT,
            error TEXT,
            created_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
            sent_at TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS milestones (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_name TEXT NOT NULL,
            client_email TEXT,
            client_phone TEXT,
            milestone TEXT NOT NULL,
            message TEXT,
            notification_sent INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS touchpoints (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_name TEXT NOT NULL,
            type TEXT NOT NULL,
            channel TEXT NOT NULL,
            due_date TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            content TEXT,
            completed_at TEXT
        )
    """)
    conn.commit()
    return conn


# --- Message Templates ---

TEMPLATES = {
    # Market updates
    "market_update_email": {
        "subject": "Your {area} Market Update — {date}",
        "body": (
            "Hi {name},\n\n"
            "Here's what's happening in {area} real estate:\n\n"
            "- Active listings: {active_count}\n"
            "- Average price: ${avg_price}\n"
            "- Avg days on market: {avg_dom}\n\n"
            "Want to discuss what this means for you? "
            "I'm just a call away.\n\n"
            "Best,\n{agent_name}\n{brokerage}"
        )
    },
    "market_update_sms": {
        "body": (
            "{area} market update: {active_count} active listings, "
            "avg ${avg_price}. Want details? Reply YES. — {agent_name}"
        )
    },
    # Listing alerts
    "listing_alert_email": {
        "subject": "New Listing Match: {address}",
        "body": (
            "Hi {name},\n\n"
            "A new listing matches your criteria!\n\n"
            "{address}\n"
            "{beds}BR / {baths}BA | {sqft} sq ft\n"
            "${price}\n\n"
            "Want to schedule a showing? Reply to this email or call me.\n\n"
            "{agent_name}\n{agent_phone}"
        )
    },
    "listing_alert_sms": {
        "body": (
            "New match! {address} — {beds}BR/{baths}BA, ${price}. "
            "Tour this week? Reply YES. — {agent_name}"
        )
    },
    # Nurture touchpoints
    "birthday": {
        "subject": "Happy Birthday, {name}!",
        "body": (
            "Hi {name},\n\n"
            "Wishing you a wonderful birthday! "
            "It's been a pleasure working with you. "
            "If you ever need anything real estate related, "
            "I'm always here.\n\n"
            "Cheers,\n{agent_name}"
        )
    },
    "home_anniversary": {
        "subject": "Happy Home Anniversary, {name}!",
        "body": (
            "Hi {name},\n\n"
            "It's been {years} year(s) since you closed on your home! "
            "I hope you're loving every moment. "
            "Your home has likely appreciated — want a free market analysis?\n\n"
            "Best,\n{agent_name}"
        )
    },
    "holiday_greeting": {
        "subject": "Happy Holidays from {agent_name}!",
        "body": (
            "Hi {name},\n\n"
            "Wishing you and your family a joyful holiday season. "
            "Thank you for your trust — it means the world to me.\n\n"
            "Warm regards,\n{agent_name}\n{brokerage}"
        )
    },
    "quarterly_checkin": {
        "subject": "Quick Check-In — {agent_name}",
        "body": (
            "Hi {name},\n\n"
            "Just checking in! How's everything with the home? "
            "The market in your area has been {market_trend}. "
            "If you have questions or need a vendor recommendation, "
            "don't hesitate to reach out.\n\n"
            "Best,\n{agent_name}"
        )
    },
    "referral_ask": {
        "body": (
            "Hi {name}, hope you're well! "
            "Quick question — do you know anyone thinking of buying or selling? "
            "I'd love to help them the way I helped you. "
            "Thank you! — {agent_name}"
        )
    },
    # Transaction milestones
    "offer_accepted": {
        "subject": "Congratulations — Your Offer Was Accepted!",
        "body": (
            "Hi {name},\n\n"
            "Exciting news — your offer on {address} has been accepted! "
            "Here's what happens next:\n\n"
            "1. Earnest money deposit (due in 3 business days)\n"
            "2. Home inspection scheduling\n"
            "3. Appraisal ordered by lender\n\n"
            "I'll guide you through every step. "
            "Let's connect tomorrow to review the timeline.\n\n"
            "{agent_name}\n{agent_phone}"
        )
    },
    "inspection_scheduled": {
        "subject": "Home Inspection Scheduled — {address}",
        "body": (
            "Hi {name},\n\n"
            "Your home inspection is scheduled for {date} at {time}. "
            "You're welcome to attend — I'll be there too.\n\n"
            "What to expect: The inspector will review the structure, "
            "systems, and major components. We'll receive a report "
            "within 24-48 hours.\n\n"
            "{agent_name}"
        )
    },
    "appraisal_complete": {
        "subject": "Appraisal Results — {address}",
        "body": (
            "Hi {name},\n\n"
            "Great news — the appraisal on {address} is complete. "
            "{appraisal_note}\n\n"
            "Next step: We're moving toward the clear-to-close. "
            "I'll keep you updated on the timeline.\n\n"
            "{agent_name}"
        )
    },
    "clear_to_close": {
        "subject": "Clear to Close! — {address}",
        "body": (
            "Hi {name},\n\n"
            "We've received clear to close on {address}! "
            "Closing is scheduled for {closing_date}.\n\n"
            "Please bring:\n"
            "- Valid photo ID\n"
            "- Cashier's check or wire transfer confirmation\n"
            "- Any outstanding documents\n\n"
            "Almost there! {agent_name}"
        )
    },
    "closing_day": {
        "subject": "Closing Day — Welcome Home!",
        "body": (
            "Hi {name},\n\n"
            "Today's the day! Closing on {address} at {time}.\n\n"
            "After signing, you'll receive the keys to your new home. "
            "It's been a pleasure helping you through this journey.\n\n"
            "Congratulations!\n{agent_name}"
        )
    },
    "post_close_30": {
        "subject": "How's the New Home? — 30-Day Check-In",
        "body": (
            "Hi {name},\n\n"
            "It's been 30 days since you moved into {address}! "
            "How's everything going? Need any vendor recommendations "
            "(plumber, electrician, landscaper)? I have a great network.\n\n"
            "Also, if any friends or family are looking to buy or sell, "
            "I'd be grateful for the referral.\n\n"
            "Enjoy your home!\n{agent_name}"
        )
    },
    "review_request": {
        "body": (
            "Hi {name}! I hope you're settling in. "
            "If you had a great experience, would you mind leaving a review? "
            "It means a lot! {review_link}\n"
            "Thank you! — {agent_name}"
        )
    },
    "seller_listing_live": {
        "subject": "Your Listing is Live! — {address}",
        "body": (
            "Hi {name},\n\n"
            "Your home at {address} is officially on the market! "
            "Here's the game plan:\n\n"
            "- Listed at ${price}\n"
            "- Professional photos are live on MLS, Zillow, and Realtor.com\n"
            "- Social media marketing begins today\n"
            "- Open house planned for {oh_date}\n\n"
            "I'll provide showing feedback and market updates regularly.\n\n"
            "{agent_name}"
        )
    },
    "showing_feedback": {
        "subject": "Showing Feedback — {address}",
        "body": (
            "Hi {name},\n\n"
            "We had a showing at {address} today. "
            "Here's the feedback:\n\n"
            "{feedback}\n\n"
            "Total showings so far: {total_showings}\n"
            "Days on market: {dom}\n\n"
            "I'll keep you posted. {agent_name}"
        )
    },
    "price_reduction": {
        "subject": "Price Adjustment Recommendation — {address}",
        "body": (
            "Hi {name},\n\n"
            "After {dom} days on market and {showings} showings, "
            "I'd like to discuss a price adjustment for {address}.\n\n"
            "Current price: ${current_price}\n"
            "Suggested price: ${new_price}\n"
            "Market data supports this adjustment based on recent comps.\n\n"
            "Let's discuss — when works for a quick call?\n\n"
            "{agent_name}"
        )
    },
}


# --- Send Functions ---

def send_sms(to_phone, body):
    """Send SMS via Twilio."""
    account_sid = os.environ.get("TWILIO_ACCOUNT_SID", "")
    auth_token = os.environ.get("TWILIO_AUTH_TOKEN", "")
    from_number = os.environ.get("TWILIO_PHONE_NUMBER", "")

    if not all([account_sid, auth_token, from_number]):
        return {"sent": False, "error": "Twilio credentials not configured",
                "note": "Set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER"}

    try:
        from twilio.rest import Client
        client = Client(account_sid, auth_token)
        msg = client.messages.create(body=body, from_=from_number, to=to_phone)
        return {"sent": True, "sid": msg.sid, "status": msg.status}
    except ImportError:
        return {"sent": False, "error": "twilio not installed. Run: pip3 install twilio"}
    except Exception as e:
        return {"sent": False, "error": str(e)}


def send_email(to_email, subject, body):
    """Send email via SendGrid."""
    sg_key = os.environ.get("SENDGRID_API_KEY", "")
    from_email = os.environ.get("SENDGRID_FROM_EMAIL", "")

    if not all([sg_key, from_email]):
        return {"sent": False, "error": "SendGrid credentials not configured",
                "note": "Set SENDGRID_API_KEY and SENDGRID_FROM_EMAIL"}

    try:
        from sendgrid import SendGridAPIClient
        from sendgrid.helpers.mail import Mail
        message = Mail(
            from_email=from_email, to_emails=to_email,
            subject=subject, plain_text_content=body
        )
        sg = SendGridAPIClient(sg_key)
        response = sg.send(message)
        return {"sent": True, "status_code": response.status_code}
    except ImportError:
        return {"sent": False, "error": "sendgrid not installed. Run: pip3 install sendgrid"}
    except Exception as e:
        return {"sent": False, "error": str(e)}


# --- Commands ---

def cmd_market_update(args):
    """Send a market update to clients in an area."""
    conn = ensure_db()
    config = load_config()
    agent = config.get("agent", {})

    # Load leads from lead_engine DB
    leads_db = os.path.join(DATA_DIR, "leads.db")
    if not os.path.exists(leads_db):
        output({"error": "No leads database found. Add leads first with lead_engine.py"})
        sys.exit(1)

    leads_conn = sqlite3.connect(leads_db)
    leads_conn.row_factory = sqlite3.Row
    area_query = f"%{args.area}%"
    leads = leads_conn.execute(
        "SELECT name, email, phone, area FROM leads WHERE area LIKE ? AND stage != 'closed-lost'",
        (area_query,)
    ).fetchall()

    if not leads:
        output({"error": "No leads found for area", "area": args.area})
        sys.exit(1)

    template_vars = {
        "area": args.area,
        "date": datetime.now(timezone.utc).strftime("%B %d, %Y"),
        "active_count": args.active_count or "N/A",
        "avg_price": args.avg_price or "N/A",
        "avg_dom": args.avg_dom or "N/A",
        "agent_name": agent.get("name", "Your Agent"),
        "brokerage": agent.get("brokerage", ""),
        "agent_phone": agent.get("phone", ""),
    }

    results = []
    for lead in leads:
        lead = dict(lead)
        tvars = {**template_vars, "name": lead["name"]}

        if args.channel in ("email", "both") and lead.get("email"):
            tmpl = TEMPLATES["market_update_email"]
            subject = tmpl["subject"].format(**tvars)
            body = tmpl["body"].format(**tvars)

            if args.dry_run:
                result = {"channel": "email", "to": lead["email"], "dry_run": True}
            else:
                result = send_email(lead["email"], subject, body)
                conn.execute(
                    "INSERT INTO messages (recipient, channel, template_id, subject, body, status) VALUES (?, ?, ?, ?, ?, ?)",
                    (lead["email"], "email", "market_update_email", subject, body,
                     "sent" if result.get("sent") else "failed")
                )
            results.append({"lead": lead["name"], **result})

        if args.channel in ("sms", "both") and lead.get("phone"):
            tmpl = TEMPLATES["market_update_sms"]
            body = tmpl["body"].format(**tvars)

            if args.dry_run:
                result = {"channel": "sms", "to": lead["phone"], "dry_run": True}
            else:
                result = send_sms(lead["phone"], body)
                conn.execute(
                    "INSERT INTO messages (recipient, channel, template_id, body, status) VALUES (?, ?, ?, ?, ?)",
                    (lead["phone"], "sms", "market_update_sms", body,
                     "sent" if result.get("sent") else "failed")
                )
            results.append({"lead": lead["name"], **result})

    conn.commit()
    output({"area": args.area, "recipients": len(leads),
            "messages_sent": len(results), "results": results})


def cmd_listing_alert(args):
    """Send listing alerts to matching leads."""
    conn = ensure_db()
    config = load_config()
    agent = config.get("agent", {})

    # Load the listing
    listings_db = os.path.join(DATA_DIR, "listings.db")
    if not os.path.exists(listings_db):
        output({"error": "No listings database. Create a listing first."})
        sys.exit(1)

    listings_conn = sqlite3.connect(listings_db)
    listings_conn.row_factory = sqlite3.Row
    listing = listings_conn.execute(
        "SELECT * FROM listings WHERE id = ?", (args.listing_id,)
    ).fetchone()

    if not listing:
        output({"error": "Listing not found", "listing_id": args.listing_id})
        sys.exit(1)

    listing = dict(listing)

    # Find matching leads
    leads_db = os.path.join(DATA_DIR, "leads.db")
    leads_conn = sqlite3.connect(leads_db)
    leads_conn.row_factory = sqlite3.Row

    query = "SELECT * FROM leads WHERE interest IN ('buying', 'both', 'investing') AND stage IN ('hot', 'warm', 'nurture')"
    params = []
    if args.match_area:
        query += " AND area LIKE ?"
        params.append(f"%{args.match_area}%")
    if args.match_budget:
        query += " AND (budget IS NULL OR budget >= ?)"
        params.append(listing["price"] * 0.8)

    leads = leads_conn.execute(query, params).fetchall()

    template_vars = {
        "address": listing["address"],
        "beds": listing["beds"], "baths": listing["baths"],
        "sqft": f"{listing['sqft']:,}" if listing.get("sqft") else "N/A",
        "price": f"{listing['price']:,.0f}" if listing.get("price") else "N/A",
        "agent_name": agent.get("name", "Your Agent"),
        "agent_phone": agent.get("phone", ""),
    }

    results = []
    for lead in leads:
        lead = dict(lead)
        tvars = {**template_vars, "name": lead["name"]}

        if lead.get("email"):
            tmpl = TEMPLATES["listing_alert_email"]
            subject = tmpl["subject"].format(**tvars)
            body = tmpl["body"].format(**tvars)
            if args.dry_run:
                results.append({"lead": lead["name"], "channel": "email", "dry_run": True})
            else:
                result = send_email(lead["email"], subject, body)
                conn.execute(
                    "INSERT INTO messages (recipient, channel, template_id, subject, body, status) VALUES (?, ?, ?, ?, ?, ?)",
                    (lead["email"], "email", "listing_alert_email", subject, body,
                     "sent" if result.get("sent") else "failed")
                )
                results.append({"lead": lead["name"], **result})

    conn.commit()
    output({"listing_id": args.listing_id, "matched_leads": len(leads),
            "alerts_sent": len(results), "results": results})


def cmd_nurture_touchpoints(args):
    """Generate and schedule nurture touchpoints for all clients."""
    conn = ensure_db()
    config = load_config()
    agent = config.get("agent", {})

    leads_db = os.path.join(DATA_DIR, "leads.db")
    if not os.path.exists(leads_db):
        output({"error": "No leads database found"})
        sys.exit(1)

    leads_conn = sqlite3.connect(leads_db)
    leads_conn.row_factory = sqlite3.Row
    leads = leads_conn.execute(
        "SELECT * FROM leads WHERE stage NOT IN ('closed-lost')"
    ).fetchall()

    now = datetime.now(timezone.utc)
    touchpoints = []

    for lead in leads:
        lead = dict(lead)

        # Quarterly check-in
        last = lead.get("last_contact")
        if last:
            try:
                last_dt = datetime.fromisoformat(last.replace("Z", "+00:00"))
                days_since = (now - last_dt).days
            except (ValueError, TypeError):
                days_since = 999
        else:
            days_since = 999

        if days_since >= 90:
            due = now + timedelta(days=1)
            tp = {
                "client": lead["name"], "type": "quarterly_checkin",
                "channel": "email", "due_date": due.strftime("%Y-%m-%d"),
                "template": "quarterly_checkin"
            }
            touchpoints.append(tp)
            conn.execute(
                "INSERT INTO touchpoints (client_name, type, channel, due_date, content) VALUES (?, ?, ?, ?, ?)",
                (lead["name"], "quarterly_checkin", "email", due.isoformat(),
                 json.dumps(tp))
            )

        # Referral ask for closed-won (every 6 months)
        if lead.get("stage") == "closed-won" and days_since >= 180:
            due = now + timedelta(days=3)
            tp = {
                "client": lead["name"], "type": "referral_ask",
                "channel": "sms", "due_date": due.strftime("%Y-%m-%d"),
                "template": "referral_ask"
            }
            touchpoints.append(tp)
            conn.execute(
                "INSERT INTO touchpoints (client_name, type, channel, due_date, content) VALUES (?, ?, ?, ?, ?)",
                (lead["name"], "referral_ask", "sms", due.isoformat(),
                 json.dumps(tp))
            )

    conn.commit()
    output({"total_clients": len(leads), "touchpoints_scheduled": len(touchpoints),
            "touchpoints": touchpoints})


def cmd_milestone(args):
    """Track and notify on a transaction milestone."""
    conn = ensure_db()
    config = load_config()
    agent = config.get("agent", {})

    template = TEMPLATES.get(args.milestone)
    if not template and not args.message:
        output({
            "error": f"Unknown milestone '{args.milestone}'",
            "available": [k for k in TEMPLATES.keys()
                          if k in ("offer_accepted", "inspection_scheduled",
                                   "appraisal_complete", "clear_to_close",
                                   "closing_day", "post_close_30", "review_request",
                                   "seller_listing_live", "showing_feedback")]
        })
        sys.exit(1)

    body = args.message or template.get("body", "")
    subject = template.get("subject", f"Milestone: {args.milestone}") if template else f"Milestone: {args.milestone}"

    # Fill in common variables
    tvars = {
        "name": args.client, "agent_name": agent.get("name", "Your Agent"),
        "agent_phone": agent.get("phone", ""), "brokerage": agent.get("brokerage", ""),
        "address": args.address or "", "date": args.date or "",
        "time": args.time or "", "closing_date": args.closing_date or "",
        "price": args.price or "", "years": args.years or "1",
        "feedback": args.feedback or "", "total_showings": args.total_showings or "",
        "dom": args.dom or "", "showings": args.total_showings or "",
        "current_price": args.current_price or "", "new_price": args.new_price or "",
        "appraisal_note": args.appraisal_note or "The property appraised at or above the contract price.",
        "market_trend": args.market_trend or "active",
        "oh_date": args.oh_date or "", "review_link": args.review_link or "",
    }

    try:
        body = body.format(**tvars)
        subject = subject.format(**tvars)
    except KeyError:
        pass  # Some vars may not be provided; that's ok

    # Store milestone
    conn.execute(
        "INSERT INTO milestones (client_name, client_email, client_phone, milestone, message) VALUES (?, ?, ?, ?, ?)",
        (args.client, args.email, args.phone, args.milestone, body)
    )

    send_results = []
    if args.email and not args.dry_run:
        result = send_email(args.email, subject, body)
        conn.execute(
            "INSERT INTO messages (recipient, channel, template_id, subject, body, status) VALUES (?, ?, ?, ?, ?, ?)",
            (args.email, "email", args.milestone, subject, body,
             "sent" if result.get("sent") else "failed")
        )
        send_results.append({"channel": "email", **result})

    if args.phone and not args.dry_run:
        sms_body = body[:1500]  # SMS length limit
        result = send_sms(args.phone, sms_body)
        conn.execute(
            "INSERT INTO messages (recipient, channel, template_id, body, status) VALUES (?, ?, ?, ?, ?)",
            (args.phone, "sms", args.milestone, sms_body,
             "sent" if result.get("sent") else "failed")
        )
        send_results.append({"channel": "sms", **result})

    conn.commit()
    output({
        "success": True, "client": args.client, "milestone": args.milestone,
        "dry_run": args.dry_run, "send_results": send_results
    })


# --- Main ---

def main():
    global VERBOSE
    parser = argparse.ArgumentParser(
        description="Client Comms — Automated client messaging & milestone tracking"
    )
    parser.add_argument("--verbose", action="store_true", help="Verbose JSON output")
    sub = parser.add_subparsers(dest="command", required=True)

    # market-update
    p_mu = sub.add_parser("market-update", help="Send market update to area leads")
    p_mu.add_argument("--area", required=True)
    p_mu.add_argument("--channel", default="email", choices=["email", "sms", "both"])
    p_mu.add_argument("--active-count", default=None)
    p_mu.add_argument("--avg-price", default=None)
    p_mu.add_argument("--avg-dom", default=None)
    p_mu.add_argument("--dry-run", action="store_true")

    # listing-alert
    p_la = sub.add_parser("listing-alert", help="Send listing alerts to matching leads")
    p_la.add_argument("--listing-id", required=True)
    p_la.add_argument("--match-area", default=None)
    p_la.add_argument("--match-budget", action="store_true")
    p_la.add_argument("--dry-run", action="store_true")

    # nurture-touchpoints
    sub.add_parser("nurture-touchpoints", help="Schedule nurture touchpoints")

    # milestone
    p_ms = sub.add_parser("milestone", help="Track transaction milestone")
    p_ms.add_argument("--client", required=True)
    p_ms.add_argument("--milestone", required=True,
                      help="Milestone type or template name")
    p_ms.add_argument("--message", default=None, help="Custom message override")
    p_ms.add_argument("--email", default=None)
    p_ms.add_argument("--phone", default=None)
    p_ms.add_argument("--address", default=None)
    p_ms.add_argument("--date", default=None)
    p_ms.add_argument("--time", default=None)
    p_ms.add_argument("--closing-date", default=None)
    p_ms.add_argument("--price", default=None)
    p_ms.add_argument("--years", default=None)
    p_ms.add_argument("--feedback", default=None)
    p_ms.add_argument("--total-showings", default=None)
    p_ms.add_argument("--dom", default=None)
    p_ms.add_argument("--current-price", default=None)
    p_ms.add_argument("--new-price", default=None)
    p_ms.add_argument("--appraisal-note", default=None)
    p_ms.add_argument("--market-trend", default=None)
    p_ms.add_argument("--oh-date", default=None)
    p_ms.add_argument("--review-link", default=None)
    p_ms.add_argument("--dry-run", action="store_true")

    args = parser.parse_args()
    VERBOSE = args.verbose
    load_env()

    commands = {
        "market-update": cmd_market_update, "listing-alert": cmd_listing_alert,
        "nurture-touchpoints": cmd_nurture_touchpoints, "milestone": cmd_milestone
    }

    try:
        commands[args.command](args)
    except Exception as e:
        output({"error": str(e), "command": args.command})
        sys.exit(1)


if __name__ == "__main__":
    main()
