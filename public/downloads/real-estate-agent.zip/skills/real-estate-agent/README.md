# Real Estate Agent Skill Pack

Premium $97 skill pack for real estate professionals. Automates lead management, listing marketing, market analysis, property comparisons, and client communications.

## Quick Start

```bash
# 1. Install dependencies
pip3 install -r requirements.txt

# 2. Copy and edit config
cp config.example.json config.json
# Edit config.json with your agent info, service areas, etc.

# 3. Add API keys to ~/.openclaw/.env
echo 'RAPIDAPI_KEY=your_key' >> ~/.openclaw/.env
echo 'TWILIO_ACCOUNT_SID=your_sid' >> ~/.openclaw/.env
echo 'TWILIO_AUTH_TOKEN=your_token' >> ~/.openclaw/.env
echo 'TWILIO_PHONE_NUMBER=+15551234567' >> ~/.openclaw/.env
echo 'SENDGRID_API_KEY=your_key' >> ~/.openclaw/.env
echo 'SENDGRID_FROM_EMAIL=you@example.com' >> ~/.openclaw/.env
echo 'WALKSCORE_API_KEY=your_key' >> ~/.openclaw/.env
echo 'GOOGLE_MAPS_API_KEY=your_key' >> ~/.openclaw/.env

# 4. Test
python3 scripts/lead_engine.py --help
```

## Scripts

### lead_engine.py — Lead Capture & CRM

SQLite-backed lead database with automated scoring and pipeline management.

```bash
# Add a lead
python3 scripts/lead_engine.py add \
  --name "John Doe" \
  --phone "+15559876543" \
  --email "john@example.com" \
  --source referral \
  --interest buying \
  --area "Pearl District" \
  --budget 550000 \
  --timeline 1-3months \
  --pre-approved

# View pipeline
python3 scripts/lead_engine.py pipeline

# Check pending follow-ups
python3 scripts/lead_engine.py auto-followup --limit 20

# Log an interaction
python3 scripts/lead_engine.py message \
  --lead-id abc123 \
  --type call \
  --channel phone \
  --message "Discussed Pearl District listings" \
  --direction outbound

# Get leads needing attention
python3 scripts/lead_engine.py nurture --days-since-contact 7

# Search leads
python3 scripts/lead_engine.py search "Pearl District"

# View stats
python3 scripts/lead_engine.py stats
```

**Lead Scoring Algorithm** (0-100):
- Timeline urgency (0-30): immediate=30, 1-3months=25, 3-6months=15, 6-12months=8, exploring=3
- Source quality (0-25): referral=25, open-house=20, zillow/realtor.com=18, website=15, social=12
- Engagement (0-20): 2 points per interaction, max 10 interactions
- Pre-approval (0-15): 15 points if pre-approved
- Recency (0-10): 10 minus days since last contact

Stages auto-classify: hot (70+), warm (40-69), nurture (0-39), closed-won, closed-lost.

### listing_marketer.py — Listing Promotion

AI-powered listing descriptions and marketing content generation.

```bash
# Generate listing description
python3 scripts/listing_marketer.py describe \
  --address "123 Oak Street, Portland, OR 97209" \
  --beds 3 --baths 2.5 --sqft 2200 \
  --price 599000 \
  --features "updated kitchen,hardwood,fireplace,backyard" \
  --area "Pearl District"

# Generate 5-post social media pack
python3 scripts/listing_marketer.py social-pack --listing-id abc123

# Create open house campaign with countdown
python3 scripts/listing_marketer.py open-house \
  --listing-id abc123 \
  --date 2026-04-15 \
  --time "1:00 PM - 4:00 PM" \
  --campaign-start 2026-04-08

# Generate just-sold announcement
python3 scripts/listing_marketer.py just-sold \
  --listing-id abc123 \
  --sale-price 615000 \
  --days-on-market 8
```

### market_reporter.py — Market Analysis

Comparative market analysis, trend reports, and newsletter generation.

```bash
# Generate CMA
python3 scripts/market_reporter.py cma \
  --address "123 Oak Street, Portland, OR 97209" \
  --radius 1.0 \
  --months 6

# Weekly market update for social media
python3 scripts/market_reporter.py weekly --area "Pearl District"

# Monthly newsletter (multiple areas)
python3 scripts/market_reporter.py newsletter \
  --areas "Pearl District,Lake Oswego,West Linn"

# Price trend analysis
python3 scripts/market_reporter.py trends --zip 97209 --months 12
```

### comps_engine.py — Property Comparisons

Property search, neighborhood scorecards, and price trend analysis.

```bash
# Search comps
python3 scripts/comps_engine.py search \
  --address "123 Oak Street, Portland, OR 97209" \
  --beds 3 --baths 2.0 \
  --sqft-range "1800-2600" \
  --months 6

# Price trends by zip
python3 scripts/comps_engine.py trends --zip 97209 --months 12

# Neighborhood scorecard
python3 scripts/comps_engine.py neighborhood \
  --address "123 Oak Street, Portland, OR 97209"
```

Neighborhood scorecard includes: Walk Score, Transit Score, Bike Score, nearby schools with ratings, amenities (grocery, parks, restaurants, hospitals), and a composite grade (A-F).

### client_comms.py — Client Messaging

Automated communications via Twilio SMS and SendGrid email.

```bash
# Send market update to area leads
python3 scripts/client_comms.py market-update \
  --area "Pearl District" \
  --channel both \
  --active-count 45 \
  --avg-price "575,000" \
  --avg-dom 18 \
  --dry-run

# Send listing alerts to matching leads
python3 scripts/client_comms.py listing-alert \
  --listing-id abc123 \
  --match-area "Pearl District" \
  --match-budget

# Schedule nurture touchpoints
python3 scripts/client_comms.py nurture-touchpoints

# Track transaction milestone
python3 scripts/client_comms.py milestone \
  --client "John Doe" \
  --milestone offer_accepted \
  --email "john@example.com" \
  --phone "+15559876543" \
  --address "123 Oak Street"
```

**Available Milestones**: offer_accepted, inspection_scheduled, appraisal_complete, clear_to_close, closing_day, post_close_30, review_request, seller_listing_live, showing_feedback, price_reduction

**Pre-built Templates** (20+): market_update_email, market_update_sms, listing_alert_email, listing_alert_sms, birthday, home_anniversary, holiday_greeting, quarterly_checkin, referral_ask, offer_accepted, inspection_scheduled, appraisal_complete, clear_to_close, closing_day, post_close_30, review_request, seller_listing_live, showing_feedback, price_reduction

## API Setup

### Zillow Data (RapidAPI)
1. Sign up at https://rapidapi.com
2. Subscribe to "Zillow" API (zillow-com1.p.rapidapi.com)
3. Add `RAPIDAPI_KEY=your_key` to `~/.openclaw/.env`

### Twilio SMS
1. Create account at https://twilio.com
2. Get a phone number
3. Add to `~/.openclaw/.env`:
   - `TWILIO_ACCOUNT_SID`
   - `TWILIO_AUTH_TOKEN`
   - `TWILIO_PHONE_NUMBER`

### SendGrid Email
1. Create account at https://sendgrid.com
2. Create an API key with Mail Send permissions
3. Verify a sender email
4. Add to `~/.openclaw/.env`:
   - `SENDGRID_API_KEY`
   - `SENDGRID_FROM_EMAIL`

### Walk Score
1. Get API key at https://www.walkscore.com/professional/api.php
2. Add `WALKSCORE_API_KEY=your_key` to `~/.openclaw/.env`

### Google Maps
1. Enable Places API and Geocoding API in Google Cloud Console
2. Create an API key
3. Add `GOOGLE_MAPS_API_KEY=your_key` to `~/.openclaw/.env`

## Configuration

Copy `config.example.json` to `config.json` and customize:

- **agent**: Your name, brokerage, license, contact info
- **service_areas**: Areas you serve (used for market reports and newsletters)
- **lead_scoring_weights**: Tune the scoring algorithm (default 1.0 for all)
- **communication**: Quiet hours, message frequency limits
- **templates**: Email/SMS signatures, review links, calendar links
- **automation**: Follow-up timing intervals

## Automation (Cron Jobs)

```bash
# Daily agent routine (8am)
0 8 * * * cd /path/to/real-estate-agent && python3 scripts/lead_engine.py auto-followup --limit 50
5 8 * * * cd /path/to/real-estate-agent && python3 scripts/client_comms.py nurture-touchpoints

# Weekly market update (Monday 9am)
0 9 * * 1 cd /path/to/real-estate-agent && python3 scripts/market_reporter.py weekly --area "Pearl District"

# Monthly newsletter (1st of month, 10am)
0 10 1 * * cd /path/to/real-estate-agent && python3 scripts/market_reporter.py newsletter --areas "Pearl District,Lake Oswego,West Linn"
```

Or use the built-in pipeline runner:
```bash
# Run the daily agent pipeline
openclaw pipeline run pipelines/daily-agent.json

# Launch a new listing campaign
openclaw pipeline run pipelines/listing-launch.json \
  --param address="123 Oak St" --param beds=3 --param baths=2.5 \
  --param sqft=2200 --param price=599000
```

## Data Storage

All data is stored in SQLite databases under `~/.openclaw/data/real-estate-agent/`:
- `leads.db` — Lead CRM data, interactions, follow-ups
- `listings.db` — Listing data and campaigns
- `market.db` — Cached market data and reports
- `comps.db` — Property comparisons and neighborhood scores
- `comms.db` — Message log, milestones, touchpoints

## Troubleshooting

**"RAPIDAPI_KEY not set"**: Add your RapidAPI key to `~/.openclaw/.env`

**"requests not installed"**: Run `pip3 install -r requirements.txt`

**"No leads found"**: Add leads first with `lead_engine.py add`

**"Listing not found"**: Run `listing_marketer.py describe` first to create the listing

**Rate limiting**: The Zillow API allows ~5 requests/minute on free tier. If rate limited, wait 60 seconds.

**SMS not sending**: Verify Twilio credentials, phone number format (+1XXXXXXXXXX), and that the recipient has opted in.

**Email not sending**: Verify SendGrid API key, sender email is verified, and recipient email is valid.

**All scripts support `--verbose`** for detailed JSON output with full data payloads.
